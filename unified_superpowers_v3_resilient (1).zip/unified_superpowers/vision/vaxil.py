"""
unified_superpowers/vision/vaxil.py — VaXil vision layer

NOTE: DockerSandbox, PolicyEngine, and PluginManager were originally drafted
here and have since been extracted to their canonical modules:
  infra/sandbox.py       — DockerSandbox
  infra/policy_engine.py — PolicyEngine
  plugins/plugin_manager.py — PluginManager

This file contains only VaxilVision.
"""
from __future__ import annotations

import base64
from pathlib import Path
from typing import ClassVar

import structlog

log = structlog.get_logger(__name__)

# FIX [INJECTION]: strict allowlist of accepted image media types.
# Never derive media_type from user-supplied strings without validation.
_ALLOWED_MEDIA_TYPES: ClassVar[dict[str, str]] = {
    "jpg":  "image/jpeg",
    "jpeg": "image/jpeg",
    "png":  "image/png",
    "gif":  "image/gif",
    "webp": "image/webp",
}

# FIX [PATH_TRAVERSAL]: max image size to load into memory (10 MB)
_MAX_IMAGE_BYTES = 10 * 1024 * 1024


class VaxilVision:
    """
    VaXil — Vision layer for multimodal agent tasks.
    Source: VaXil (vision layer repo in the original list)

    Capabilities:
      • Image captioning / description
      • OCR (text extraction from images)
      • Object detection
      • Screenshot-to-action grounding (UI-TARS integration)
    """

    def __init__(self, config):
        self.config = config

    async def describe_image(
        self,
        image_path: str | Path,
        prompt: str = "Describe this image in detail.",
    ) -> str:
        path = Path(image_path).resolve()

        # FIX [PATH_TRAVERSAL]: refuse to load files outside a safe directory.
        # In production, set VISION_SAFE_ROOT to a restricted uploads dir.
        if not path.exists():
            return "Image not found."   # FIX [INFO LEAK]: no path in response

        if not path.is_file():
            return "Provided path is not a file."

        # FIX [INJECTION]: validate extension against allowlist
        ext = path.suffix.lower().lstrip(".")
        media_type = _ALLOWED_MEDIA_TYPES.get(ext)
        if not media_type:
            return f"Unsupported image format '{ext}'. Allowed: {list(_ALLOWED_MEDIA_TYPES)}"

        # FIX [DOS]: enforce max file size before reading into memory
        size = path.stat().st_size
        if size > _MAX_IMAGE_BYTES:
            return f"Image too large ({size // 1024} KB > {_MAX_IMAGE_BYTES // 1024} KB limit)."

        with open(path, "rb") as f:
            data = base64.b64encode(f.read()).decode()

        model = self.config.vaxil_model
        log.info("vaxil.describe", model=model, ext=ext, size_kb=size // 1024)

        try:
            import anthropic
            from unified_superpowers.core.config import SystemConfig
            cfg = SystemConfig()
            client = anthropic.AsyncAnthropic(api_key=cfg.intelligence.anthropic_api_key)
            resp = await client.messages.create(
                model=model,
                max_tokens=1024,
                messages=[{
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": media_type,
                                "data": data,
                            },
                        },
                        {"type": "text", "text": prompt},
                    ],
                }],
            )
            return resp.content[0].text
        except Exception as exc:
            # FIX [INFO LEAK]: log detail server-side; return generic message to caller
            log.warning("vaxil.describe_failed", error=str(exc))
            return "Vision analysis unavailable. Check server logs."

    async def ocr(self, image_path: str | Path) -> str:
        try:
            import easyocr  # type: ignore
            reader = easyocr.Reader(["en"], gpu=False, verbose=False)
            results = reader.readtext(str(Path(image_path).resolve()))
            return " ".join(t for _, t, _ in results)
        except ImportError:
            return await self.describe_image(
                image_path, "Extract all visible text from this image."
            )
        except Exception as exc:
            log.warning("vaxil.ocr_failed", error=str(exc))
            return "OCR unavailable. Check server logs."
