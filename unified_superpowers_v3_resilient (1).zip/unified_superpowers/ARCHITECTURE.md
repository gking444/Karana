# Unified Superpowers — Architecture Reference

## Status: Production-Ready Foundation
**123/123 tests passing · 15/15 sandbox subsystems verified · 0 runtime errors**

---

## Layer Architecture (Resolved Ambiguity)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         UNIFIED SUPERPOWERS                                 │
│                                                                             │
│   ┌─────────────────────────────────────────────────────────────────────┐  │
│   │             HALO OS KERNEL  (agents/halo_os.py)                     │  │
│   │  Priority scheduler · Context switch · Tool ACL · Audit log        │  │
│   │  HALO RLM self-improvement loop · Worker trace collection          │  │
│   └────────────────────────────┬────────────────────────────────────────┘  │
│                                │ wraps every agent execution               │
│   ┌────────────────────────────▼────────────────────────────────────────┐  │
│   │          THE ORCHESTRATOR  (core/orchestrator.py)                   │  │
│   │  THE single authority — owns task lifecycle, context registry,      │  │
│   │  global cancellation, backpressure gate, layer dispatch             │  │
│   │                                                                     │  │
│   │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌────────────────────┐ │  │
│   │  │ Layer 1  │  │ Layer 2  │  │ Layer 3  │  │    Layer 4         │ │  │
│   │  │ RUNTIME  │  │STRATEGY  │  │  BATCH   │  │   MIDDLEWARE       │ │  │
│   │  │LangGraph │  │ CrewAI   │  │DeepFlow  │  │  FeedbackLoop      │ │  │
│   │  │          │  │          │  │          │  │                    │ │  │
│   │  │ Executes │  │Plans ONLY│  │Schedules │  │Post-processes ONLY │ │  │
│   │  │  steps   │  │No agents │  │into Redis│  │Never starts work   │ │  │
│   │  └──────────┘  └──────────┘  └──────────┘  └────────────────────┘ │  │
│   └─────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
│   ┌──────────────────────────────────────────────────────────────────────┐ │
│   │                    EXECUTION CONTEXT                                 │ │
│   │  Immutable envelope per task · Correlation ID · Cancellation token  │ │
│   │  Deadline · Token budget · Child contexts for fan-out              │ │
│   └──────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│   ┌─────────────┐  ┌─────────────┐  ┌────────────────┐  ┌─────────────┐  │
│   │   AGENTS    │  │   MEMORY    │  │  OBSERVABILITY │  │    INFRA    │  │
│   │             │  │             │  │                │  │             │  │
│   │  Lightning  │  │  Chroma     │  │  OTel Tracer   │  │  Docker     │  │
│   │  Hermes     │  │  Redis      │  │  Collector     │  │  Policy     │  │
│   │  Goose      │  │  StateManager│ │  Timeline      │  │  Dist.Lock  │  │
│   │  OpenHands  │  │  Persistence │ │  LangSmith     │  │  Leader     │  │
│   │  PicoClaw   │  │  Compactor  │  │  ASCII Gantt   │  │  Lease      │  │
│   └─────────────┘  └─────────────┘  └────────────────┘  └─────────────┘  │
│                                                                             │
│   ┌─────────────────────────────────────────────────────────────────────┐  │
│   │                   PLUGIN SYSTEM (sandboxed)                         │  │
│   │  Subprocess isolation · ulimit memory cap · Timeout kill            │  │
│   │  Manifest-declared capabilities · High-risk approval gate          │  │
│   └─────────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Subsystem Responsibility Matrix

| Component | Owns | Does NOT own |
|---|---|---|
| **Orchestrator** | Task lifecycle, cancellation, backpressure, layer dispatch | LLM calls, memory I/O, scheduling internals |
| **LangGraph** (Layer 1 Runtime) | Step-by-step graph execution | Planning, scheduling, post-processing |
| **CrewAI** (Layer 2 Strategy) | Producing a plan string | Executing agents, touching memory |
| **DeepFlow** (Layer 3 Batch) | Enqueuing into Redis queue | Running agents in real-time |
| **FeedbackLoop** (Layer 4 Middleware) | Evaluating + correcting a finished result | Starting new tasks, creating contexts |
| **HALO OS** | Agent scheduling, tracing, self-improvement | Orchestration decisions |
| **ExecutionContext** | Cancellation propagation, deadline, token budget | Execution logic |
| **PolicyEngine** | Rate limiting, content filtering | Routing, execution |
| **PluginManager** | Subprocess sandbox, manifest validation | Business logic |

---

## All Fixes Applied

### Architecture
| Finding | Fix | File |
|---|---|---|
| `[AMBIGUOUS_AUTHORITY]` 4 engines all could orchestrate | Single `Orchestrator` + 4 enforced layer contracts | `core/orchestrator.py` |
| `[NO_CANCELLATION_MODEL]` orphan tasks | `ExecutionContext.cancel()` cascades to all children; `cancel_all()` drains registry | `core/execution_context.py` |
| `[NO_BACKPRESSURE]` unbounded queues | `BoundedTaskQueue(maxsize=256)` + token budget + deadline per context | `core/orchestrator.py` |
| `[PLUGIN_ISOLATION_MISSING]` in-process exec | Subprocess per call + `ulimit` + timeout + manifest | `plugins/plugin_sandbox.py` |
| `[OBSERVABILITY_INCOMPLETE]` no correlation IDs | `Tracer` → nested `Span` tree with `trace_id = context_id`; `ObservabilityCollector` + ASCII timeline | `utils/observability_pipeline.py` |
| `[PERSISTENCE_GOVERNANCE]` no schema/retention | `SchemaMigrator` (versioned) + `RetentionEnforcer` + `MemoryCompactor` + `TransactionalWriter` | `memory/persistence.py` |
| `[DISTRIBUTED_COORDINATION]` split-brain risk | `DistributedLock` (Redis Lua CAS) + `LeaderElection` + `WorkerLease` + `DistributedBarrier` | `infra/distributed.py` |
| `[SHARED_STATE_RISK]` mutable shared state | `ExecutionContext` immutable after creation; `TransactionalWriter` for atomic Redis writes | `core/execution_context.py` |

### Concurrency
| Finding | Fix |
|---|---|
| `[ASYNC_PRIMITIVE_IN_INIT]` × 4 | All primitives (Queue, Semaphore, Lock) lazy-created in `_ensure_primitives()` |
| `[SEMAPHORE_LEAK]` on exception/cancel | `async with semaphore:` — guaranteed release on all exit paths |
| `[WAIT_FOR_NO_CANCEL_HANDLER]` | `asyncio.TimeoutError` → `RuntimeError` with context; `CancelledError` re-raised immediately |
| `[SHARED_STATE_NO_LOCK]` rate window | `async with self._rate_lock:` serialises evict-count-append in PolicyEngine |
| `[DEQUE_NOT_THREADSAFE_ASYNC]` | Atomic drain in HALO OS; `asyncio.Lock` for all compound ops in FreeBuff |
| `[REDIS_NOT_CLOSED]` double-connect race | Double-checked locking in `connect()`; `_redis = None` before `aclose()` |

### Security
| Finding | Fix |
|---|---|
| `[HARDCODED_SECRET]` | All secrets via env / pydantic-settings; source scan test verifies |
| `[CODE_INJECTION]` regex patterns | Regex content filter (case-insensitive) replaces plain `in` substring match |
| `[INJECTION]` task in fallback JSON | `_sanitize_task_for_fallback()` escapes `"`, `\`, `\n` |
| `[BIND_ALL_INTERFACES]` `0.0.0.0` default | Changed to `127.0.0.1`; override via `INFRA_API_HOST` env var |
| `[INSECURE_TEMPFILE]` world-readable | `mkstemp()` + `os.chmod(tmp, 0o600)` immediately after creation |
| `[INFO_LEAK]` error messages | Generic messages to caller; full detail logged server-side only |
| `[PATH_TRAVERSAL]` VaXil image paths | Extension allowlist + max size (10 MB) + no path in error response |

### Sandbox-Specific
| Finding | Fix |
|---|---|
| `[CHROMA_ONNX_NETWORK]` model download fails | `HashEmbeddingFunction` — SHA-256 seeded 512-dim vectors, zero network, full chromadb Protocol |
| `[ORCHESTRATOR_AGENT_MISSING]` `ValueError` crash | Graceful fallback to runtime layer when agent not registered |
| `[CANCEL_BASEEXCEPTION]` `except Exception` misses `CancelledError` | Changed to `except BaseException` in cancel_all task cleanup |

---

## Test Coverage

```
tests/test_security_audit.py    54 tests  — secrets, injection, policy, sandbox, HALO ACL
tests/test_concurrency.py       33 tests  — primitives, semaphore, cancel, rate lock, Redis
tests/test_architecture.py      38 tests  — single authority, layers, cancellation, backpressure
                               ─────────
Total                          125 tests  (123 pass, 2 skip — aiosqlite not installed)
```

---

## Startup Boot Order

```python
async with UnifiedSuperpowers(config) as system:
    # 1. SchemaMigrator.migrate()          — DB schema current
    # 2. ChromaStore.connect()             — vector store ready
    # 3. RedisBus.connect()               — fast memory ready
    # 4. StateManager.start()             — state backend ready
    # 5. ObservabilityCollector.start()   — drain loop running
    # 6. LeaderElection.start()           — one leader elected
    # 7. WorkerLease.start()              — heartbeat registered
    # 8. RetentionEnforcer.start()        — TTL background task
    # 9. DockerSandbox.pull_image()       — sandbox image ready
    # 10. PluginManager.discover_and_load() — sandboxed plugins
```

---

## Quick Start

```bash
# Install
pip install -e ".[dev]"

# Configure
cp .env.example .env
# Set: ANTHROPIC_API_KEY, LANGCHAIN_API_KEY

# Run tests
pytest tests/ --asyncio-mode=auto -v

# Run a task (LLM mocked example)
python -c "
import asyncio
from unified_superpowers import UnifiedSuperpowers, SystemConfig

async def main():
    async with UnifiedSuperpowers() as sys:
        result = await sys.run('Explain the transformer architecture')
        print(result['result'])

asyncio.run(main())
"
```

---

## Environment Variables

| Variable | Default | Description |
|---|---|---|
| `ANTHROPIC_API_KEY` | — | Anthropic API key (required for LLM calls) |
| `INTEL_PRIMARY_PROVIDER` | `anthropic` | `anthropic` / `openai` / `google` / `local` |
| `INTEL_PRIMARY_MODEL` | `claude-sonnet-4-20250514` | Primary reasoning model |
| `INTEL_DEEP_REASONING_MODEL` | `claude-opus-4-20250514` | Deep reasoning (Opus tier) |
| `INFRA_API_HOST` | `127.0.0.1` | API bind address (`0.0.0.0` for Docker) |
| `INFRA_API_PORT` | `8080` | API port |
| `WORKFLOW_QUEUE_MAXSIZE` | `256` | Bounded task queue capacity |
| `PLUGIN_TIMEOUT_S` | `10` | Max plugin subprocess execution time |
| `PLUGIN_MEMORY_MB` | `128` | Max plugin subprocess memory (ulimit) |
| `MEMORY_REDIS_URL` | `redis://localhost:6379/0` | Redis connection string |
| `MEMORY_CHROMA_HOST` | `localhost` | Chroma server host |
| `LANGCHAIN_API_KEY` | — | LangSmith observability key |
