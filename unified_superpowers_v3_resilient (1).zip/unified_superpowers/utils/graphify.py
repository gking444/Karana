"""
unified_superpowers/utils/graphify.py — Graphify visualisation / logic graphing
"""
from __future__ import annotations


class Graphify:
    """Render agent task graphs and system status as Mermaid / rich tables."""

    def render_task_graph(self, subtasks: list[dict]) -> str:
        if not subtasks:
            return "No subtasks."
        lines = ["graph TD"]
        for st in subtasks:
            sid = st.get("id", "?")
            desc = st.get("description", "")[:40].replace('"', "\'")
            lines.append(f'    {sid}["{sid}: {desc}"]')
            for dep in st.get("depends_on", []):
                lines.append(f"    {dep} --> {sid}")
        return "```mermaid\n" + "\n".join(lines) + "\n```"

    def render_system_status(self, status: dict) -> str:
        try:
            from rich.table import Table
            from rich.console import Console
            import io
            table = Table(title="Unified Superpowers — System Status")
            table.add_column("Component", style="cyan")
            table.add_column("Value",     style="green")
            for k, v in status.items():
                table.add_row(str(k), str(v))
            buf = io.StringIO()
            Console(file=buf, highlight=False).print(table)
            return buf.getvalue()
        except ImportError:
            return "\n".join(f"{k}: {v}" for k, v in status.items())
