from __future__ import annotations
import asyncio
import time
import uuid
from collections import deque
from typing import Any


class FreeBuff:
    """
    FreeBuff — an in-memory scratchpad / context buffer for agents.

    Concurrency: asyncio.Lock (lazy) guards compound deque ops.
    Single-element append (write) is GIL-atomic — no lock needed.
    All multi-step ops (snapshot, clear, filter) use async API.
    """

    def __init__(self, maxlen: int = 500):
        self._buffer: deque[dict] = deque(maxlen=maxlen)
        self._lock: asyncio.Lock | None = None

    def _get_lock(self) -> asyncio.Lock:
        if self._lock is None:
            self._lock = asyncio.Lock()
        return self._lock

    def write(self, agent: str, content: str, tag: str = "note") -> None:
        """Atomic single-append — GIL-safe, no lock needed."""
        self._buffer.append({"agent": agent, "tag": tag,
                              "content": content, "ts": time.time()})

    async def read_all_async(self, agent: str | None = None,
                              tag: str | None = None) -> list[dict]:
        """Thread-safe snapshot under lock."""
        async with self._get_lock():
            items = list(self._buffer)
        if agent:
            items = [i for i in items if i["agent"] == agent]
        if tag:
            items = [i for i in items if i["tag"] == tag]
        return items

    async def read_latest_async(self, n: int = 10) -> list[dict]:
        async with self._get_lock():
            return list(self._buffer)[-n:]

    async def clear_async(self) -> None:
        async with self._get_lock():
            self._buffer.clear()

    # ── Sync API (safe for single-threaded / non-concurrent callers) ──────────
    def read_all(self, agent: str | None = None, tag: str | None = None) -> list[dict]:
        items = list(self._buffer)
        if agent:
            items = [i for i in items if i["agent"] == agent]
        if tag:
            items = [i for i in items if i["tag"] == tag]
        return items

    def read_latest(self, n: int = 10) -> list[dict]:
        return list(self._buffer)[-n:]

    def clear(self) -> None:
        self._buffer.clear()

    def summary(self) -> str:
        items = self.read_latest(20)
        if not items:
            return "(FreeBuff is empty)"
        return "\n".join(
            f"[{i['agent']}|{i['tag']}] {i['content'][:120]}" for i in items
        )


class OpenWork:
    """Work-item tracker — see utils/freebuff.py for full docstring."""
    pass  # full implementation preserved in original; stripped here for clarity


class PaperClip:
    """File attachment manager — see utils/freebuff.py for full docstring."""
    pass  # full implementation preserved in original; stripped here for clarity
