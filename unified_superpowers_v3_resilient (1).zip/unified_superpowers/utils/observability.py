"""
unified_superpowers/utils/observability.py — LangSmith + structlog setup
unified_superpowers/utils/graphify.py      — Graphify visualization
unified_superpowers/cli.py                 — CLI entrypoint (typer)
"""

# ═══════════════════════════════════════════════════════════════════════════
# Observability
# ═══════════════════════════════════════════════════════════════════════════
from __future__ import annotations
import os, structlog
from typing import Any


def setup_observability(config) -> None:
    """
    Configure structlog + LangSmith tracing.
    Source: LangSmith (observability) repo
    """
    import logging
    level = getattr(logging, config.log_level, logging.INFO)
    logging.basicConfig(level=level)

    processors = [
        structlog.contextvars.merge_contextvars,
        structlog.processors.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
    ]
    if config.log_format == "json":
        processors.append(structlog.processors.JSONRenderer())
    else:
        processors.append(structlog.dev.ConsoleRenderer(colors=True))

    structlog.configure(
        processors=processors,
        wrapper_class=structlog.make_filtering_bound_logger(level),
        context_class=dict,
        logger_factory=structlog.PrintLoggerFactory(),
    )

    # LangSmith
    if config.langsmith_api_key:
        os.environ["LANGCHAIN_API_KEY"]     = config.langsmith_api_key
        os.environ["LANGCHAIN_TRACING_V2"]  = "true"
        os.environ["LANGCHAIN_PROJECT"]     = config.langsmith_project


# ═══════════════════════════════════════════════════════════════════════════
# Graphify — visualization / logic graphing
# ═══════════════════════════════════════════════════════════════════════════
class Graphify:
    """
    Graphify — visualise agent workflows, decision trees, task graphs.
    Source: Graphify (visualisation / logic graphing) repo
    """

    def render_task_graph(self, subtasks: list[dict]) -> str:
        """Render a JARVIS-style subtask DAG as ASCII + Mermaid."""
        if not subtasks:
            return "No subtasks."

        lines = ["graph TD"]
        for st in subtasks:
            sid = st.get("id", "?")
            desc = st.get("description", "")[:40].replace('"', "'")
            lines.append(f'    {sid}["{sid}: {desc}"]')
            for dep in st.get("depends_on", []):
                lines.append(f"    {dep} --> {sid}")

        mermaid = "\n".join(lines)
        return f"```mermaid\n{mermaid}\n```"

    def render_system_status(self, status: dict) -> str:
        """Pretty-print system status."""
        from rich.table import Table
        from rich.console import Console
        import io

        table = Table(title="Unified Superpowers — System Status")
        table.add_column("Component", style="cyan")
        table.add_column("Value", style="green")
        for k, v in status.items():
            table.add_row(str(k), str(v))

        buf = io.StringIO()
        Console(file=buf, highlight=False).print(table)
        return buf.getvalue()


# ═══════════════════════════════════════════════════════════════════════════
# CLI — typer app
# ═══════════════════════════════════════════════════════════════════════════
import typer, asyncio
from typing import Optional

app = typer.Typer(
    name="superpowers",
    help="Unified Superpowers — autonomous AI agent system.",
    add_completion=False,
)


@app.command()
def run(
    task: str = typer.Argument(..., help="Task for the AI system to execute"),
    config_file: Optional[str] = typer.Option(None, "--config", "-c",
                                               help="Path to config.yaml"),
    deep: bool = typer.Option(False, "--deep", help="Force deep reasoning mode"),
    stream: bool = typer.Option(False, "--stream", help="Stream output tokens"),
):
    """Run a task through the Unified Superpowers system."""
    from unified_superpowers.core.config import SystemConfig
    from unified_superpowers.core.system import UnifiedSuperpowers

    cfg = SystemConfig.from_yaml(config_file) if config_file else SystemConfig()

    async def _run():
        async with UnifiedSuperpowers(cfg) as system:
            if stream:
                async for token in system.stream(task):
                    print(token, end="", flush=True)
                print()
            else:
                result = await system.run(task)
                typer.echo(f"\n{'─'*60}")
                typer.echo(result["result"])
                typer.echo(f"{'─'*60}")
                typer.echo(f"⏱  {result['elapsed_s']}s  |  "
                           f"agent: {result['routing'].primary.value}")

    asyncio.run(_run())


@app.command()
def status():
    """Show the current status of all sub-systems."""
    from unified_superpowers.core.config import SystemConfig
    from unified_superpowers.core.system import UnifiedSuperpowers

    async def _status():
        async with UnifiedSuperpowers() as system:
            g = Graphify()
            typer.echo(g.render_system_status(system.halo_os.status()))

    asyncio.run(_status())


@app.command()
def improve():
    """Run one HALO self-improvement cycle."""
    from unified_superpowers.core.config import SystemConfig
    from unified_superpowers.core.system import UnifiedSuperpowers

    async def _improve():
        async with UnifiedSuperpowers() as system:
            patches = await system.halo_os.improve(system.lightning.raw_llm)
            if patches:
                typer.echo(f"✅ {len(patches)} patch(es) applied:")
                for p in patches:
                    typer.echo(f"  [{p.patch_type}] {p.description}")
            else:
                typer.echo("No improvements needed — system is healthy.")

    asyncio.run(_improve())


if __name__ == "__main__":
    app()
