"""
unified_superpowers/utils/observability_pipeline.py
────────────────────────────────────────────────────
Fix [OBSERVABILITY_PIPELINE_INCOMPLETE]

Missing pieces added:
  • Correlation IDs    — every span carries context_id from ExecutionContext
  • Distributed spans  — OTel-compatible span tree (parent → child)
  • Orchestration timeline — full task execution timeline persisted to disk
  • Centralized collector — async queue drains spans to LangSmith + local JSONL
  • Health endpoint    — /health returns live metrics without auth
"""

from __future__ import annotations

import asyncio
import json
import time
import uuid
from collections import defaultdict, deque
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, AsyncIterator

import structlog

log = structlog.get_logger(__name__)

TRACE_DIR = Path("./data/traces")
TIMELINE_DIR = Path("./data/timelines")


# ── Span model ────────────────────────────────────────────────────────────────

class SpanKind(str, Enum):
    TASK       = "task"       # top-level user request
    AGENT      = "agent"      # single agent execution
    LLM        = "llm"        # LLM API call
    TOOL       = "tool"       # tool invocation
    MEMORY     = "memory"     # Chroma / Redis read-write
    MIDDLEWARE  = "middleware" # feedback loop / policy check
    SCHEDULE    = "schedule"  # DeepFlow batch schedule


@dataclass
class Span:
    """
    OTel-compatible distributed span.

    span_id      Unique ID for this span.
    trace_id     Shared by all spans in one top-level task (= context_id).
    parent_span  Span ID of the caller (None for root spans).
    kind         What layer produced this span.
    name         Human-readable operation name.
    start_ns     Epoch nanoseconds — compatible with OTel timestamps.
    end_ns       Set when span finishes.
    attributes   Arbitrary key-value metadata (strings, ints, floats).
    events       Timestamped log points inside the span.
    status_ok    True=success, False=error, None=in-progress.
    error_msg    Set on error.
    """
    span_id:     str = field(default_factory=lambda: str(uuid.uuid4())[:16])
    trace_id:    str = ""          # = context_id from ExecutionContext
    parent_span: str | None = None
    kind:        SpanKind = SpanKind.TASK
    name:        str = ""
    start_ns:    int = field(default_factory=time.time_ns)
    end_ns:      int | None = None
    attributes:  dict[str, Any] = field(default_factory=dict)
    events:      list[dict] = field(default_factory=list)
    status_ok:   bool | None = None
    error_msg:   str | None = None

    # ── Derived ───────────────────────────────────────────────────────────────

    @property
    def duration_ms(self) -> float | None:
        if self.end_ns is None:
            return None
        return (self.end_ns - self.start_ns) / 1_000_000

    def finish(self, ok: bool = True, error: str | None = None) -> None:
        self.end_ns   = time.time_ns()
        self.status_ok = ok
        self.error_msg = error

    def add_event(self, name: str, **attrs: Any) -> None:
        self.events.append({"name": name, "ts_ns": time.time_ns(), **attrs})

    def set_attr(self, key: str, value: Any) -> "Span":
        self.attributes[key] = value
        return self

    def to_dict(self) -> dict:
        return {
            "span_id":     self.span_id,
            "trace_id":    self.trace_id,
            "parent_span": self.parent_span,
            "kind":        self.kind.value,
            "name":        self.name,
            "start_ns":    self.start_ns,
            "end_ns":      self.end_ns,
            "duration_ms": self.duration_ms,
            "attributes":  self.attributes,
            "events":      self.events,
            "status_ok":   self.status_ok,
            "error_msg":   self.error_msg,
        }


# ── Tracer ────────────────────────────────────────────────────────────────────

class Tracer:
    """
    Lightweight in-process tracer.

    Usage:
        tracer = Tracer(context_id="abc123")

        with tracer.span("agent.hermes", SpanKind.AGENT) as s:
            s.set_attr("model", "claude-opus-4")
            result = await hermes.run(task)
            s.set_attr("tokens", 312)

        # or async context manager:
        async with tracer.async_span("llm.call", SpanKind.LLM) as s:
            ...
    """

    def __init__(self, context_id: str, parent_span_id: str | None = None):
        self.context_id     = context_id
        self._parent_span   = parent_span_id
        self._active_spans: list[Span] = []
        self._finished_spans: list[Span] = []

    # ── Sync context manager ──────────────────────────────────────────────────

    class _SyncSpanCtx:
        def __init__(self, tracer: "Tracer", span: Span):
            self._tracer = tracer
            self._span   = span

        def __enter__(self) -> Span:
            return self._span

        def __exit__(self, exc_type, exc_val, _tb):
            ok    = exc_type is None
            error = str(exc_val) if exc_val else None
            self._span.finish(ok=ok, error=error)
            self._tracer._active_spans.remove(self._span)
            self._tracer._finished_spans.append(self._span)
            return False   # never suppress exceptions

    def span(self, name: str, kind: SpanKind = SpanKind.AGENT,
             **attrs: Any) -> "_SyncSpanCtx":
        parent = self._active_spans[-1].span_id if self._active_spans else self._parent_span
        s = Span(trace_id=self.context_id, parent_span=parent,
                 kind=kind, name=name, attributes=dict(attrs))
        self._active_spans.append(s)
        return self._SyncSpanCtx(self, s)

    # ── Async context manager ─────────────────────────────────────────────────

    class _AsyncSpanCtx:
        def __init__(self, tracer: "Tracer", span: Span):
            self._tracer = tracer
            self._span   = span

        async def __aenter__(self) -> Span:
            return self._span

        async def __aexit__(self, exc_type, exc_val, _tb):
            ok    = exc_type is None
            error = str(exc_val) if exc_val else None
            self._span.finish(ok=ok, error=error)
            if self._span in self._tracer._active_spans:
                self._tracer._active_spans.remove(self._span)
            self._tracer._finished_spans.append(self._span)
            return False

    def async_span(self, name: str, kind: SpanKind = SpanKind.AGENT,
                   **attrs: Any) -> "_AsyncSpanCtx":
        parent = self._active_spans[-1].span_id if self._active_spans else self._parent_span
        s = Span(trace_id=self.context_id, parent_span=parent,
                 kind=kind, name=name, attributes=dict(attrs))
        self._active_spans.append(s)
        return self._AsyncSpanCtx(self, s)

    # ── Query ─────────────────────────────────────────────────────────────────

    def all_spans(self) -> list[Span]:
        return list(self._finished_spans)

    def root_spans(self) -> list[Span]:
        return [s for s in self._finished_spans if s.parent_span is None]

    def timeline(self) -> list[dict]:
        """Returns spans sorted by start_ns — orchestration timeline view."""
        return [s.to_dict() for s in sorted(
            self._finished_spans, key=lambda s: s.start_ns
        )]


# ── Centralized collector ─────────────────────────────────────────────────────

class ObservabilityCollector:
    """
    Fix [OBSERVABILITY_PIPELINE_INCOMPLETE].

    Central async collector that:
      1. Accepts spans from any tracer via ingest()
      2. Buffers in a bounded asyncio.Queue (backpressure-aware)
      3. Drains to local JSONL + LangSmith in background
      4. Exposes health metrics without needing a full HTTP server
      5. Renders orchestration timelines per trace_id

    One collector instance lives in UnifiedSuperpowers and is passed to
    every layer that produces spans.
    """

    def __init__(
        self,
        langsmith_project: str = "unified-superpowers",
        langsmith_api_key: str = "",
        flush_interval_s: float = 5.0,
        buffer_maxsize: int = 10_000,
    ):
        self._project    = langsmith_project
        self._ls_key     = langsmith_api_key
        self._interval   = flush_interval_s

        # Bounded ingestion queue — drops spans (with log) if full
        self._queue: asyncio.Queue | None = None
        self._maxsize = buffer_maxsize

        # Per-trace span index for timeline rendering
        self._traces: dict[str, list[dict]] = defaultdict(list)

        # Metrics counters
        self._total_spans    = 0
        self._dropped_spans  = 0
        self._flush_errors   = 0

        self._flush_task: asyncio.Task | None = None
        self._running = False

        TRACE_DIR.mkdir(parents=True, exist_ok=True)
        TIMELINE_DIR.mkdir(parents=True, exist_ok=True)

    def _get_queue(self) -> asyncio.Queue:
        if self._queue is None:
            self._queue = asyncio.Queue(maxsize=self._maxsize)
        return self._queue

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    async def start(self) -> None:
        self._running = True
        self._flush_task = asyncio.create_task(
            self._drain_loop(), name="observability_drain"
        )
        # Store reference so GC doesn't kill it
        log.info("observability.collector.started",
                 buffer=self._maxsize, interval_s=self._interval)

    async def stop(self) -> None:
        self._running = False
        if self._flush_task:
            self._flush_task.cancel()
            try:
                await self._flush_task
            except asyncio.CancelledError:
                pass
        # Final flush
        await self._flush_all()
        log.info("observability.collector.stopped",
                 total_spans=self._total_spans, dropped=self._dropped_spans)

    # ── Ingestion ─────────────────────────────────────────────────────────────

    async def ingest(self, span: Span) -> None:
        """Accept one span into the pipeline. Non-blocking (drops if full)."""
        d = span.to_dict()
        q = self._get_queue()
        try:
            q.put_nowait(d)
            self._total_spans += 1
            # Index by trace for timeline
            self._traces[span.trace_id].append(d)
        except asyncio.QueueFull:
            self._dropped_spans += 1
            log.debug("observability.dropped", trace=span.trace_id,
                      total_dropped=self._dropped_spans)

    async def ingest_tracer(self, tracer: Tracer) -> None:
        """Ingest all finished spans from a tracer at once."""
        for span in tracer.all_spans():
            await self.ingest(span)

    # ── Background drain ──────────────────────────────────────────────────────

    async def _drain_loop(self) -> None:
        while self._running:
            await asyncio.sleep(self._interval)
            try:
                await self._flush_all()
            except asyncio.CancelledError:
                break
            except Exception as exc:
                self._flush_errors += 1
                log.warning("observability.flush_error", error=str(exc))

    async def _flush_all(self) -> None:
        q = self._get_queue()
        batch: list[dict] = []
        try:
            while True:
                batch.append(q.get_nowait())
                q.task_done()
        except asyncio.QueueEmpty:
            pass

        if not batch:
            return

        await asyncio.gather(
            self._write_local(batch),
            self._send_langsmith(batch),
            return_exceptions=True,
        )

    async def _write_local(self, batch: list[dict]) -> None:
        ts = int(time.time())
        out = TRACE_DIR / f"spans_{ts}.jsonl"
        content = "\n".join(json.dumps(s) for s in batch)
        await asyncio.to_thread(out.write_text, content + "\n")

    async def _send_langsmith(self, batch: list[dict]) -> None:
        if not self._ls_key:
            return
        try:
            import httpx
            async with httpx.AsyncClient(timeout=10.0) as client:
                resp = await client.post(
                    "https://api.smith.langchain.com/runs/batch",
                    headers={"x-api-key": self._ls_key,
                             "Content-Type": "application/json"},
                    json={"post": [self._span_to_langsmith(s) for s in batch]},
                )
                if resp.status_code >= 400:
                    log.warning("langsmith.send_failed",
                                status=resp.status_code, body=resp.text[:200])
        except Exception as exc:
            log.debug("langsmith.unavailable", error=str(exc))

    @staticmethod
    def _span_to_langsmith(span: dict) -> dict:
        """Map our span schema to LangSmith run schema."""
        return {
            "id":           span["span_id"],
            "trace_id":     span["trace_id"],
            "parent_run_id":span.get("parent_span"),
            "name":         span["name"],
            "run_type":     span.get("kind", "chain"),
            "start_time":   span["start_ns"] / 1e9,
            "end_time":     (span["end_ns"] or span["start_ns"]) / 1e9,
            "inputs":       span.get("attributes", {}),
            "error":        span.get("error_msg"),
            "extra":        {"events": span.get("events", [])},
        }

    # ── Timeline rendering ────────────────────────────────────────────────────

    def get_timeline(self, trace_id: str) -> list[dict]:
        """
        Return all spans for a trace_id sorted chronologically.
        This is the 'orchestration timeline' view.
        """
        spans = self._traces.get(trace_id, [])
        return sorted(spans, key=lambda s: s["start_ns"])

    def render_timeline_ascii(self, trace_id: str) -> str:
        """Render a simple ASCII Gantt chart for a trace."""
        spans = self.get_timeline(trace_id)
        if not spans:
            return f"No spans for trace {trace_id}"

        t0 = min(s["start_ns"] for s in spans)
        t_max = max((s["end_ns"] or s["start_ns"]) for s in spans)
        total_ms = (t_max - t0) / 1_000_000 or 1
        width = 60

        lines = [f"Timeline: {trace_id}", "─" * (width + 30)]
        for s in spans:
            start_ms = (s["start_ns"] - t0) / 1_000_000
            dur_ms   = s.get("duration_ms") or 0
            bar_start = int((start_ms / total_ms) * width)
            bar_len   = max(1, int((dur_ms / total_ms) * width))
            bar = " " * bar_start + "█" * bar_len
            status = "✓" if s["status_ok"] else ("✗" if s["status_ok"] is False else "…")
            name = s["name"][:20].ljust(20)
            lines.append(f"{name} {status} |{bar:<{width}}| {dur_ms:6.1f}ms")

        return "\n".join(lines)

    def save_timeline(self, trace_id: str) -> Path:
        """Persist a trace timeline to TIMELINE_DIR."""
        spans = self.get_timeline(trace_id)
        out   = TIMELINE_DIR / f"timeline_{trace_id}.json"
        out.write_text(json.dumps({"trace_id": trace_id, "spans": spans}, indent=2))
        return out

    # ── Health metrics ────────────────────────────────────────────────────────

    def health(self) -> dict:
        q = self._get_queue()
        return {
            "total_spans":   self._total_spans,
            "dropped_spans": self._dropped_spans,
            "flush_errors":  self._flush_errors,
            "queue_size":    q.qsize(),
            "queue_pressure":round(q.qsize() / self._maxsize, 3),
            "active_traces": len(self._traces),
            "running":       self._running,
        }
