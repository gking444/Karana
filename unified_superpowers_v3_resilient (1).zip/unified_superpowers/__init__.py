"""
╔══════════════════════════════════════════════════════════════════════════════╗
║          U N I F I E D   S U P E R P O W E R S   S Y S T E M              ║
║                                                                              ║
║  Combines 30+ GitHub repositories into one autonomous AI agent stack:       ║
║                                                                              ║
║  Core Framework  → OpenJarvis  (modular, local-first)                        ║
║  Brain / Reason  → Hermes · OpenClaude · Gemma 4                            ║
║  Orchestration   → LangGraph · LangChain · CrewAI                           ║
║  Dev Execution   → OpenHands · LightningAgent · Goose                       ║
║  UI / Vision     → UI-TARS · PicoClaw · VaXil · edxui                      ║
║  Workflow        → Ruflow · DeepFlow 2.0 · Task Router                      ║
║  Memory          → Chroma (vector) · Redis (fast) · State Manager           ║
║  Observability   → LangSmith · Feedback Loop                                ║
║  Reference       → Microsoft JARVIS (HuggingGPT)                            ║
║  Extensions      → Plugin System · Policy Engine · Superpowers              ║
║  Utilities       → Graphify · FreeBuff · OpenWork · PaperClip               ║
║  Infra           → Docker · Jarvis Runtime                                  ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

from unified_superpowers.core.system import UnifiedSuperpowers
from unified_superpowers.core.config import SystemConfig

__version__ = "1.0.0"
__all__ = ["UnifiedSuperpowers", "SystemConfig"]
