"""
unified_superpowers/plugins/plugin_manager.py — Plugin System
"""
from __future__ import annotations
import importlib.util, inspect
from pathlib import Path
from typing import Any
import structlog
log = structlog.get_logger(__name__)

class PluginManager:
    def __init__(self, plugin_dirs: list[Path]):
        self.plugin_dirs = plugin_dirs
        self._plugins: dict[str, Any] = {}
    async def discover_and_load(self) -> None:
        for plugin_dir in self.plugin_dirs:
            if not plugin_dir.exists():
                plugin_dir.mkdir(parents=True, exist_ok=True)
                continue
            for py_file in plugin_dir.glob("*.py"):
                await self._load(py_file)
    async def _load(self, path: Path) -> None:
        name = path.stem
        try:
            spec = importlib.util.spec_from_file_location(name, path)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            if hasattr(mod, "register"):
                self._plugins[name] = mod
                log.info("plugin.loaded", name=name)
        except Exception as exc:
            log.warning("plugin.load_failed", name=name, error=str(exc))
    def list_plugins(self) -> list[str]: return list(self._plugins.keys())
    async def call_hook(self, hook: str, *args, **kwargs) -> list[Any]:
        results = []
        for name, mod in self._plugins.items():
            fn = getattr(mod, hook, None)
            if fn:
                try:
                    r = await fn(*args, **kwargs) if inspect.iscoroutinefunction(fn) else fn(*args, **kwargs)
                    results.append(r)
                except Exception as exc:
                    log.warning("plugin.hook_failed", plugin=name, hook=hook, error=str(exc))
        return results
