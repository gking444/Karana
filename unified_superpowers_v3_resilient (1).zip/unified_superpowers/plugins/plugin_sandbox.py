"""
unified_superpowers/plugins/plugin_sandbox.py
──────────────────────────────────────────────
Fix [PLUGIN_ISOLATION_MISSING] + [DYNAMIC_IMPORTS_DANGEROUS]

Problems fixed:
  1. Plugins ran in-process → one crash/block killed the runtime
  2. spec.loader.exec_module() gave plugins unrestricted Python execution
  3. No capability declarations → plugins had implicit full access
  4. No timeout → a blocking plugin stalled the async event loop

Solution:
  PluginSandbox     — runs each plugin in a subprocess with a timeout
  PluginManifest    — declarative capability set (what the plugin may do)
  CapabilityGuard   — enforces the manifest before any hook fires
  SandboxedPlugin   — wraps a plugin's hooks with the guard + subprocess call

Architecture:
  ┌──────────────────────────────────────────────────────────┐
  │  PluginManager (orchestrator)                            │
  │    • discovers .py files + matching .manifest.json       │
  │    • validates manifest against AllowedCapabilities      │
  │    • wraps each plugin in SandboxedPlugin                │
  └──────────────────────────────────────────────────────────┘
            │ calls
  ┌──────────▼────────────────────────────────────────────────┐
  │  SandboxedPlugin                                          │
  │    • spawns plugin in subprocess (asyncio subprocess)    │
  │    • passes hook name + JSON args via stdin              │
  │    • reads JSON result from stdout                       │
  │    • enforces timeout (PLUGIN_TIMEOUT_S)                 │
  │    • kills subprocess on timeout/error                   │
  └───────────────────────────────────────────────────────────┘
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any

import structlog

log = structlog.get_logger(__name__)

PLUGIN_TIMEOUT_S = float(os.getenv("PLUGIN_TIMEOUT_S", "10"))
PLUGIN_MEMORY_MB = int(os.getenv("PLUGIN_MEMORY_MB", "128"))


# ── Capability model ──────────────────────────────────────────────────────────

class Capability(str, Enum):
    """
    Explicit capability flags a plugin must declare to use a resource.
    Inspired by Android permissions and WASM component model.
    """
    READ_MEMORY   = "read_memory"     # read Chroma / Redis
    WRITE_MEMORY  = "write_memory"    # write Chroma / Redis
    CALL_LLM      = "call_llm"        # make LLM API calls
    FILE_READ     = "file_read"       # read local filesystem
    FILE_WRITE    = "file_write"      # write local filesystem
    NETWORK       = "network"         # outbound HTTP
    SPAWN_AGENT   = "spawn_agent"     # create new agent tasks
    EXECUTE_CODE  = "execute_code"    # run code in sandbox
    UI_CONTROL    = "ui_control"      # desktop automation
    ADMIN         = "admin"           # manage other plugins


# Capabilities that require explicit operator approval
HIGH_RISK_CAPABILITIES = {
    Capability.EXECUTE_CODE,
    Capability.UI_CONTROL,
    Capability.ADMIN,
    Capability.FILE_WRITE,
    Capability.SPAWN_AGENT,
}


@dataclass
class PluginManifest:
    """
    Declarative metadata every plugin must ship alongside its .py file.
    File: <plugin_name>.manifest.json

    Example:
        {
          "name": "my_plugin",
          "version": "1.0.0",
          "author": "team@example.com",
          "capabilities": ["read_memory", "call_llm"],
          "hooks": ["on_task_complete"],
          "description": "Logs task completions to Slack"
        }
    """
    name:         str
    version:      str = "1.0.0"
    author:       str = "unknown"
    description:  str = ""
    capabilities: list[Capability] = field(default_factory=list)
    hooks:        list[str]        = field(default_factory=list)
    # If True, the plugin was approved by an operator for high-risk capabilities
    operator_approved: bool = False

    @classmethod
    def load(cls, manifest_path: Path) -> "PluginManifest":
        with open(manifest_path) as f:
            data = json.load(f)
        caps = [Capability(c) for c in data.get("capabilities", [])]
        return cls(
            name=data["name"],
            version=data.get("version", "1.0.0"),
            author=data.get("author", "unknown"),
            description=data.get("description", ""),
            capabilities=caps,
            hooks=data.get("hooks", []),
            operator_approved=data.get("operator_approved", False),
        )

    def check_capability(self, cap: Capability) -> None:
        """Raise PermissionError if this manifest does not declare `cap`."""
        if cap not in self.capabilities:
            raise PermissionError(
                f"Plugin '{self.name}' attempted to use capability "
                f"'{cap.value}' which is not declared in its manifest. "
                f"Declared: {[c.value for c in self.capabilities]}"
            )

    def validate_high_risk(self) -> list[str]:
        """
        Return list of warnings for undeclared high-risk capabilities.
        Raises if high-risk caps are present but operator_approved=False.
        """
        warnings = []
        for cap in self.capabilities:
            if cap in HIGH_RISK_CAPABILITIES and not self.operator_approved:
                warnings.append(
                    f"Plugin '{self.name}' declares high-risk capability "
                    f"'{cap.value}' without operator_approved=true in manifest."
                )
        return warnings


# ── Subprocess runner ─────────────────────────────────────────────────────────

_RUNNER_SCRIPT = """\
import sys, json, importlib.util, traceback

def run(plugin_path, hook, args):
    spec = importlib.util.spec_from_file_location("plugin", plugin_path)
    mod  = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    fn = getattr(mod, hook, None)
    if fn is None:
        return {"ok": False, "error": f"Hook '{hook}' not found in plugin"}
    import asyncio, inspect
    if inspect.iscoroutinefunction(fn):
        result = asyncio.run(fn(**args))
    else:
        result = fn(**args)
    return {"ok": True, "result": result}

payload = json.loads(sys.stdin.read())
try:
    out = run(payload["plugin_path"], payload["hook"], payload.get("args", {}))
    print(json.dumps(out))
except Exception as exc:
    print(json.dumps({"ok": False, "error": traceback.format_exc()}))
"""


class SandboxedPlugin:
    """
    Runs a single plugin hook in a subprocess.

    • Process is spawned fresh per call — no persistent state leaks between calls
    • stdout = JSON result; stderr = discarded (logs stay in subprocess only)
    • Killed unconditionally after PLUGIN_TIMEOUT_S seconds
    • Memory limit enforced via ulimit on POSIX systems
    """

    def __init__(self, plugin_path: Path, manifest: PluginManifest):
        self.path     = plugin_path
        self.manifest = manifest

    async def call_hook(self, hook: str, **kwargs: Any) -> Any:
        """
        Call `hook` in a fresh subprocess.
        Returns the hook's return value (must be JSON-serialisable).
        Raises RuntimeError on timeout or plugin crash.
        """
        if hook not in self.manifest.hooks:
            log.debug("plugin.hook_not_declared",
                      plugin=self.manifest.name, hook=hook)
            return None

        payload = json.dumps({
            "plugin_path": str(self.path),
            "hook": hook,
            "args": kwargs,
        }).encode()

        # Build subprocess command — enforce memory cap via ulimit (POSIX only)
        if sys.platform != "win32":
            cmd = [
                "sh", "-c",
                f"ulimit -v {PLUGIN_MEMORY_MB * 1024}; "
                f"{sys.executable} -c {json.dumps(_RUNNER_SCRIPT)}",
            ]
        else:
            cmd = [sys.executable, "-c", _RUNNER_SCRIPT]

        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL,
        )

        try:
            stdout, _ = await asyncio.wait_for(
                proc.communicate(payload),
                timeout=PLUGIN_TIMEOUT_S,
            )
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            raise RuntimeError(
                f"Plugin '{self.manifest.name}' hook '{hook}' "
                f"timed out after {PLUGIN_TIMEOUT_S}s — killed."
            )
        except asyncio.CancelledError:
            proc.kill()
            await proc.wait()
            raise

        if proc.returncode != 0:
            raise RuntimeError(
                f"Plugin '{self.manifest.name}' subprocess exited "
                f"with code {proc.returncode}."
            )

        try:
            result = json.loads(stdout)
        except json.JSONDecodeError as exc:
            raise RuntimeError(
                f"Plugin '{self.manifest.name}' returned non-JSON output: "
                f"{stdout[:200]}"
            ) from exc

        if not result.get("ok"):
            raise RuntimeError(
                f"Plugin '{self.manifest.name}' hook '{hook}' failed: "
                f"{result.get('error', 'unknown error')[:500]}"
            )

        return result.get("result")


# ── Updated PluginManager ──────────────────────────────────────────────────────

class PluginManager:
    """
    Discovers, validates, and exposes sandboxed plugins.

    Replaces the old in-process exec_module() approach with:
      1. Manifest validation before load
      2. High-risk capability warnings (or errors if unapproved)
      3. SandboxedPlugin wrapper for every hook call
    """

    def __init__(self, plugin_dirs: list[Path],
                 allow_high_risk: bool = False):
        self.plugin_dirs    = plugin_dirs
        self.allow_high_risk = allow_high_risk
        self._plugins: dict[str, SandboxedPlugin] = {}
        self._manifests: dict[str, PluginManifest] = {}

    async def discover_and_load(self) -> None:
        for plugin_dir in self.plugin_dirs:
            if not plugin_dir.exists():
                plugin_dir.mkdir(parents=True, exist_ok=True)
                continue
            for py_file in sorted(plugin_dir.glob("*.py")):
                await self._load(py_file)

    async def _load(self, path: Path) -> None:
        name = path.stem

        # ── Require manifest ───────────────────────────────────────────────
        manifest_path = path.with_suffix(".manifest.json")
        if not manifest_path.exists():
            log.warning(
                "plugin.no_manifest",
                name=name,
                hint=f"Create {manifest_path} to enable this plugin.",
            )
            return

        try:
            manifest = PluginManifest.load(manifest_path)
        except Exception as exc:
            log.error("plugin.manifest_parse_failed", name=name, error=str(exc))
            return

        # ── Capability validation ──────────────────────────────────────────
        warnings = manifest.validate_high_risk()
        for w in warnings:
            if self.allow_high_risk:
                log.warning("plugin.high_risk_capability", warning=w)
            else:
                log.error(
                    "plugin.blocked_high_risk",
                    name=name,
                    warning=w,
                    hint="Set allow_high_risk=True or add operator_approved=true to manifest.",
                )
                return

        # ── Wrap in sandbox ────────────────────────────────────────────────
        sandboxed = SandboxedPlugin(path, manifest)
        self._plugins[name]   = sandboxed
        self._manifests[name] = manifest
        log.info(
            "plugin.loaded",
            name=name,
            capabilities=[c.value for c in manifest.capabilities],
            hooks=manifest.hooks,
        )

    def list_plugins(self) -> list[dict]:
        return [
            {
                "name":         name,
                "version":      self._manifests[name].version,
                "capabilities": [c.value for c in self._manifests[name].capabilities],
                "hooks":        self._manifests[name].hooks,
            }
            for name in self._plugins
        ]

    async def call_hook(self, hook: str, **kwargs: Any) -> list[Any]:
        """Call `hook` on all plugins that declare it. Returns list of results."""
        results = []
        for name, plugin in list(self._plugins.items()):
            if hook not in plugin.manifest.hooks:
                continue
            try:
                r = await plugin.call_hook(hook, **kwargs)
                if r is not None:
                    results.append(r)
            except Exception as exc:
                # Plugin failure is isolated — never propagates to runtime
                log.error(
                    "plugin.hook_failed",
                    plugin=name,
                    hook=hook,
                    error=str(exc)[:200],
                )
        return results

    def check_capability(self, plugin_name: str, cap: Capability) -> bool:
        manifest = self._manifests.get(plugin_name)
        if not manifest:
            return False
        try:
            manifest.check_capability(cap)
            return True
        except PermissionError:
            return False
