"""
unified_superpowers/cli.py — CLI entrypoint (typer)
"""
from __future__ import annotations
import asyncio
from typing import Optional
import typer

app = typer.Typer(
    name="superpowers",
    help="Unified Superpowers — autonomous AI agent system.",
    add_completion=False,
)


@app.command()
def run(
    task: str = typer.Argument(..., help="Task for the AI system to execute"),
    config_file: Optional[str] = typer.Option(None, "--config", "-c"),
    deep: bool  = typer.Option(False, "--deep"),
    stream: bool= typer.Option(False, "--stream"),
):
    """Run a task through the Unified Superpowers system."""
    from unified_superpowers.core.config import SystemConfig
    from unified_superpowers.core.system import UnifiedSuperpowers

    cfg = SystemConfig.from_yaml(config_file) if config_file else SystemConfig()

    async def _run():
        async with UnifiedSuperpowers(cfg) as system:
            if stream:
                async for token in system.stream(task):
                    print(token, end="", flush=True)
                print()
            else:
                result = await system.run(task)
                typer.echo(result["result"])

    asyncio.run(_run())


if __name__ == "__main__":
    app()
