"""
unified_superpowers/memory/chroma_store.py — Vector memory (Chroma)
"""
from __future__ import annotations

import hashlib
import math
import time
from typing import Any

import structlog

log = structlog.get_logger(__name__)


def _make_local_ef():
    """
    Build a local embedding function — no network, no ONNX download.

    Implements the full chromadb EmbeddingFunction API discovered empirically:
      • name()        → str          (called by get_or_create_collection)
      • __call__()    → Embeddings   (called by add / upsert)
      • embed_query() → Embeddings   (called by query)

    Uses SHA-256 seeded hashing to produce 512-dim unit-normalised vectors.
    Not semantically meaningful; suitable for dev/sandbox/CI environments.
    """
    try:
        from chromadb.utils.embedding_functions import SentenceTransformerEmbeddingFunction
        ef = SentenceTransformerEmbeddingFunction(model_name="all-MiniLM-L6-v2", device="cpu")
        ef(["warmup"])   # raises if model not cached locally
        log.debug("chroma.embedding_fn", source="sentence-transformers")
        return ef
    except Exception:
        pass

    class HashEmbeddingFunction:
        """
        Deterministic hash-based embedding.  No external dependencies.
        Implements the chromadb EmbeddingFunction duck-type protocol.

        FIX [DEPRECATION_WARNING]: chromadb's collection-config serialiser
        calls `embedding_function.is_legacy()` as a METHOD (not a property)
        when persisting collection metadata. A plain bool class attribute
        raises "'bool' object is not callable" when chromadb tries to call
        it. Define it as a method returning False to mark us "current-style".
        """
        DIM = 512

        def is_legacy(self) -> bool:
            return False

        def supported_spaces(self) -> list:
            return ["cosine", "l2", "ip"]

        def get_config(self) -> dict:
            return {"dim": self.DIM, "type": "hash_embedding_function"}

        @classmethod
        def build_from_config(cls, config: dict) -> "HashEmbeddingFunction":
            return cls()

        def name(self) -> str:                  # chromadb calls this as a METHOD
            return "hash_embedding_function"

        def __call__(self, input) -> list:       # add / upsert path
            return self._embed(input)

        def embed_query(self, input) -> list:    # query path
            return self._embed(input)

        def _embed(self, texts) -> list:
            results = []
            for text in texts:
                seed = str(text).encode("utf-8", errors="replace")
                raw: list[float] = []
                i = 0
                while len(raw) < self.DIM:
                    digest = hashlib.sha256(seed + i.to_bytes(4, "little")).digest()
                    for byte in digest:
                        raw.append(float(byte) - 127.5)
                        if len(raw) == self.DIM:
                            break
                    i += 1
                norm = math.sqrt(sum(x * x for x in raw)) or 1.0
                results.append([x / norm for x in raw])
            return results

    log.info(
        "chroma.embedding_fn",
        source="hash_fallback",
        note="deterministic hash embeddings — semantic search disabled",
    )
    return HashEmbeddingFunction()


class ChromaStore:
    """
    Vector memory — wraps chromadb.
    Source: github.com/chroma-core/chroma

    Connection strategy:
      1. Remote HTTP server (production)
      2. In-memory client with local embedding function (dev / sandbox)
    """

    def __init__(self, config):
        self.config = config
        self._client = None
        self._collection = None
        self._ef = None   # embedding function, created lazily

    def _get_ef(self):
        if self._ef is None:
            self._ef = _make_local_ef()
        return self._ef

    async def connect(self) -> None:
        try:
            import chromadb
            self._client = chromadb.HttpClient(
                host=self.config.chroma_host,
                port=self.config.chroma_port,
            )
            # Remote server uses its own embedding function
            self._collection = self._client.get_or_create_collection(
                name=self.config.chroma_collection,
                metadata={"hnsw:space": "cosine"},
            )
            log.info("chroma.connected",
                     collection=self.config.chroma_collection,
                     mode="remote")
        except Exception as exc:
            log.warning("chroma.remote_unavailable", error=str(exc)[:120])
            # FIX [CHROMA_ONNX_NETWORK]: pass our local embedding function
            # so Chroma never tries to download the ONNX model.
            await self._connect_local()

    async def _connect_local(self) -> None:
        try:
            import chromadb
            self._client = chromadb.Client()
            ef = self._get_ef()
            self._collection = self._client.get_or_create_collection(
                name=self.config.chroma_collection,
                embedding_function=ef,
                metadata={"hnsw:space": "cosine"},
            )
            log.info("chroma.in_memory_fallback",
                     embedding="local",
                     collection=self.config.chroma_collection)
        except Exception as exc2:
            log.warning("chroma.unavailable", error=str(exc2)[:120])
            self._collection = None

    async def add(self, task: str, result: Any) -> None:
        if not self._collection:
            return
        doc_id = hashlib.sha256(
            f"{task}{time.time()}".encode()
        ).hexdigest()[:16]
        try:
            self._collection.add(
                ids=[doc_id],
                documents=[str(result)[:2000]],
                metadatas=[{"task": task[:200], "ts": time.time()}],
            )
        except Exception as exc:
            log.warning("chroma.add_failed", error=str(exc)[:120])

    async def query(self, text: str, n_results: int = 5) -> list[dict]:
        if not self._collection:
            return []
        try:
            actual_n = min(
                n_results,
                self._collection.count(),
            )
            if actual_n == 0:
                return []
            res = self._collection.query(
                query_texts=[text], n_results=actual_n
            )
            docs  = res.get("documents", [[]])[0]
            metas = res.get("metadatas",  [[]])[0]
            return [
                {"document": d, "metadata": m}
                for d, m in zip(docs, metas)
            ]
        except Exception as exc:
            log.warning("chroma.query_failed", error=str(exc)[:120])
            return []

    async def delete_collection(self) -> None:
        if self._client and self._collection:
            try:
                self._client.delete_collection(self.config.chroma_collection)
                self._collection = None
            except Exception as exc:
                log.warning("chroma.delete_failed", error=str(exc))
