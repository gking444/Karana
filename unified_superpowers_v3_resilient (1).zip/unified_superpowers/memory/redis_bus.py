"""
unified_superpowers/memory/redis_bus.py
unified_superpowers/memory/state_manager.py
"""
# ── redis_bus.py ─────────────────────────────────────────────────────────
from __future__ import annotations
import asyncio
import json
import structlog
from typing import Any

log = structlog.get_logger(__name__)


class RedisBus:
    """
    Fast memory + task queue — wraps redis-py async.
    Source: Redis (redis.io) + RQ (python-rq)

    Thread/concurrency safety model
    ────────────────────────────────
    • _connect_lock (asyncio.Lock, lazy):
        Guards connect() so that if two coroutines call connect() concurrently
        (e.g. at startup race) only one actually creates the connection; the
        second finds _redis already set and returns immediately.

    • redis-py AsyncRedis connection pool:
        redis-py's async client is internally thread-safe for individual
        commands (each command grabs a connection from the pool).
        We do NOT need to lock around individual set/get/push/pop calls.

    • disconnect():
        Sets self._redis = None *before* awaiting aclose() so that
        any concurrent in-flight command that checks `if self._redis`
        after the None assignment will fall through to the no-op path
        rather than calling aclose() on a closing connection.
    """

    def __init__(self, config):
        self.config = config
        self._redis = None
        # FIX [SHARED_STATE_NO_LOCK]: lazy lock for connect — prevents
        # concurrent double-connect at startup.
        self._connect_lock: asyncio.Lock | None = None

    def _get_lock(self) -> asyncio.Lock:
        """Lazily create the connect lock under the running event loop."""
        if self._connect_lock is None:
            self._connect_lock = asyncio.Lock()
        return self._connect_lock

    async def connect(self) -> None:
        # FIX [SHARED_STATE_NO_LOCK]: double-checked locking pattern —
        # fast path (already connected) costs zero contention.
        if self._redis is not None:
            return
        async with self._get_lock():
            if self._redis is not None:   # re-check inside lock
                return
            try:
                import redis.asyncio as aioredis
                self._redis = await aioredis.from_url(
                    self.config.redis_url,
                    encoding="utf-8",
                    decode_responses=True,
                )
                await self._redis.ping()
                log.info("redis.connected", url=self.config.redis_url)
            except Exception as exc:
                log.warning("redis.connect_failed_using_dict_fallback", error=str(exc))
                self._redis = None   # in-process dict fallback

    async def disconnect(self) -> None:
        # FIX [REDIS_NOT_CLOSED]: explicit disconnect confirmed present.
        # Set to None FIRST so concurrent callers see None immediately,
        # then await the actual close — avoids "use after close" on the pool.
        client, self._redis = self._redis, None
        if client is not None:
            try:
                await client.aclose()
                log.info("redis.disconnected")
            except Exception as exc:
                log.warning("redis.disconnect_error", error=str(exc))

    async def set(self, key: str, value: Any, ttl: int | None = None) -> None:
        if self._redis:
            payload = json.dumps(value) if not isinstance(value, str) else value
            if ttl:
                await self._redis.setex(key, ttl, payload)
            else:
                await self._redis.set(key, payload)

    async def get(self, key: str) -> Any | None:
        if self._redis:
            raw = await self._redis.get(key)
            if raw is None:
                return None
            try:
                return json.loads(raw)
            except Exception as exc:
                # FIX [SILENT_EXCEPTION]: log that the stored value wasn't valid
                # JSON — this usually means a plain-string value was stored, so
                # return it as-is.  But always log so corrupt data is visible.
                log.debug("redis.get.not_json", key=key, error=str(exc))
                return raw
        return None

    async def push_task(self, task_data: dict) -> None:
        if self._redis:
            await self._redis.lpush(
                self.config.redis_queue_name, json.dumps(task_data)
            )

    async def pop_task(self) -> dict | None:
        if self._redis:
            raw = await self._redis.rpop(self.config.redis_queue_name)
            if raw:
                return json.loads(raw)
        return None


# ── state_manager.py ─────────────────────────────────────────────────────
class StateManager:
    """
    Workflow state manager — persists agent/task state across runs.
    Source: State Manager concept (workflow memory in the original repo list)
    Backends: Redis (default), SQLite, in-memory dict
    """

    def __init__(self, config, redis_bus: RedisBus):
        self.config = config
        self.redis = redis_bus
        self._mem: dict[str, Any] = {}   # in-process fallback

    async def start(self) -> None:
        if self.config.state_backend == "sqlite":
            await self._init_sqlite()

    async def _init_sqlite(self) -> None:
        import aiosqlite
        self._db_path = str(self.config.state_db_path)
        async with aiosqlite.connect(self._db_path) as db:
            await db.execute(
                "CREATE TABLE IF NOT EXISTS state "
                "(key TEXT PRIMARY KEY, value TEXT, ts REAL)"
            )
            await db.commit()

    async def set(self, key: str, value: Any) -> None:
        ttl = self.config.redis_state_ttl
        if self.config.state_backend == "redis":
            await self.redis.set(key, value, ttl=ttl)
        elif self.config.state_backend == "sqlite":
            import aiosqlite, time, json
            async with aiosqlite.connect(str(self.config.state_db_path)) as db:
                await db.execute(
                    "INSERT OR REPLACE INTO state(key,value,ts) VALUES(?,?,?)",
                    (key, json.dumps(value), time.time()),
                )
                await db.commit()
        else:
            self._mem[key] = value

    async def get(self, key: str) -> Any | None:
        if self.config.state_backend == "redis":
            return await self.redis.get(key)
        elif self.config.state_backend == "sqlite":
            import aiosqlite, json
            async with aiosqlite.connect(str(self.config.state_db_path)) as db:
                async with db.execute(
                    "SELECT value FROM state WHERE key=?", (key,)
                ) as cur:
                    row = await cur.fetchone()
                    return json.loads(row[0]) if row else None
        return self._mem.get(key)
