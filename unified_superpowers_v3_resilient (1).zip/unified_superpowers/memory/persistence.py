"""
unified_superpowers/memory/persistence.py
──────────────────────────────────────────
Fix [PERSISTENCE_GOVERNANCE]

Missing pieces added:
  • Schema migration   — versioned migrations run at startup
  • Retention policy   — TTL-based eviction from Chroma + Redis
  • Memory compaction  — merge duplicate/stale embeddings
  • Consistency check  — verify Redis ↔ Chroma alignment
  • Transactional write — Redis MULTI/EXEC wrapper for atomic updates
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import structlog

log = structlog.get_logger(__name__)

SCHEMA_DIR  = Path("./data/migrations")
SCHEMA_FILE = Path("./data/schema_version.json")


# ══════════════════════════════════════════════════════════════════════════════
# 1. Schema migration
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class Migration:
    version:     int
    description: str
    up_sql:      str = ""          # for SQLite state backend
    up_fn:       Any = None        # async callable for other backends


# Built-in migration chain — extend this list as the schema evolves
MIGRATIONS: list[Migration] = [
    Migration(
        version=1,
        description="Initial schema: state table",
        up_sql=(
            "CREATE TABLE IF NOT EXISTS state "
            "(key TEXT PRIMARY KEY, value TEXT, ts REAL, ttl_s REAL);"
        ),
    ),
    Migration(
        version=2,
        description="Add task_log table for audit trail",
        up_sql=(
            "CREATE TABLE IF NOT EXISTS task_log "
            "(context_id TEXT PRIMARY KEY, task TEXT, status TEXT, "
            " tokens_used INTEGER, elapsed_ms REAL, created_at REAL);"
        ),
    ),
    Migration(
        version=3,
        description="Add plugin_state table",
        up_sql=(
            "CREATE TABLE IF NOT EXISTS plugin_state "
            "(plugin TEXT, key TEXT, value TEXT, ts REAL, "
            " PRIMARY KEY (plugin, key));"
        ),
    ),
]

CURRENT_SCHEMA_VERSION = max(m.version for m in MIGRATIONS)


class SchemaMigrator:
    """
    Runs outstanding migrations at startup.
    Safe to call multiple times — migrations are idempotent.
    """

    def __init__(self, db_path: str | Path):
        self._db_path = str(db_path)

    async def migrate(self) -> None:
        SCHEMA_DIR.mkdir(parents=True, exist_ok=True)
        current = self._read_version()
        pending = [m for m in MIGRATIONS if m.version > current]

        if not pending:
            log.debug("schema.up_to_date", version=current)
            return

        log.info("schema.migrating",
                 from_version=current,
                 to_version=CURRENT_SCHEMA_VERSION,
                 steps=len(pending))

        try:
            import aiosqlite
        except ImportError:
            log.warning("schema.aiosqlite_missing — skipping SQLite migrations")
            return

        async with aiosqlite.connect(self._db_path) as db:
            for migration in pending:
                log.info("schema.applying",
                         version=migration.version,
                         description=migration.description)
                if migration.up_sql:
                    for stmt in migration.up_sql.split(";"):
                        stmt = stmt.strip()
                        if stmt:
                            await db.execute(stmt)
                if migration.up_fn:
                    await migration.up_fn(db)
                await db.commit()

        self._write_version(CURRENT_SCHEMA_VERSION)
        log.info("schema.migration_complete", version=CURRENT_SCHEMA_VERSION)

    def _read_version(self) -> int:
        if not SCHEMA_FILE.exists():
            return 0
        try:
            return int(json.loads(SCHEMA_FILE.read_text()).get("version", 0))
        except Exception:
            return 0

    def _write_version(self, v: int) -> None:
        SCHEMA_FILE.write_text(json.dumps({"version": v, "updated_at": time.time()}))


# ══════════════════════════════════════════════════════════════════════════════
# 2. Retention policy
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class RetentionPolicy:
    """
    Declarative TTL rules for each memory tier.

    Fields
    ──────
    redis_default_ttl_s  Every Redis key written by StateManager uses this TTL.
    chroma_max_docs      Evict oldest documents once collection exceeds this count.
    chroma_max_age_s     Evict Chroma documents older than this (0 = no age limit).
    compact_interval_s   How often to run compaction (0 = manual only).
    """
    redis_default_ttl_s: int   = 86_400     # 24 h
    chroma_max_docs:     int   = 50_000
    chroma_max_age_s:    float = 0.0         # 0 = disabled
    compact_interval_s:  float = 3_600.0     # 1 h


class RetentionEnforcer:
    """
    Applies a RetentionPolicy against Chroma + Redis at intervals.
    """

    def __init__(self, policy: RetentionPolicy,
                 chroma_store, redis_bus):
        self._policy = policy
        self._chroma = chroma_store
        self._redis  = redis_bus
        self._task:  asyncio.Task | None = None

    async def start(self) -> None:
        if self._policy.compact_interval_s > 0:
            self._task = asyncio.create_task(
                self._run_loop(), name="retention_enforcer"
            )
            log.info("retention.started",
                     interval_s=self._policy.compact_interval_s)

    async def stop(self) -> None:
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass

    async def _run_loop(self) -> None:
        while True:
            await asyncio.sleep(self._policy.compact_interval_s)
            try:
                await self.enforce()
            except asyncio.CancelledError:
                break
            except Exception as exc:
                log.warning("retention.enforce_error", error=str(exc))

    async def enforce(self) -> dict:
        """Run all retention checks. Returns summary dict."""
        results = {}
        results["chroma"] = await self._enforce_chroma()
        results["redis"]  = await self._enforce_redis()
        log.info("retention.enforced", **results)
        return results

    async def _enforce_chroma(self) -> dict:
        if not self._chroma._collection:
            return {"skipped": True}
        try:
            count = self._chroma._collection.count()
            evicted = 0

            # Age-based eviction
            if self._policy.chroma_max_age_s > 0:
                cutoff = time.time() - self._policy.chroma_max_age_s
                results = self._chroma._collection.get(
                    where={"ts": {"$lt": cutoff}},
                    include=["metadatas"],
                )
                ids = results.get("ids", [])
                if ids:
                    self._chroma._collection.delete(ids=ids)
                    evicted += len(ids)
                    log.info("retention.chroma.age_evicted", count=len(ids))

            # Count-based eviction (keep newest)
            if count > self._policy.chroma_max_docs:
                over = count - self._policy.chroma_max_docs
                results = self._chroma._collection.get(
                    limit=over, include=["metadatas"],
                )
                ids = results.get("ids", [])
                if ids:
                    self._chroma._collection.delete(ids=ids)
                    evicted += len(ids)
                    log.info("retention.chroma.count_evicted", count=len(ids))

            return {"before": count, "evicted": evicted,
                    "after": count - evicted}
        except Exception as exc:
            log.warning("retention.chroma.error", error=str(exc))
            return {"error": str(exc)}

    async def _enforce_redis(self) -> dict:
        """Redis TTL is set at write-time; this verifies keys without TTL."""
        if not self._redis._redis:
            return {"skipped": True}
        try:
            # Scan for keys with no TTL (ttl = -1) and apply default
            fixed = 0
            cursor = 0
            while True:
                cursor, keys = await self._redis._redis.scan(
                    cursor, count=100
                )
                for key in keys:
                    ttl = await self._redis._redis.ttl(key)
                    if ttl == -1:   # persistent key — apply default TTL
                        await self._redis._redis.expire(
                            key, self._policy.redis_default_ttl_s
                        )
                        fixed += 1
                if cursor == 0:
                    break
            return {"ttl_applied_to": fixed}
        except Exception as exc:
            log.warning("retention.redis.error", error=str(exc))
            return {"error": str(exc)}


# ══════════════════════════════════════════════════════════════════════════════
# 3. Transactional write (Redis MULTI/EXEC)
# ══════════════════════════════════════════════════════════════════════════════

class TransactionalWriter:
    """
    Fix [SHARED_STATE_RISK] — atomic multi-key writes to Redis.

    Wraps Redis MULTI/EXEC so that updating routing metadata,
    context state, and task log in a single request is atomic.
    """

    def __init__(self, redis_bus):
        self._redis = redis_bus

    async def atomic_write(self, updates: dict[str, Any],
                           ttl_s: int = 86_400) -> bool:
        """
        Write multiple key-value pairs atomically via MULTI/EXEC.
        Returns True on success, False if transaction was aborted.

        All writes succeed or none do — prevents partial state updates
        that could leave routing metadata inconsistent with task state.
        """
        client = self._redis._redis
        if client is None:
            # In-memory fallback is inherently non-transactional but
            # single-threaded — acceptable for dev mode.
            for k, v in updates.items():
                await self._redis.set(k, v, ttl=ttl_s)
            return True

        try:
            pipe = client.pipeline(transaction=True)
            for key, value in updates.items():
                payload = json.dumps(value) if not isinstance(value, str) else value
                pipe.setex(key, ttl_s, payload)
            results = await pipe.execute()
            return all(r is not None for r in results)
        except Exception as exc:
            log.error("transactional_writer.failed", error=str(exc),
                      keys=list(updates.keys()))
            return False

    async def compare_and_swap(self, key: str,
                                expected: Any, new_value: Any,
                                ttl_s: int = 86_400) -> bool:
        """
        Optimistic CAS — only writes if current value matches `expected`.
        Uses WATCH/MULTI/EXEC for true OCC semantics.
        """
        client = self._redis._redis
        if client is None:
            current = await self._redis.get(key)
            if current != expected:
                return False
            await self._redis.set(key, new_value, ttl=ttl_s)
            return True

        try:
            async with client.pipeline(transaction=True) as pipe:
                while True:
                    try:
                        await pipe.watch(key)
                        current = await pipe.get(key)
                        if current is not None:
                            try:
                                current = json.loads(current)
                            except Exception:
                                pass
                        if current != expected:
                            await pipe.unwatch()
                            return False
                        pipe.multi()
                        payload = (json.dumps(new_value)
                                   if not isinstance(new_value, str) else new_value)
                        pipe.setex(key, ttl_s, payload)
                        await pipe.execute()
                        return True
                    except Exception:
                        # Optimistic failure — value changed during WATCH
                        continue
        except Exception as exc:
            log.error("cas.failed", key=key, error=str(exc))
            return False


# ══════════════════════════════════════════════════════════════════════════════
# 4. Consistency check — Redis ↔ Chroma alignment
# ══════════════════════════════════════════════════════════════════════════════

class ConsistencyChecker:
    """
    Detects drift between Redis (fast cache) and Chroma (vector store).

    Runs periodically or on-demand.  Reports:
      • Keys in Redis with no corresponding Chroma document
      • Chroma documents with no corresponding Redis state entry
      • Hash mismatches (content changed in one but not the other)
    """

    def __init__(self, chroma_store, redis_bus):
        self._chroma = chroma_store
        self._redis  = redis_bus

    async def check(self) -> dict:
        results = {
            "redis_only":   [],
            "chroma_only":  [],
            "hash_mismatch":[],
            "consistent":   0,
        }
        try:
            # Gather Redis keys (task state prefix)
            redis_keys: set[str] = set()
            if self._redis._redis:
                cursor = 0
                while True:
                    cursor, keys = await self._redis._redis.scan(
                        cursor, match="last_task:*", count=100
                    )
                    redis_keys.update(k.replace("last_task:", "") for k in keys)
                    if cursor == 0:
                        break

            # Gather Chroma IDs
            chroma_ids: set[str] = set()
            if self._chroma._collection:
                res = self._chroma._collection.get(include=[])
                chroma_ids.update(res.get("ids", []))

            results["redis_only"]  = list(redis_keys - chroma_ids)[:50]
            results["chroma_only"] = list(chroma_ids - redis_keys)[:50]
            results["consistent"]  = len(redis_keys & chroma_ids)

        except Exception as exc:
            results["error"] = str(exc)
            log.warning("consistency_check.failed", error=str(exc))

        log.info("consistency_check.done", **{
            k: v for k, v in results.items()
            if not isinstance(v, list) or len(v) <= 5
        })
        return results


# ══════════════════════════════════════════════════════════════════════════════
# 5. Memory compaction
# ══════════════════════════════════════════════════════════════════════════════

class MemoryCompactor:
    """
    Merge near-duplicate embeddings in Chroma to reduce storage bloat.

    Strategy:
      1. Query Chroma for documents with identical task hashes
      2. Keep the most recent; delete duplicates
      3. Log compaction stats
    """

    def __init__(self, chroma_store):
        self._chroma = chroma_store

    async def compact(self) -> dict:
        if not self._chroma._collection:
            return {"skipped": True}
        try:
            # Fetch all metadata
            all_docs = self._chroma._collection.get(include=["metadatas", "documents"])
            ids       = all_docs.get("ids", [])
            metas     = all_docs.get("metadatas", [])
            docs      = all_docs.get("documents", [])

            # Group by task hash
            seen: dict[str, tuple[str, float]] = {}   # hash → (id, ts)
            to_delete: list[str] = []

            for doc_id, meta, doc in zip(ids, metas, docs):
                task_hash = hashlib.sha256(
                    doc[:200].encode() if doc else b""
                ).hexdigest()[:16]
                ts = float(meta.get("ts", 0))

                if task_hash in seen:
                    existing_id, existing_ts = seen[task_hash]
                    if ts > existing_ts:
                        # Current is newer — delete old
                        to_delete.append(existing_id)
                        seen[task_hash] = (doc_id, ts)
                    else:
                        # Existing is newer — delete current
                        to_delete.append(doc_id)
                else:
                    seen[task_hash] = (doc_id, ts)

            if to_delete:
                self._chroma._collection.delete(ids=to_delete)
                log.info("compaction.done",
                         removed=len(to_delete),
                         remaining=len(ids) - len(to_delete))
            else:
                log.debug("compaction.nothing_to_do", total=len(ids))

            return {
                "before": len(ids),
                "removed": len(to_delete),
                "after":  len(ids) - len(to_delete),
            }
        except Exception as exc:
            log.warning("compaction.failed", error=str(exc))
            return {"error": str(exc)}
