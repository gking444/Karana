"""
unified_superpowers/server.py
──────────────────────────────
Production FastAPI server.

Endpoints
─────────
GET  /health/liveness   — Is the process alive? (no deps checked)
GET  /health/readiness  — Can we serve traffic? (checks memory, policy, obs)
GET  /health/status     — Full system status (orchestrator, HALO, obs, queue)
POST /v1/run            — Submit a task
POST /v1/cancel/{ctx_id}— Cancel an in-flight task
GET  /v1/timeline/{id}  — Get observability timeline for a trace
GET  /docs              — OpenAPI / Swagger UI (auto-generated)

Resilience
──────────
• Graceful shutdown: SIGTERM drains in-flight tasks (up to 30s)
• Request timeout: 120s hard limit per /v1/run call
• 413 on oversized payloads (> 32KB body)
• Correlation ID injected into every response header
"""

from __future__ import annotations

import asyncio
import os
import signal
import time
import uuid
from contextlib import asynccontextmanager
from typing import Any

import structlog

log = structlog.get_logger(__name__)

# ── Lazy FastAPI import ───────────────────────────────────────────────────────
try:
    from fastapi import FastAPI, HTTPException, Request, Response
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import JSONResponse
    from pydantic import BaseModel, Field, validator
    _FASTAPI_AVAILABLE = True
except ImportError:
    _FASTAPI_AVAILABLE = False
    FastAPI = None


# ── Request/Response models ───────────────────────────────────────────────────

if _FASTAPI_AVAILABLE:
    class RunRequest(BaseModel):
        task:         str  = Field(..., min_length=1, max_length=32_000,
                                  description="Natural-language task to execute")
        deadline_s:   float | None = Field(None, ge=1.0, le=600.0,
                                           description="Hard deadline in seconds")
        token_budget: int  | None  = Field(None, ge=100, le=128_000,
                                           description="Max LLM tokens for this request")
        metadata:     dict[str, Any] = Field(default_factory=dict)

        @validator("task")
        def task_not_empty(cls, v):
            if not v.strip():
                raise ValueError("task must not be blank")
            return v

    class RunResponse(BaseModel):
        result:      str
        context_id:  str
        elapsed_s:   float
        agent_role:  str
        token_pressure: float | None = None

    class HealthDetail(BaseModel):
        status:      str        # "ok" | "degraded" | "down"
        checks:      dict[str, Any]
        uptime_s:    float
        version:     str = "2.0"


# ── Global state ──────────────────────────────────────────────────────────────

_system = None          # UnifiedSuperpowers instance
_boot_time = time.monotonic()
_shutdown_event: asyncio.Event | None = None


def get_system():
    if _system is None:
        raise RuntimeError("System not initialised. Call create_app() first.")
    return _system


# ── App factory ───────────────────────────────────────────────────────────────

def create_app(system=None, config=None) -> "FastAPI | None":
    """
    Create and configure the FastAPI application.

    Parameters
    ──────────
    system  : pre-built UnifiedSuperpowers instance (for testing)
    config  : SystemConfig (used if system is None)
    """
    global _system, _shutdown_event

    if not _FASTAPI_AVAILABLE:
        log.warning("fastapi_not_installed",
                    hint="pip install fastapi uvicorn[standard]")
        return None

    _shutdown_event = asyncio.Event()

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        """Boot → serve → drain → shutdown."""
        global _system
        nonlocal system, config

        # Boot
        if system is not None:
            _system = system
        else:
            from unified_superpowers.core.system import UnifiedSuperpowers
            from unified_superpowers.core.config import SystemConfig
            _system = UnifiedSuperpowers(config or SystemConfig())

        await _system.start()
        log.info("server.ready",
                 host=_system.config.infra.api_host,
                 port=_system.config.infra.api_port)

        # Register signal handlers for graceful shutdown.
        # FIX [SIGNAL_HANDLER_MAIN_THREAD_ONLY]: add_signal_handler() calls
        # signal.set_wakeup_fd() under the hood, which raises ValueError/
        # RuntimeError when the event loop is not running on the main thread
        # of the main interpreter (e.g. under TestClient, which runs the
        # ASGI lifespan in a worker thread via anyio). Graceful-shutdown
        # signal handling is a deployment nicety for the real uvicorn/main-
        # thread case — it must never prevent the app from booting in
        # embedded or test contexts where signals aren't deliverable anyway.
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGTERM, signal.SIGINT):
            try:
                loop.add_signal_handler(sig, _trigger_shutdown)
            except (NotImplementedError, ValueError, RuntimeError) as exc:
                log.debug(
                    "server.signal_handler_unavailable",
                    signal=sig.name,
                    reason=str(exc),
                    hint="Expected under TestClient/non-main-thread embedding.",
                )

        yield   # ← serve requests here

        # Drain — by the time we're past `yield`, the ASGI server has
        # already decided to shut down (signal received, or the lifespan
        # context manager is simply exiting normally, e.g. under
        # TestClient). We give in-flight tasks a short grace window
        # to finish; we do NOT wait for `_shutdown_event` here, since
        # that event only fires on an explicit SIGTERM/SIGINT and would
        # otherwise block every *normal* shutdown for the full timeout.
        log.info("server.draining", grace_s=5.0)
        active = len(_system.orchestrator.active_contexts())
        if active:
            log.info("server.draining_active_tasks", count=active)
            await asyncio.sleep(min(5.0, 0.5 * active))

        await _system.stop()
        log.info("server.shutdown_complete")

    app = FastAPI(
        title="Unified Superpowers API",
        description=(
            "Autonomous AI agent orchestration system — 30+ repos unified. "
            "Single-authority task routing, circuit-broken LLM calls, "
            "distributed coordination, and plugin sandboxing."
        ),
        version="2.0.0",
        lifespan=lifespan,
        docs_url="/docs",
        redoc_url="/redoc",
        openapi_url="/openapi.json",
    )

    # CORS
    app.add_middleware(
        CORSMiddleware,
        allow_origins=os.getenv("CORS_ORIGINS", "http://localhost:3000").split(","),
        allow_methods=["GET", "POST", "DELETE"],
        allow_headers=["*"],
    )

    # ── Middleware: correlation ID + timing ───────────────────────────────────

    @app.middleware("http")
    async def correlation_middleware(request: Request, call_next):
        req_id = request.headers.get("X-Request-ID") or str(uuid.uuid4())[:12]
        start  = time.monotonic()

        # Reject oversized payloads (> 32 KB) before parsing
        content_length = request.headers.get("content-length", "0")
        if int(content_length) > 32 * 1024:
            return JSONResponse(
                status_code=413,
                content={"error": "Payload too large (max 32 KB).",
                         "request_id": req_id},
            )

        response = await call_next(request)
        elapsed = round(time.monotonic() - start, 4)
        response.headers["X-Request-ID"]    = req_id
        response.headers["X-Response-Time"] = str(elapsed)
        return response

    # ── Health endpoints ──────────────────────────────────────────────────────

    @app.get("/health/liveness", tags=["health"],
             summary="Liveness probe — is the process alive?")
    async def liveness():
        """
        Liveness check — answers 'is the process running?'.
        Used by Kubernetes to decide whether to restart the pod.
        Never checks external dependencies.
        """
        return {"status": "alive", "uptime_s": round(time.monotonic() - _boot_time, 1)}

    @app.get("/health/readiness", response_model=HealthDetail,
             tags=["health"],
             summary="Readiness probe — can the service accept traffic?")
    async def readiness():
        """
        Readiness check — answers 'is the service ready to serve requests?'.
        Checks: Chroma reachable, Redis reachable, policy engine operational.
        Returns 200 (ready) or 503 (not ready).
        """
        sys = get_system()
        checks: dict[str, Any] = {}

        # Chroma
        try:
            chroma_ok = sys.chroma._collection is not None
            checks["chroma"] = "ok" if chroma_ok else "degraded (in-memory fallback)"
        except Exception as exc:
            checks["chroma"] = f"error: {exc}"

        # Redis
        try:
            redis_ok = sys.redis_bus._redis is not None
            checks["redis"] = "ok" if redis_ok else "degraded (in-process fallback)"
        except Exception as exc:
            checks["redis"] = f"error: {exc}"

        # Policy engine
        try:
            await sys.policy.check("healthcheck ping", caller_key="__health__")
            checks["policy"] = "ok"
        except Exception as exc:
            checks["policy"] = f"error: {exc}"

        # Observability
        checks["observability"] = "ok" if sys.obs._running else "stopped"

        # Overall
        down = [k for k, v in checks.items() if isinstance(v, str) and "error" in v]
        status = "down" if down else "ok"
        code   = 503 if down else 200

        detail = HealthDetail(
            status=status,
            checks=checks,
            uptime_s=round(time.monotonic() - _boot_time, 1),
        )
        return JSONResponse(status_code=code, content=detail.dict())

    @app.get("/health/status", tags=["health"],
             summary="Full system status — orchestrator, HALO, queue pressure")
    async def status():
        """Full live system snapshot including queue pressure and HALO OS metrics."""
        return get_system().status()

    # ── Task endpoints ────────────────────────────────────────────────────────

    @app.post("/v1/run", response_model=RunResponse, tags=["tasks"],
              summary="Submit a task to the agent system")
    async def run_task(req: RunRequest, request: Request):
        """
        Submit a natural-language task.

        The system routes to the best agent (lightning/hermes/openhands/picoclaw/goose),
        applies the FeedbackLoop post-processor, and returns the result.

        Respects X-Request-ID header for distributed tracing.
        """
        sys     = get_system()
        req_id  = request.headers.get("X-Request-ID") or str(uuid.uuid4())[:12]

        try:
            result = await asyncio.wait_for(
                sys.run(
                    req.task,
                    context={**req.metadata, "request_id": req_id},
                    deadline_s=req.deadline_s,
                    token_budget=req.token_budget,
                ),
                timeout=120.0,
            )
        except asyncio.TimeoutError:
            raise HTTPException(
                status_code=504,
                detail="Task timed out after 120s. Use a shorter task or increase deadline.",
            )
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc))
        except RuntimeError as exc:
            # Circuit open, queue full, etc.
            raise HTTPException(status_code=503, detail=str(exc))

        return RunResponse(
            result      =result["result"],
            context_id  =req_id,
            elapsed_s   =result["elapsed_s"],
            agent_role  =result["routing"].primary.value,
        )

    @app.post("/v1/cancel/{context_id}", tags=["tasks"],
              summary="Cancel an in-flight task")
    async def cancel_task(context_id: str):
        """Cancel a running task by its correlation ID."""
        ok = await get_system().cancel(context_id)
        if not ok:
            raise HTTPException(status_code=404,
                                detail=f"Context '{context_id}' not found or already done.")
        return {"cancelled": True, "context_id": context_id}

    @app.get("/v1/timeline/{trace_id}", tags=["observability"],
             summary="Get execution timeline for a trace")
    async def get_timeline(trace_id: str):
        """
        Returns all OTel-compatible spans for a trace, sorted chronologically.
        Useful for debugging slow tasks or understanding agent dispatch order.
        """
        spans = get_system().obs.get_timeline(trace_id)
        if not spans:
            raise HTTPException(status_code=404,
                                detail=f"No spans found for trace '{trace_id}'.")
        return {
            "trace_id": trace_id,
            "span_count": len(spans),
            "spans": spans,
        }

    return app


# ── Shutdown helpers ──────────────────────────────────────────────────────────

def _trigger_shutdown():
    global _shutdown_event
    log.info("server.shutdown_signal_received")
    if _shutdown_event:
        _shutdown_event.set()


async def _wait_for_shutdown_signal_debug():
    """
    Debug helper — not used in the drain path (see lifespan() comment).
    Kept for manual testing of signal-triggered shutdown behavior.
    """
    if _shutdown_event:
        await _shutdown_event.wait()


# ── Entrypoint ────────────────────────────────────────────────────────────────

def main():
    try:
        import uvicorn
    except ImportError:
        print("uvicorn not installed. Run: pip install uvicorn[standard]")
        return

    from unified_superpowers.core.config import SystemConfig
    cfg = SystemConfig()
    app = create_app(config=cfg)
    if app is None:
        print("FastAPI not available. Run: pip install fastapi uvicorn[standard]")
        return

    uvicorn.run(
        app,
        host=cfg.infra.api_host,
        port=cfg.infra.api_port,
        log_level=cfg.observability.log_level.lower(),
        access_log=True,
        timeout_graceful_shutdown=30,
    )


if __name__ == "__main__":
    main()
