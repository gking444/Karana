"""
unified_superpowers/workflow/deepflow.py — DeepFlow 2.0 + Ruflow
"""
from __future__ import annotations
import structlog
log = structlog.get_logger(__name__)

class DeepFlowEngine:
    def __init__(self, config): self.config = config
    async def schedule_workflow(self, name: str, task: str, cron: str) -> str:
        log.info("deepflow.schedule", name=name, cron=cron)
        try:
            from prefect import flow
            from prefect.deployments import Deployment
            @flow(name=name)
            def dynamic_flow(): return task
            d = Deployment.build_from_flow(flow=dynamic_flow, name=f"{name}-deployment", schedule={"cron": cron})
            d.apply()
            return f"Workflow '{name}' scheduled: {cron}"
        except ImportError:
            return f"Prefect not available — workflow '{name}' registered locally."
        except Exception as exc:
            return f"DeepFlow error: {exc}"
    async def run_now(self, name, task_fn, *args, **kwargs):
        from tenacity import retry, stop_after_attempt, wait_exponential
        @retry(stop=stop_after_attempt(3), wait=wait_exponential(min=1, max=10))
        async def _run(): return await task_fn(*args, **kwargs)
        return await _run()
