"""
unified_superpowers/workflow/crewai_engine.py  — CrewAI multi-agent crew
unified_superpowers/workflow/deepflow.py       — DeepFlow 2.0 / Prefect
unified_superpowers/workflow/feedback_loop.py  — Self-correction loop
"""

# ── crewai_engine.py ──────────────────────────────────────────────────────
from __future__ import annotations
import structlog
log = structlog.get_logger(__name__)


class CrewAIEngine:
    """
    CrewAI orchestration — role-playing autonomous agent crews.
    Source: github.com/crewAIInc/crewAI
    """

    def __init__(self, config):
        self.config = config

    async def run(self, task: str, plan: str = "") -> str:
        log.info("crewai.run", task=task[:80])
        try:
            from crewai import Agent, Task, Crew, Process
            from langchain_anthropic import ChatAnthropic

            intel = self.config.intelligence
            llm = ChatAnthropic(
                model=intel.primary_model,
                anthropic_api_key=intel.anthropic_api_key,
            )

            planner = Agent(
                role="Strategic Planner",
                goal="Break complex tasks into achievable steps",
                backstory="You are a master strategist with deep expertise in AI systems.",
                llm=llm, verbose=False,
            )
            executor = Agent(
                role="Task Executor",
                goal="Execute tasks precisely and efficiently",
                backstory="You are a meticulous executor who delivers high-quality results.",
                llm=llm, verbose=False,
            )
            reviewer = Agent(
                role="Quality Reviewer",
                goal="Ensure output meets requirements and is accurate",
                backstory="You are a rigorous reviewer who catches errors and improves quality.",
                llm=llm, verbose=False,
            )

            t_plan   = Task(description=f"Plan execution for: {task}\nExisting plan hint: {plan}",
                            agent=planner, expected_output="Step-by-step execution plan")
            t_exec   = Task(description=f"Execute: {task}",
                            agent=executor, expected_output="Completed task output",
                            context=[t_plan])
            t_review = Task(description="Review and improve the output",
                            agent=reviewer, expected_output="Final polished result",
                            context=[t_exec])

            crew = Crew(
                agents=[planner, executor, reviewer],
                tasks=[t_plan, t_exec, t_review],
                process=Process.sequential,
                verbose=False,
            )
            result = crew.kickoff()
            return str(result)

        except ImportError:
            log.warning("crewai.not_installed")
            return f"CrewAI not available — task queued: {task}"
        except Exception as exc:
            log.error("crewai.run_failed", error=str(exc))
            return f"CrewAI error: {exc}"


# ── deepflow.py ───────────────────────────────────────────────────────────
class DeepFlowEngine:
    """
    DeepFlow 2.0 / Ruflow — workflow automation engine.
    Source: DeepFlow 2.0 + Ruflow (workflow automation)
    Uses Prefect for scheduling, retries, and observability.
    """

    def __init__(self, config):
        self.config = config

    async def schedule_workflow(self, name: str, task: str, cron: str) -> str:
        log.info("deepflow.schedule", name=name, cron=cron)
        try:
            from prefect import flow, task as ptask
            from prefect.deployments import Deployment

            @flow(name=name)
            def dynamic_flow():
                return task

            deployment = Deployment.build_from_flow(
                flow=dynamic_flow,
                name=f"{name}-deployment",
                schedule={"cron": cron},
            )
            deployment.apply()
            return f"Workflow '{name}' scheduled: {cron}"
        except ImportError:
            return f"Prefect not available — workflow '{name}' registered locally."
        except Exception as exc:
            return f"DeepFlow schedule error: {exc}"

    async def run_now(self, name: str, task_fn, *args, **kwargs):
        """Run a task immediately with retry logic."""
        import asyncio
        from tenacity import retry, stop_after_attempt, wait_exponential

        @retry(stop=stop_after_attempt(3), wait=wait_exponential(min=1, max=10))
        async def _run():
            return await task_fn(*args, **kwargs)

        return await _run()


# ── feedback_loop.py ──────────────────────────────────────────────────────
class FeedbackLoop:
    """
    Self-correction loop — evaluates output quality and iterates.
    Source: Feedback Loop repo concept

    Algorithm:
      1. Score the output (LLM-as-judge)
      2. If score < threshold → generate critique
      3. Re-run with critique as context
      4. Repeat up to max_rounds
    """

    JUDGE_PROMPT = """\
You are a quality judge. Score this task output from 0.0 to 1.0.
Task: {task}
Output: {output}

Respond with JSON only: {{"score": 0.0, "critique": "..."}}
"""

    def __init__(self, workflow_config, hermes_agent):
        self.config = workflow_config
        self.hermes = hermes_agent

    async def evaluate_and_correct(self, task: str, output: str) -> str:
        if not self.config.enable_self_correction:
            return output

        import json as _json
        current = output

        for round_n in range(self.config.max_correction_rounds):
            # Judge
            judge_prompt = self.JUDGE_PROMPT.format(task=task, output=current)
            raw = await self.hermes.run(judge_prompt)
            try:
                clean = raw.strip().lstrip("```json").rstrip("```").strip()
                data = _json.loads(clean)
                score = float(data.get("score", 1.0))
                critique = data.get("critique", "")
            except Exception:
                break   # can't parse → accept current output

            log.info("feedback_loop.scored", round=round_n+1,
                     score=score, critique=critique[:80])

            if score >= 0.85:
                break

            # Correct
            correction_prompt = (
                f"Improve the following output based on this critique.\n\n"
                f"Original task: {task}\n\n"
                f"Previous output:\n{current}\n\n"
                f"Critique: {critique}\n\n"
                f"Provide an improved version:"
            )
            current = await self.hermes.run(correction_prompt)

        return current
