"""
unified_superpowers/workflow/langgraph_engine.py
──────────────────────────────────────────────────
LangGraph decision graph — core orchestration.
Source: github.com/langchain-ai/langgraph

Builds a stateful multi-actor graph:
  START → route → [lightning | openhands | picoclaw | hermes] → synthesise → END
"""
from __future__ import annotations
from typing import Any, TypedDict
import structlog
log = structlog.get_logger(__name__)


class GraphState(TypedDict):
    task: str
    routing: Any
    context: dict
    agent_result: str
    final_answer: str


class LangGraphEngine:
    """Wraps LangGraph StateGraph for complex multi-step orchestration."""

    def __init__(self, config, agents: dict):
        self.config = config
        self.agents = agents
        self._graph = None

    def _build(self):
        from langgraph.graph import StateGraph, END, START

        g = StateGraph(GraphState)

        async def route_node(state: GraphState):
            return state  # routing already done upstream

        async def execute_node(state: GraphState):
            from unified_superpowers.core.task_router import AgentRole
            role = state["routing"].primary
            agent = self.agents.get(role)
            if agent:
                result = await agent.run(state["task"], context=state["context"])
            else:
                result = "No agent found for role: " + str(role)
            return {**state, "agent_result": result}

        async def synthesise_node(state: GraphState):
            return {**state, "final_answer": state["agent_result"]}

        g.add_node("route",      route_node)
        g.add_node("execute",    execute_node)
        g.add_node("synthesise", synthesise_node)

        g.add_edge(START,        "route")
        g.add_edge("route",      "execute")
        g.add_edge("execute",    "synthesise")
        g.add_edge("synthesise", END)

        return g.compile()

    async def run(self, task: str, decision, context: dict) -> str:
        try:
            if self._graph is None:
                self._graph = self._build()
            state: GraphState = {
                "task": task, "routing": decision,
                "context": context, "agent_result": "", "final_answer": "",
            }
            result = await self._graph.ainvoke(state)
            return result["final_answer"]
        except Exception as exc:
            log.warning("langgraph.run_failed", error=str(exc))
            raise
