"""
unified_superpowers/workflow/feedback_loop.py — Self-correction loop
"""
from __future__ import annotations
import structlog
log = structlog.get_logger(__name__)

class FeedbackLoop:
    JUDGE_PROMPT = """You are a quality judge. Score this task output 0.0-1.0.\nTask: {task}\nOutput: {output}\nRespond with JSON only: {{"score": 0.0, "critique": "..."}}"""
    def __init__(self, workflow_config, hermes_agent):
        self.config = workflow_config
        self.hermes = hermes_agent
    async def evaluate_and_correct(self, task: str, output: str) -> str:
        if not self.config.enable_self_correction:
            return output
        import json as _json
        current = output
        for round_n in range(self.config.max_correction_rounds):
            raw = await self.hermes.run(self.JUDGE_PROMPT.format(task=task, output=current))
            try:
                clean = raw.strip().lstrip("```json").rstrip("```").strip()
                data = _json.loads(clean)
                score = float(data.get("score", 1.0))
                critique = data.get("critique", "")
            except Exception:
                break
            log.info("feedback_loop.scored", round=round_n+1, score=score)
            if score >= 0.85:
                break
            current = await self.hermes.run(
                f"Improve based on critique.\nTask: {task}\nOutput:\n{current}\nCritique: {critique}\nImproved version:"
            )
        return current
