"""
unified_superpowers/core/task_router.py
───────────────────────────────────────
Task Router / Decision Engine
  Combines rule-based heuristics with an LLM classifier to decide
  which agent(s) should handle each incoming task.

Mapped repos:
  • Task Router  — original decision-engine concept
  • Lightning Agent — fast executor path (simple/short tasks)
  • Goose        — lightweight worker path
  • OpenHands    — coding / dev execution
  • PicoClaw     — UI / desktop automation
  • UI-TARS      — UI agent
  • Hermes       — reasoning / complex tasks
"""

from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
import structlog

_log = structlog.get_logger(__name__)
from typing import Any


class AgentRole(str, Enum):
    LIGHTNING  = "lightning"    # LightningAgent  — fast, stateless, <30 s
    GOOSE      = "goose"        # Goose           — lightweight background worker
    OPENHANDS  = "openhands"    # OpenHands       — coding & file manipulation
    PICOCLAW   = "picoclaw"     # PicoClaw/UI-TARS — desktop UI control
    HERMES     = "hermes"       # Hermes          — deep reasoning
    ORCHESTRATOR = "orchestrator"  # full multi-agent crew


@dataclass
class RoutingDecision:
    primary: AgentRole
    fallback: AgentRole | None = None
    requires_vision: bool = False
    requires_code: bool = False
    requires_ui: bool = False
    complexity: float = 0.5         # 0 – 1
    estimated_duration_s: int = 10
    metadata: dict[str, Any] = field(default_factory=dict)


# ── Keyword heuristics (rule-based, zero-latency) ────────────────────────────

_UI_KEYWORDS    = {"click", "type", "scroll", "screenshot", "window", "desktop",
                   "browser", "button", "form", "drag", "hover", "open app"}
_CODE_KEYWORDS  = {"code", "python", "javascript", "debug", "fix bug", "write a script",
                   "repository", "git", "npm", "pip", "dockerfile", "sql", "refactor"}
_FAST_KEYWORDS  = {"what is", "define", "summarize", "translate", "convert",
                   "calculate", "math", "quick", "simple", "short"}
_REASON_KEYWORDS= {"analyze", "plan", "strategy", "compare", "evaluate", "design",
                   "architecture", "research", "think through", "best approach"}


def _keyword_route(task: str) -> RoutingDecision | None:
    t = task.lower()
    if any(k in t for k in _UI_KEYWORDS):
        return RoutingDecision(
            primary=AgentRole.PICOCLAW,
            requires_vision=True, requires_ui=True, complexity=0.5,
        )
    if any(k in t for k in _CODE_KEYWORDS):
        return RoutingDecision(
            primary=AgentRole.OPENHANDS,
            requires_code=True, complexity=0.6,
        )
    if any(k in t for k in _FAST_KEYWORDS):
        return RoutingDecision(
            primary=AgentRole.LIGHTNING,
            complexity=0.2, estimated_duration_s=5,
        )
    if any(k in t for k in _REASON_KEYWORDS):
        return RoutingDecision(
            primary=AgentRole.HERMES,
            complexity=0.8, estimated_duration_s=60,
        )
    return None


# ── LLM-based classifier (used when heuristics are ambiguous) ─────────────

_CLASSIFIER_PROMPT = """\
You are a task router for an autonomous AI system. 
Classify the following task into exactly ONE agent role from this list:
  lightning  – simple, fast, single-step tasks (< 30 s)
  goose      – lightweight background or scheduled tasks
  openhands  – any coding, scripting, file editing, or dev task
  picoclaw   – UI/desktop automation, clicking, typing, screenshots
  hermes     – complex reasoning, planning, research, analysis
  orchestrator – multi-step tasks that need several agents together

Respond with a single JSON object:
{
  "primary": "<role>",
  "complexity": <0.0-1.0>,
  "requires_vision": <true|false>,
  "requires_code": <true|false>,
  "requires_ui": <true|false>,
  "estimated_duration_s": <integer>
}

Task: {task}
"""


async def llm_route(task: str, llm_call_fn) -> RoutingDecision:
    """
    Call the LLM to classify the task when rules don't match.
    `llm_call_fn` accepts a prompt string and returns a string response.
    """
    import json
    prompt = _CLASSIFIER_PROMPT.format(task=task)
    raw = await llm_call_fn(prompt)
    try:
        data = json.loads(raw)
        return RoutingDecision(
            primary=AgentRole(data.get("primary", "hermes")),
            complexity=float(data.get("complexity", 0.5)),
            requires_vision=bool(data.get("requires_vision", False)),
            requires_code=bool(data.get("requires_code", False)),
            requires_ui=bool(data.get("requires_ui", False)),
            estimated_duration_s=int(data.get("estimated_duration_s", 30)),
        )
    except Exception as exc:
        # FIX [SILENT_EXCEPTION]: always log routing parse failures;
        # they indicate LLM returned malformed JSON — worth auditing.
        _log.warning("llm_route.parse_failed", error=str(exc), raw_preview=raw[:120])
        return RoutingDecision(primary=AgentRole.HERMES, complexity=0.7)


class TaskRouter:
    """
    Unified Task Router.
    mode = "rules"  → heuristics only (zero latency)
    mode = "llm"    → always call LLM classifier
    mode = "hybrid" → heuristics first, LLM fallback
    """

    def __init__(self, mode: str = "hybrid", llm_call_fn=None):
        self.mode = mode
        self.llm_call_fn = llm_call_fn

    async def route(self, task: str) -> RoutingDecision:
        if self.mode == "rules":
            return _keyword_route(task) or RoutingDecision(primary=AgentRole.HERMES)
        if self.mode == "llm" and self.llm_call_fn:
            return await llm_route(task, self.llm_call_fn)
        # hybrid
        decision = _keyword_route(task)
        if decision:
            return decision
        if self.llm_call_fn:
            return await llm_route(task, self.llm_call_fn)
        return RoutingDecision(primary=AgentRole.HERMES, complexity=0.6)
