"""
unified_superpowers/core/execution_context.py
──────────────────────────────────────────────
ExecutionContext  — the single source of truth for every running task.

Fixes:
  [AMBIGUOUS_AUTHORITY]   One context object owns the task lifecycle.
  [NO_CANCELLATION_MODEL] Context.cancel() propagates to all children.
  [NO_CORRELATION_IDS]    context_id flows through every log / span.
  [SHARED_STATE_RISK]     Immutable after creation; only status is mutable
                          under a lock.
  [NO_BACKPRESSURE]       Context carries a token budget and deadline.

Every agent call, LangGraph step, CrewAI kickoff, and DeepFlow run receives
the same ExecutionContext.  Nothing starts work without one.
"""

from __future__ import annotations

import asyncio
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

import structlog

log = structlog.get_logger(__name__)


class ContextStatus(str, Enum):
    PENDING   = "pending"
    RUNNING   = "running"
    DONE      = "done"
    CANCELLED = "cancelled"
    FAILED    = "failed"


@dataclass
class ExecutionContext:
    """
    Immutable execution envelope.  Created once per top-level task; passed
    down through every layer.  Children inherit the cancel token so that
    context.cancel() cascades to all in-flight work.

    Fields
    ──────
    context_id      Correlation ID — appears in every log line and OTEL span.
    parent_id       For sub-tasks; enables distributed trace trees.
    task            Original task string (read-only after creation).
    routing         RoutingDecision attached after router runs.
    deadline_at     Absolute monotonic time limit.  None = no deadline.
    token_budget    Max LLM tokens this context may consume.
    tokens_used     Running total (updated via consume_tokens()).
    cancel_event    asyncio.Event set by cancel().  All awaiters watch this.
    _children       Child contexts for sub-task fan-out.
    _lock           Guards status + tokens_used mutations.
    """

    # ── Identity ──────────────────────────────────────────────────────────────
    context_id:  str = field(default_factory=lambda: str(uuid.uuid4())[:12])
    parent_id:   str | None = None
    task:        str = ""
    metadata:    dict[str, Any] = field(default_factory=dict)

    # ── Lifecycle ─────────────────────────────────────────────────────────────
    status:      ContextStatus = ContextStatus.PENDING
    created_at:  float = field(default_factory=time.monotonic)
    started_at:  float | None = None
    finished_at: float | None = None

    # ── Backpressure / resource limits ───────────────────────────────────────
    deadline_at:    float | None = None   # monotonic; None = unlimited
    token_budget:   int = 32_000          # max LLM tokens for this context
    tokens_used:    int = 0

    # ── Cancellation ─────────────────────────────────────────────────────────
    # Created lazily inside the first async call (correct event loop)
    _cancel_event:  asyncio.Event | None = field(default=None, repr=False)
    _children:      list["ExecutionContext"] = field(default_factory=list, repr=False)
    _lock:          asyncio.Lock | None = field(default=None, repr=False)

    # ── Routing metadata (attached after TaskRouter runs) ────────────────────
    routing:        Any = field(default=None, repr=False)  # RoutingDecision

    def __post_init__(self):
        # DO NOT create asyncio primitives here — we are in sync __init__.
        # They are created lazily via _ensure_async_primitives().
        pass

    # ── Primitive lazy-init ───────────────────────────────────────────────────

    def _ensure_async_primitives(self) -> None:
        """Must be called at the top of every async method."""
        if self._cancel_event is None:
            self._cancel_event = asyncio.Event()
        if self._lock is None:
            self._lock = asyncio.Lock()

    # ── Cancellation API ─────────────────────────────────────────────────────

    async def cancel(self, reason: str = "requested") -> None:
        """
        Cancel this context AND all child contexts.

        Propagation model:
          parent.cancel() → sets parent._cancel_event
                          → iterates _children → child.cancel()
          All coroutines that do `await ctx.wait_cancelled()` unblock.
        """
        self._ensure_async_primitives()
        async with self._lock:
            if self.status in (ContextStatus.DONE, ContextStatus.FAILED):
                return  # already terminal — cancel is a no-op
            self.status = ContextStatus.CANCELLED
            self.finished_at = time.monotonic()

        self._cancel_event.set()
        log.info("context.cancelled", context_id=self.context_id, reason=reason)

        # Propagate to children
        for child in list(self._children):
            await child.cancel(reason=f"parent:{reason}")

    @property
    def is_cancelled(self) -> bool:
        return (
            self.status == ContextStatus.CANCELLED
            or (self._cancel_event is not None and self._cancel_event.is_set())
        )

    async def wait_cancelled(self) -> None:
        """Await this to block until the context is cancelled."""
        self._ensure_async_primitives()
        await self._cancel_event.wait()

    def check_cancelled(self) -> None:
        """Sync check — raises asyncio.CancelledError if context is cancelled."""
        if self.is_cancelled:
            raise asyncio.CancelledError(
                f"ExecutionContext {self.context_id} was cancelled"
            )

    # ── Deadline ──────────────────────────────────────────────────────────────

    @property
    def is_expired(self) -> bool:
        if self.deadline_at is None:
            return False
        return time.monotonic() > self.deadline_at

    def check_deadline(self) -> None:
        """Raises TimeoutError if the deadline has passed."""
        if self.is_expired:
            raise TimeoutError(
                f"Context {self.context_id} deadline exceeded "
                f"(+{time.monotonic() - self.deadline_at:.2f}s overdue)"
            )

    def remaining_seconds(self) -> float | None:
        if self.deadline_at is None:
            return None
        return max(0.0, self.deadline_at - time.monotonic())

    # ── Token backpressure ────────────────────────────────────────────────────

    async def consume_tokens(self, n: int) -> None:
        """
        Reserve n tokens against this context's budget.
        Raises ResourceWarning if the budget would be exceeded.
        """
        self._ensure_async_primitives()
        async with self._lock:
            projected = self.tokens_used + n
            if projected > self.token_budget:
                raise ResourceWarning(
                    f"Token budget exhausted: {self.tokens_used}/{self.token_budget} "
                    f"(tried to add {n}). Context: {self.context_id}"
                )
            self.tokens_used = projected

    @property
    def token_pressure(self) -> float:
        """0.0 = empty, 1.0 = full."""
        if self.token_budget == 0:
            return 1.0
        return self.tokens_used / self.token_budget

    # ── Child context (sub-task fan-out) ─────────────────────────────────────

    def spawn_child(self, sub_task: str,
                    token_budget: int | None = None,
                    deadline_at: float | None = None) -> "ExecutionContext":
        """
        Create a child context for a sub-task.
        Child inherits parent deadline (whichever is sooner) and
        a fraction of the token budget.
        """
        child = ExecutionContext(
            parent_id=self.context_id,
            task=sub_task,
            # Child deadline: min(parent_deadline, explicit_deadline)
            deadline_at=min(
                filter(None, [self.deadline_at, deadline_at]),
                default=None,
            ),
            # Child budget: explicit or half of parent remainder
            token_budget=token_budget or max(
                1000, (self.token_budget - self.tokens_used) // 2
            ),
            metadata={**self.metadata, "parent_task": self.task[:60]},
        )
        self._children.append(child)
        return child

    # ── Lifecycle transitions ─────────────────────────────────────────────────

    async def mark_running(self) -> None:
        self._ensure_async_primitives()
        async with self._lock:
            self.status = ContextStatus.RUNNING
            self.started_at = time.monotonic()

    async def mark_done(self) -> None:
        self._ensure_async_primitives()
        async with self._lock:
            if self.status == ContextStatus.RUNNING:
                self.status = ContextStatus.DONE
                self.finished_at = time.monotonic()

    async def mark_failed(self, error: str) -> None:
        self._ensure_async_primitives()
        async with self._lock:
            self.status = ContextStatus.FAILED
            self.finished_at = time.monotonic()
            self.metadata["error"] = error

    # ── Structured log binding ────────────────────────────────────────────────

    def bind_log(self) -> structlog.BoundLogger:
        """Return a logger pre-bound with this context's correlation ID."""
        return log.bind(
            context_id=self.context_id,
            parent_id=self.parent_id,
            task_preview=self.task[:60],
        )

    # ── Serialisation ─────────────────────────────────────────────────────────

    def to_dict(self) -> dict:
        return {
            "context_id":  self.context_id,
            "parent_id":   self.parent_id,
            "task":        self.task[:200],
            "status":      self.status.value,
            "created_at":  self.created_at,
            "started_at":  self.started_at,
            "finished_at": self.finished_at,
            "token_budget":self.token_budget,
            "tokens_used": self.tokens_used,
            "token_pressure": round(self.token_pressure, 3),
            "deadline_at": self.deadline_at,
            "remaining_s": self.remaining_seconds(),
            "children":    len(self._children),
        }

    def __repr__(self) -> str:
        return (
            f"ExecutionContext(id={self.context_id}, "
            f"status={self.status.value}, "
            f"tokens={self.tokens_used}/{self.token_budget})"
        )
