"""
unified_superpowers/core/system.py
───────────────────────────────────
UnifiedSuperpowers — top-level facade.

Architecture after refactor
────────────────────────────
  1. ONE orchestration authority  → Orchestrator (core/orchestrator.py)
  2. CLEAR layer contracts        → Runtime/Strategy/Batch/Middleware
  3. Global cancellation          → ExecutionContext.cancel() + cancel_all()
  4. Backpressure                 → BoundedTaskQueue inside Orchestrator
  5. Distributed coordination     → DistributedLock + LeaderElection + WorkerLease
  6. Plugin isolation             → PluginManager(PluginSandbox)
  7. Observability pipeline       → ObservabilityCollector
  8. Persistence governance       → SchemaMigrator + RetentionEnforcer + Compactor
  9. HALO OS kernel               → wraps all agent execution

Nothing in this file duplicates orchestration logic.
UnifiedSuperpowers only:
  • wires components together
  • manages boot/shutdown order
  • exposes a clean public API (run, stream, cancel, status)
"""

from __future__ import annotations

import asyncio
import time
from typing import Any, AsyncIterator

import structlog

from unified_superpowers.core.config import SystemConfig
from unified_superpowers.core.execution_context import ExecutionContext
from unified_superpowers.core.orchestrator import (
    Orchestrator,
    LangGraphRuntimeAdapter,
    CrewAIStrategyAdapter,
    DeepFlowBatchAdapter,
    FeedbackLoopMiddlewareAdapter,
)
from unified_superpowers.core.task_router import TaskRouter, AgentRole

from unified_superpowers.agents.halo_os import HALO_OS, TaskPriority
from unified_superpowers.agents.lightning_agent import LightningAgent
from unified_superpowers.agents.goose_agent import GooseAgent
from unified_superpowers.agents.openhands_adapter import OpenHandsAdapter
from unified_superpowers.agents.picoclaw_agent import PicoClawAgent
from unified_superpowers.agents.hermes_agent import HermesAgent

from unified_superpowers.memory.chroma_store import ChromaStore
from unified_superpowers.memory.redis_bus import RedisBus, StateManager
from unified_superpowers.memory.persistence import (
    SchemaMigrator,
    RetentionPolicy,
    RetentionEnforcer,
    TransactionalWriter,
    ConsistencyChecker,
    MemoryCompactor,
)

from unified_superpowers.workflow.langgraph_engine import LangGraphEngine
from unified_superpowers.workflow.crewai_engine import CrewAIEngine
from unified_superpowers.workflow.deepflow import DeepFlowEngine
from unified_superpowers.workflow.feedback_loop import FeedbackLoop

from unified_superpowers.vision.vaxil import VaxilVision
from unified_superpowers.infra.sandbox import DockerSandbox
from unified_superpowers.infra.policy_engine import PolicyEngine
from unified_superpowers.infra.distributed import (
    DistributedLock,
    LeaderElection,
    WorkerLease,
)

from unified_superpowers.plugins.plugin_sandbox import PluginManager
from unified_superpowers.utils.observability import setup_observability
from unified_superpowers.utils.observability_pipeline import ObservabilityCollector
from unified_superpowers.utils.graphify import Graphify


class UnifiedSuperpowers:
    """
    Top-level facade — wires and boots all subsystems.

    Public API
    ──────────
      run(task)           → execute a task, returns result dict
      stream(task)        → async token stream from Hermes
      cancel(context_id)  → cancel one in-flight task
      cancel_all()        → graceful shutdown of all tasks
      status()            → live system health snapshot
    """

    def __init__(self, config: SystemConfig | None = None):
        self.config = config or SystemConfig()
        self.config.apply_to_environment()
        setup_observability(self.config.observability)
        self._log = structlog.get_logger("superpowers.system")

        # ── Memory ────────────────────────────────────────────────────────
        self.chroma      = ChromaStore(self.config.memory)
        self.redis_bus   = RedisBus(self.config.memory)
        self.state_mgr   = StateManager(self.config.memory, self.redis_bus)
        self.tx_writer   = TransactionalWriter(self.redis_bus)

        # ── Persistence governance ────────────────────────────────────────
        self.migrator    = SchemaMigrator(self.config.memory.state_db_path)
        self.retention   = RetentionEnforcer(
            RetentionPolicy(
                redis_default_ttl_s=self.config.memory.redis_state_ttl,
            ),
            self.chroma, self.redis_bus,
        )
        self.compactor   = MemoryCompactor(self.chroma)
        self.consistency = ConsistencyChecker(self.chroma, self.redis_bus)

        # ── Safety ────────────────────────────────────────────────────────
        self.policy      = PolicyEngine(self.config.policy)

        # ── Observability pipeline ────────────────────────────────────────
        self.obs         = ObservabilityCollector(
            langsmith_project=self.config.observability.langsmith_project,
            langsmith_api_key=self.config.observability.langsmith_api_key,
        )

        # ── Distributed coordination ──────────────────────────────────────
        self.leader      = LeaderElection(self.redis_bus, role="orchestrator")
        self.lease       = WorkerLease(self.redis_bus)

        # ── Agents ────────────────────────────────────────────────────────
        self.lightning   = LightningAgent(self.config)
        self.goose       = GooseAgent(self.config)
        self.openhands   = OpenHandsAdapter(self.config)
        self.picoclaw    = PicoClawAgent(self.config)
        self.hermes      = HermesAgent(self.config)

        self._agents = {
            AgentRole.LIGHTNING:  self.lightning,
            AgentRole.GOOSE:      self.goose,
            AgentRole.OPENHANDS:  self.openhands,
            AgentRole.PICOCLAW:   self.picoclaw,
            AgentRole.HERMES:     self.hermes,
        }

        # ── HALO OS kernel — wraps all agent execution ────────────────────
        self.halo_os     = HALO_OS(self.config)

        # ── Workflow engines (used by layer adapters — not direct orchestrators) ─
        self._langgraph  = LangGraphEngine(self.config, self._agents)
        self._crewai     = CrewAIEngine(self.config)
        self._deepflow   = DeepFlowEngine(self.config)
        self._feedback   = FeedbackLoop(self.config.workflow, self.hermes)

        # ── THE single orchestration authority ────────────────────────────
        self.orchestrator = Orchestrator(
            agents=self._agents,
            runtime=LangGraphRuntimeAdapter(self._langgraph),
            strategy=CrewAIStrategyAdapter(self.hermes),
            batch=DeepFlowBatchAdapter(self._deepflow, self.redis_bus),
            middleware=FeedbackLoopMiddlewareAdapter(self._feedback),
            memory_write=self._persist,
            queue_maxsize=int(
                __import__("os").getenv("WORKFLOW_QUEUE_MAXSIZE", "256")
            ),
            default_token_budget=self.config.intelligence.deep_reasoning_threshold and 32_000,
        )

        # ── Task router ───────────────────────────────────────────────────
        self.router      = TaskRouter(
            mode=self.config.workflow.router_mode,
            llm_call_fn=self.lightning.raw_llm,
        )

        # ── Vision / Infra / Extensions ───────────────────────────────────
        self.vision      = VaxilVision(self.config.ui_vision)
        self.sandbox     = DockerSandbox(self.config.infra)
        self.plugins     = PluginManager(self.config.plugin_dirs)
        self.graphify    = Graphify()

    # ── Lifecycle ──────────────────────────────────────────────────────────

    async def start(self) -> None:
        self._log.info("boot.start")

        # 1. Schema migration (idempotent)
        await self.migrator.migrate()

        # 2. Memory
        await self.chroma.connect()
        await self.redis_bus.connect()
        await self.state_mgr.start()

        # 3. Observability pipeline
        await self.obs.start()

        # 4. Distributed coordination
        await self.leader.start()
        await self.lease.start()

        # 5. Retention background task
        await self.retention.start()

        # 6. Infra
        await self.sandbox.pull_image()

        # 7. Plugins (sandboxed)
        await self.plugins.discover_and_load()

        self._log.info(
            "boot.ready",
            agent_roles=[r.value for r in self._agents],
            is_leader=self.leader.is_leader,
            plugins=self.plugins.list_plugins(),
        )

    async def stop(self) -> None:
        self._log.info("shutdown.start")

        # 1. Cancel all in-flight tasks gracefully
        cancelled = await self.orchestrator.cancel_all("shutdown")
        self._log.info("shutdown.tasks_cancelled", count=cancelled)

        # 2. Flush HALO traces + observability pipeline
        self.halo_os.flush_traces()
        await self.obs.stop()

        # 3. Coordination
        await self.lease.stop()
        await self.leader.stop()

        # 4. Retention
        await self.retention.stop()

        # 5. Memory
        await self.redis_bus.disconnect()

        self._log.info("shutdown.done")

    # ── Public API ──────────────────────────────────────────────────────────

    async def run(self, task: str,
                  context: dict[str, Any] | None = None,
                  deadline_s: float | None = None,
                  token_budget: int | None = None) -> dict:
        """
        Execute a task through the full stack.
        Returns {result, context_id, elapsed_s, tokens_used, routing}.
        """
        t0 = time.monotonic()

        # Policy gate (async — uses distributed rate-limit lock)
        await self.policy.check(task)

        # Route
        decision = await self.router.route(task)

        # Run through HALO OS → Orchestrator
        async def _run_fn(proc):
            result, ctx = await self.orchestrator.run(
                task,
                decision=decision,
                context_id=proc.pid,
                metadata=context or {},
                deadline_s=deadline_s,
                token_budget=token_budget,
            )
            return result

        priority = (TaskPriority.HIGH if decision.complexity >= 0.75
                    else TaskPriority.NORMAL)

        result_str = await self.halo_os.run_agent(
            agent_role=decision.primary.value,
            task=task,
            run_fn=_run_fn,
            priority=priority,
        )

        elapsed = round(time.monotonic() - t0, 3)
        return {
            "result":  result_str,
            "routing": decision,
            "elapsed_s": elapsed,
        }

    async def stream(self, task: str) -> AsyncIterator[str]:
        """Stream response tokens directly from Hermes."""
        await self.policy.check(task)
        async for token in self.hermes.stream(task):
            yield token

    async def cancel(self, context_id: str) -> bool:
        """Cancel a single in-flight task by its correlation ID."""
        return await self.orchestrator.cancel_context(context_id, reason="user")

    async def cancel_all(self) -> int:
        """Cancel all in-flight tasks."""
        return await self.orchestrator.cancel_all("user_request")

    async def schedule(self, task: str, cron: str) -> str:
        """Schedule a recurring task via DeepFlow batch layer."""
        ctx = ExecutionContext(task=task)
        return await self.orchestrator._batch.schedule(task, cron, ctx)

    # ── Memory helpers ──────────────────────────────────────────────────────

    async def _persist(self, task: str, result: Any) -> None:
        """Atomic transactional write to both Chroma and Redis."""
        key = f"last_task:{hash(task) & 0xFFFFFFFF}"
        await asyncio.gather(
            self.chroma.add(task=task, result=result),
            self.tx_writer.atomic_write(
                {key: str(result)[:2000]},
                ttl_s=self.config.memory.redis_state_ttl,
            ),
            return_exceptions=True,
        )

    # ── Status / health ──────────────────────────────────────────────────────

    def status(self) -> dict:
        return {
            "orchestrator":   self.orchestrator.status(),
            "halo_os":        self.halo_os.status(),
            "observability":  self.obs.health(),
            "is_leader":      self.leader.is_leader,
            "plugins":        self.plugins.list_plugins(),
        }

    # ── Context manager ──────────────────────────────────────────────────────

    async def __aenter__(self):
        await self.start()
        return self

    async def __aexit__(self, *_):
        await self.stop()
