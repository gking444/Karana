"""
unified_superpowers/core/config.py
──────────────────────────────────
Central configuration object that governs every sub-system.
Values are read from environment variables / .env / config.yaml.

Source repos covered:
  OpenJarvis (engine, local-first)
  Hermes / OpenClaude / Gemma 4   (intelligence layer)
  Microsoft JARVIS                 (task-planning API)
  LangSmith                        (observability)
  Chroma + Redis                   (memory)
  Docker                           (sandbox)
  Policy Engine                    (safety)
"""

from __future__ import annotations
import os
from pathlib import Path
from typing import Literal, Optional
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class IntelligenceConfig(BaseSettings):
    """Brain / LLM layer — Hermes, OpenClaude, Gemma 4, Gemini."""

    model_config = SettingsConfigDict(env_prefix="INTEL_", extra="ignore")

    # Primary reasoning model  (Hermes / OpenClaude path)
    primary_provider: Literal["anthropic", "openai", "google", "local"] = "anthropic"
    primary_model: str = "claude-sonnet-4-20250514"

    # Local fallback (Gemma 4 / llama.cpp)
    local_model_path: Optional[Path] = None
    local_engine: Literal["ollama", "llama_cpp", "vllm", "sglang"] = "ollama"
    local_model_name: str = "gemma3:12b"

    # OpenClaude deep-reasoning override
    deep_reasoning_model: str = "claude-opus-4-20250514"
    deep_reasoning_threshold: float = 0.7   # route to deep model above this complexity

    # API keys
    anthropic_api_key: str = Field(default="", alias="ANTHROPIC_API_KEY")
    openai_api_key: str = Field(default="", alias="OPENAI_API_KEY")
    google_api_key: str = Field(default="", alias="GOOGLE_API_KEY")

    # Microsoft JARVIS (HuggingGPT) — model dispatch endpoint
    huggingface_token: str = Field(default="", alias="HF_TOKEN")
    jarvis_hf_endpoint: str = "https://api-inference.huggingface.co/models"


class MemoryConfig(BaseSettings):
    """Chroma (vector) + Redis (fast/queue) + State Manager."""

    model_config = SettingsConfigDict(env_prefix="MEMORY_", extra="ignore")

    # Chroma
    chroma_host: str = "localhost"
    chroma_port: int = 8000
    chroma_collection: str = "superpowers_main"
    chroma_persist_dir: Path = Path("./data/chroma")

    # Redis
    redis_url: str = "redis://localhost:6379/0"
    redis_queue_name: str = "superpowers_tasks"
    redis_state_ttl: int = 86_400          # 24 h state expiry

    # State Manager
    state_backend: Literal["redis", "sqlite", "memory"] = "redis"
    state_db_path: Path = Path("./data/state.db")


class WorkflowConfig(BaseSettings):
    """Ruflow · DeepFlow 2.0 · Task Router · Feedback Loop."""

    model_config = SettingsConfigDict(env_prefix="WORKFLOW_", extra="ignore")

    # Task Router — how to classify incoming requests
    router_mode: Literal["llm", "rules", "hybrid"] = "hybrid"
    fast_task_timeout_s: int = 30          # Lightning Agent threshold
    slow_task_timeout_s: int = 600

    # DeepFlow 2.0 / Prefect
    prefect_api_url: Optional[str] = None  # None = local Prefect server

    # Feedback Loop
    enable_self_correction: bool = True
    max_correction_rounds: int = 3


class UIVisionConfig(BaseSettings):
    """UI-TARS · PicoClaw · VaXil · edxui."""

    model_config = SettingsConfigDict(env_prefix="VISION_", extra="ignore")

    enable_ui_control: bool = False        # PicoClaw — desktop automation
    screenshot_interval_ms: int = 500
    ocr_language: str = "en"
    vaxil_model: str = "gpt-4o"           # vision model for VaXil
    edxui_host: str = "localhost"
    edxui_port: int = 3000


class InfraConfig(BaseSettings):
    """Docker sandbox · Jarvis Runtime."""

    model_config = SettingsConfigDict(env_prefix="INFRA_", extra="ignore")

    sandbox_image: str = "python:3.12-slim"
    sandbox_mem_limit: str = "512m"
    sandbox_cpu_limit: float = 1.0
    sandbox_timeout_s: int = 120
    sandbox_network: str = "none"         # isolated by default

    jarvis_runtime_port: int = 7860
    expose_api: bool = True
    # FIX [BIND_ALL_INTERFACES]: default to loopback; set INFRA_API_HOST=0.0.0.0
    # explicitly in docker/k8s deployments only — never expose blindly in dev.
    api_host: str = "127.0.0.1"
    api_port: int = 8080


class ObservabilityConfig(BaseSettings):
    """LangSmith · structlog."""

    model_config = SettingsConfigDict(env_prefix="OBS_", extra="ignore")

    langsmith_api_key: str = Field(default="", alias="LANGCHAIN_API_KEY")
    langsmith_project: str = "unified-superpowers"
    langchain_tracing: bool = True

    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = "INFO"
    log_format: Literal["json", "console"] = "console"


class PolicyConfig(BaseSettings):
    """Policy Engine — safety, guardrails, rate limits."""

    model_config = SettingsConfigDict(env_prefix="POLICY_", extra="ignore")

    max_tokens_per_request: int = 8_000
    max_requests_per_minute: int = 60
    allow_web_browsing: bool = True
    allow_code_execution: bool = True
    allow_file_write: bool = True
    allow_shell_commands: bool = False     # off by default
    content_filter_level: Literal["off", "low", "medium", "high"] = "medium"
    blocked_domains: list[str] = Field(default_factory=list)


class SystemConfig(BaseSettings):
    """Root config — composes all sub-configs."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    intelligence: IntelligenceConfig = Field(default_factory=IntelligenceConfig)
    memory: MemoryConfig = Field(default_factory=MemoryConfig)
    workflow: WorkflowConfig = Field(default_factory=WorkflowConfig)
    ui_vision: UIVisionConfig = Field(default_factory=UIVisionConfig)
    infra: InfraConfig = Field(default_factory=InfraConfig)
    observability: ObservabilityConfig = Field(default_factory=ObservabilityConfig)
    policy: PolicyConfig = Field(default_factory=PolicyConfig)

    # Plugin / extension discovery
    plugin_dirs: list[Path] = Field(default_factory=lambda: [Path("./plugins")])

    @classmethod
    def from_yaml(cls, path: str | Path) -> "SystemConfig":
        import yaml
        with open(path) as f:
            data = yaml.safe_load(f) or {}
        return cls(**data)

    def apply_to_environment(self) -> None:
        """Push critical values into os.environ for LangSmith, etc."""
        obs = self.observability
        if obs.langsmith_api_key:
            os.environ["LANGCHAIN_API_KEY"] = obs.langsmith_api_key
        if obs.langchain_tracing:
            os.environ["LANGCHAIN_TRACING_V2"] = "true"
        os.environ["LANGCHAIN_PROJECT"] = obs.langsmith_project
