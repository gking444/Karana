"""
unified_superpowers/core/orchestrator.py
─────────────────────────────────────────
THE single orchestration authority.

Fixes [AMBIGUOUS_AUTHORITY] by enforcing strict layer contracts:

  ┌────────────────────────────────────────────────────────────────┐
  │  ORCHESTRATOR  (this file — owns task lifecycle)               │
  │                                                                │
  │  Layer 1 — RUNTIME  ── LangGraph                              │
  │    Canonical step-execution graph.  Owns the event loop.      │
  │    Calls agents directly.  Returns structured state.          │
  │                                                                │
  │  Layer 2 — STRATEGY ── CrewAI                                 │
  │    Role-based planning ONLY.  Produces a task plan.           │
  │    Does NOT execute agents directly.                          │
  │    Hands plan back to the LangGraph runtime.                  │
  │                                                                │
  │  Layer 3 — BATCH    ── DeepFlow                               │
  │    Schedules repeating / long-running workflows.              │
  │    Does NOT orchestrate agents in real-time.                  │
  │    Enqueues tasks via Redis; runtime handles execution.        │
  │                                                                │
  │  Layer 4 — MIDDLEWARE── FeedbackLoop                          │
  │    Post-processing hook ONLY.  Never starts work.             │
  │    Evaluates a completed result and requests one correction.  │
  │                                                                │
  └────────────────────────────────────────────────────────────────┘

Every layer receives an ExecutionContext — the single source of truth
for cancellation, deadlines, token budgets, and correlation IDs.
"""

from __future__ import annotations

import asyncio
import time
from typing import Any

import structlog

from unified_superpowers.core.execution_context import ExecutionContext, ContextStatus
from unified_superpowers.core.task_router import AgentRole, RoutingDecision

log = structlog.get_logger(__name__)


# ══════════════════════════════════════════════════════════════════════════════
# Backpressure: bounded task queue
# ══════════════════════════════════════════════════════════════════════════════

class BoundedTaskQueue:
    """
    Fix [NO_BACKPRESSURE].

    A bounded asyncio queue with:
      • hard capacity limit (blocks producers at high-water mark)
      • admission rejection at max_queue (immediate error, not hang)
      • pressure gauge (0.0–1.0) so callers can throttle proactively

    Replaces the unbounded put() calls that could balloon under load.
    """

    def __init__(self, maxsize: int = 256):
        self._q: asyncio.Queue | None = None
        self._maxsize = maxsize
        self._rejected: int = 0

    def _get_q(self) -> asyncio.Queue:
        if self._q is None:
            self._q = asyncio.Queue(maxsize=self._maxsize)
        return self._q

    async def enqueue(self, ctx: ExecutionContext, timeout: float = 5.0) -> None:
        """
        Enqueue a context for execution.
        Raises QueueFullError if the queue is at capacity after `timeout` seconds.
        """
        q = self._get_q()
        if q.full():
            self._rejected += 1
            raise QueueFullError(
                f"Task queue at capacity ({self._maxsize}). "
                f"Total rejected: {self._rejected}. "
                "Increase WORKFLOW_QUEUE_MAXSIZE or scale workers."
            )
        try:
            await asyncio.wait_for(q.put(ctx), timeout=timeout)
        except asyncio.TimeoutError:
            self._rejected += 1
            raise QueueFullError(
                f"Queue enqueue timed out after {timeout}s. "
                "System is under backpressure."
            )

    async def dequeue(self) -> ExecutionContext:
        return await self._get_q().get()

    def task_done(self) -> None:
        self._get_q().task_done()

    @property
    def pressure(self) -> float:
        if self._q is None:
            return 0.0
        return self._q.qsize() / self._maxsize

    @property
    def size(self) -> int:
        return self._get_q().qsize() if self._q else 0

    @property
    def rejected_total(self) -> int:
        return self._rejected


class QueueFullError(RuntimeError):
    """Raised when the bounded task queue rejects a new task."""


# ══════════════════════════════════════════════════════════════════════════════
# Layer contracts (interfaces the orchestrator enforces)
# ══════════════════════════════════════════════════════════════════════════════

class IRuntimeLayer:
    """
    Layer 1: LangGraph — canonical step executor.
    Contract: receives task + context + decision → returns result string.
    Must respect ctx.is_cancelled and ctx.is_expired at every graph node.
    """
    async def run(self, task: str, ctx: ExecutionContext,
                  decision: RoutingDecision, agents: dict) -> str:
        raise NotImplementedError


class IStrategyLayer:
    """
    Layer 2: CrewAI — planning only.
    Contract: receives task + context → returns a structured plan string.
    Must NOT invoke agents or execute any step directly.
    """
    async def plan(self, task: str, ctx: ExecutionContext) -> str:
        raise NotImplementedError


class IBatchLayer:
    """
    Layer 3: DeepFlow — scheduling only.
    Contract: receives task + cron → enqueues into Redis task queue.
    Must NOT run agents in real-time.
    """
    async def schedule(self, task: str, cron: str,
                       ctx: ExecutionContext) -> str:
        raise NotImplementedError


class IMiddlewareHook:
    """
    Layer 4: FeedbackLoop — post-processing hook.
    Contract: receives completed result → returns (possibly improved) result.
    Must NOT start new tasks or touch memory directly.
    """
    async def apply(self, task: str, result: str,
                    ctx: ExecutionContext) -> str:
        raise NotImplementedError


# ══════════════════════════════════════════════════════════════════════════════
# Adapters: wrap existing engines to enforce the layer contracts
# ══════════════════════════════════════════════════════════════════════════════

class LangGraphRuntimeAdapter(IRuntimeLayer):
    """Wraps LangGraphEngine — adds context checking at each step."""

    def __init__(self, engine):
        self._engine = engine

    async def run(self, task: str, ctx: ExecutionContext,
                  decision: RoutingDecision, agents: dict) -> str:
        ctx.check_cancelled()
        ctx.check_deadline()
        clog = ctx.bind_log()

        try:
            result = await self._engine.run(task, decision=decision, context=ctx.metadata)
            return result
        except asyncio.CancelledError:
            await ctx.cancel("langgraph_cancelled")
            raise
        except Exception as exc:
            clog.error("runtime.failed", error=str(exc))
            raise


class CrewAIStrategyAdapter(IStrategyLayer):
    """
    Wraps CrewAIEngine — constrained to planning only.
    Hermes generates the plan; CrewAI validates and structures it.
    CrewAI NEVER calls agents or executes steps directly here.
    """

    def __init__(self, hermes_agent):
        self._hermes = hermes_agent

    async def plan(self, task: str, ctx: ExecutionContext) -> str:
        ctx.check_cancelled()
        ctx.check_deadline()

        # Strategy: ask Hermes to produce a structured plan
        plan_prompt = (
            f"You are a strategic planner. Produce a numbered execution plan "
            f"for this task. Each step must be a discrete, testable action.\n\n"
            f"Task: {task}\n\nContext ID: {ctx.context_id}"
        )
        return await self._hermes.run(plan_prompt)


class DeepFlowBatchAdapter(IBatchLayer):
    """Wraps DeepFlowEngine — scheduling only, enqueues into Redis queue."""

    def __init__(self, engine, redis_bus):
        self._engine = engine
        self._redis  = redis_bus

    async def schedule(self, task: str, cron: str,
                       ctx: ExecutionContext) -> str:
        ctx.check_cancelled()
        # Push to Redis queue for async pickup — does NOT execute now
        await self._redis.push_task({
            "task": task,
            "cron": cron,
            "context_id": ctx.context_id,
            "scheduled_at": time.time(),
        })
        return await self._engine.schedule_workflow(
            name=f"task_{ctx.context_id}", task=task, cron=cron
        )


class FeedbackLoopMiddlewareAdapter(IMiddlewareHook):
    """Wraps FeedbackLoop — post-processing only, no new task creation."""

    def __init__(self, feedback_loop):
        self._loop = feedback_loop

    async def apply(self, task: str, result: str,
                    ctx: ExecutionContext) -> str:
        ctx.check_cancelled()
        ctx.check_deadline()
        return await self._loop.evaluate_and_correct(task, result)


# ══════════════════════════════════════════════════════════════════════════════
# The Orchestrator — single authority
# ══════════════════════════════════════════════════════════════════════════════

class Orchestrator:
    """
    THE single orchestration authority.

    Owns:
      • task lifecycle (create → run → correct → persist → done)
      • global cancellation (cancel_all(), cancel_context())
      • backpressure gate (BoundedTaskQueue)
      • context registry (tracks every in-flight ExecutionContext)
      • layer dispatch (runtime → strategy → batch → middleware)

    Does NOT own:
      • agent execution logic   (delegated to agents)
      • LLM calls               (delegated to agents)
      • memory reads/writes     (delegated to ChromaStore / RedisBus)
      • scheduling internals    (delegated to DeepFlowBatchAdapter)
    """

    def __init__(
        self,
        *,
        agents:       dict,
        runtime:      IRuntimeLayer,
        strategy:     IStrategyLayer,
        batch:        IBatchLayer,
        middleware:   IMiddlewareHook,
        memory_write, # async fn(task, result) → None
        queue_maxsize: int = 256,
        default_token_budget: int = 32_000,
        default_deadline_s:   float | None = None,
    ):
        self._agents   = agents
        self._runtime  = runtime
        self._strategy = strategy
        self._batch    = batch
        self._middleware = middleware
        self._memory_write = memory_write

        # Backpressure
        self._queue = BoundedTaskQueue(maxsize=queue_maxsize)

        # Defaults
        self._default_token_budget  = default_token_budget
        self._default_deadline_s    = default_deadline_s

        # Context registry — key: context_id, value: ExecutionContext
        self._registry: dict[str, ExecutionContext] = {}
        self._registry_lock: asyncio.Lock | None = None

        self._log = structlog.get_logger("orchestrator")

    def _get_registry_lock(self) -> asyncio.Lock:
        if self._registry_lock is None:
            self._registry_lock = asyncio.Lock()
        return self._registry_lock

    # ── Context management ────────────────────────────────────────────────────

    async def _register(self, ctx: ExecutionContext) -> None:
        async with self._get_registry_lock():
            self._registry[ctx.context_id] = ctx

    async def _deregister(self, ctx: ExecutionContext) -> None:
        async with self._get_registry_lock():
            self._registry.pop(ctx.context_id, None)

    def get_context(self, context_id: str) -> ExecutionContext | None:
        return self._registry.get(context_id)

    def active_contexts(self) -> list[ExecutionContext]:
        return [
            ctx for ctx in self._registry.values()
            if ctx.status == ContextStatus.RUNNING
        ]

    # ── Global cancellation ───────────────────────────────────────────────────

    async def cancel_context(self, context_id: str,
                              reason: str = "operator") -> bool:
        """Cancel a single in-flight task by its correlation ID."""
        ctx = self._registry.get(context_id)
        if ctx is None:
            return False
        await ctx.cancel(reason)
        self._log.info("orchestrator.cancel", context_id=context_id, reason=reason)
        return True

    async def cancel_all(self, reason: str = "shutdown") -> int:
        """
        Fix [NO_CANCELLATION_MODEL]: cancel every in-flight context.
        Returns the number of contexts cancelled.
        """
        active = self.active_contexts()
        self._log.info("orchestrator.cancel_all", count=len(active), reason=reason)
        await asyncio.gather(
            *[ctx.cancel(reason) for ctx in active],
            return_exceptions=True,
        )
        return len(active)

    # ── Main entry ────────────────────────────────────────────────────────────

    async def run(
        self,
        task: str,
        decision: RoutingDecision,
        context_id: str | None = None,
        parent_context: ExecutionContext | None = None,
        token_budget: int | None = None,
        deadline_s: float | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> tuple[str, ExecutionContext]:
        """
        Execute a task through the layer stack.

        Returns (result_string, execution_context).
        The context carries the correlation ID, token usage, timing, and status.
        """
        # ── Build ExecutionContext ───────────────────────────────────────────
        deadline_at = (
            time.monotonic() + (deadline_s or self._default_deadline_s)
            if (deadline_s or self._default_deadline_s)
            else None
        )
        ctx = ExecutionContext(
            context_id=context_id or str(__import__("uuid").uuid4())[:12],
            parent_id=parent_context.context_id if parent_context else None,
            task=task,
            deadline_at=deadline_at,
            token_budget=token_budget or self._default_token_budget,
            metadata=metadata or {},
        )
        ctx.routing = decision
        clog = ctx.bind_log()

        # ── Backpressure gate ───────────────────────────────────────────────
        await self._queue.enqueue(ctx)
        self._queue.task_done()   # slot used; release immediately (queue is a gate not a buffer)
        clog.info("orchestrator.accepted", queue_pressure=round(self._queue.pressure, 2))

        await self._register(ctx)
        await ctx.mark_running()

        try:
            result = await self._execute(task, ctx, decision)
            await ctx.mark_done()
            clog.info(
                "orchestrator.done",
                tokens_used=ctx.tokens_used,
                elapsed_s=round((ctx.finished_at or 0) - (ctx.started_at or 0), 3),
            )
            return result, ctx

        except asyncio.CancelledError:
            await ctx.cancel("asyncio_cancelled")
            raise
        except Exception as exc:
            await ctx.mark_failed(str(exc))
            clog.error("orchestrator.failed", error=str(exc))
            raise
        finally:
            await self._deregister(ctx)

    async def _execute(
        self, task: str, ctx: ExecutionContext, decision: RoutingDecision
    ) -> str:
        """
        Dispatch through layers in strict order:

          1. Strategy (CrewAI) — plan if complex
          2. Runtime  (LangGraph) — execute the plan
          3. Middleware (FeedbackLoop) — post-process

        Simple tasks skip the strategy layer.
        """
        clog = ctx.bind_log()

        # ── Guard: cancelled or expired before we even start ─────────────────
        ctx.check_cancelled()
        ctx.check_deadline()

        # ── Layer 2: Strategy (complex tasks only) ────────────────────────────
        plan: str | None = None
        if decision.complexity >= 0.75:
            clog.info("orchestrator.planning")
            plan = await self._strategy.plan(task, ctx)
            ctx.check_cancelled()   # cancel may have arrived during planning

        # ── Layer 1: Runtime ──────────────────────────────────────────────────
        clog.info("orchestrator.runtime", role=decision.primary.value,
                  has_plan=plan is not None)

        if plan:
            # Attach plan to context so LangGraph can use it
            ctx.metadata["execution_plan"] = plan

        if decision.primary == AgentRole.ORCHESTRATOR or decision.complexity >= 0.85:
            raw = await self._runtime.run(task, ctx, decision, self._agents)
        else:
            # Direct agent dispatch — bypass LangGraph for simple tasks.
            # FIX: graceful fallback to runtime when agent not registered
            # (e.g. PicoClaw disabled on headless, OpenHands not installed).
            agent = self._agents.get(decision.primary)
            if agent is not None:
                raw = await agent.run(task, context=ctx.metadata)
            else:
                clog.warning(
                    "orchestrator.agent_missing_fallback_to_runtime",
                    role=decision.primary.value,
                )
                raw = await self._runtime.run(task, ctx, decision, self._agents)

        ctx.check_cancelled()   # cancel during execution

        # ── Layer 4: Middleware (FeedbackLoop) ────────────────────────────────
        result = await self._middleware.apply(task, raw, ctx)

        # ── Persist ────────────────────────────────────────────────────────────
        await self._memory_write(task, result)

        return result

    # ── Status / health ───────────────────────────────────────────────────────

    def status(self) -> dict:
        all_ctx = list(self._registry.values())
        return {
            "active_tasks":   len([c for c in all_ctx if c.status == ContextStatus.RUNNING]),
            "total_tracked":  len(all_ctx),
            "queue_size":     self._queue.size,
            "queue_pressure": round(self._queue.pressure, 3),
            "queue_rejected": self._queue.rejected_total,
        }
