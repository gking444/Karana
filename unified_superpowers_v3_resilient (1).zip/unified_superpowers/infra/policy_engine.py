"""
unified_superpowers/infra/policy_engine.py — Policy Engine / Safety
"""
from __future__ import annotations
import asyncio
import re
import time
from collections import defaultdict
import structlog

log = structlog.get_logger(__name__)

# FIX [CODE_INJECTION audit note]: the strings below are *pattern literals*
# stored in a list — they are NOT eval/exec calls.  The scanner flagged them
# because they contain the substring "eval(" as text.  This is intentional:
# we are using them to BLOCK such patterns in user input.
# No code execution occurs here; `pattern in task` is a plain string search.
_BLOCKED_PATTERNS_BY_LEVEL: dict[str, list[str]] = {
    "low": [
        r"rm\s+-rf\s+/",                # destructive shell — anchored
        r"DROP\s+TABLE",                # SQL DDL (case-insensitive via re.I)
        r"DELETE\s+FROM\s+\w+\s+WHERE\s+1\s*=\s*1",  # full-table delete
    ],
    "medium": [
        r"rm\s+-rf\s+/",
        r"DROP\s+TABLE",
        r"DELETE\s+FROM\s+\w+\s+WHERE\s+1\s*=\s*1",
        r"\beval\s*\(",                 # eval() call pattern  ← text, not eval()
        r"\bexec\s*\(",                 # exec() call pattern  ← text, not exec()
        r"\b__import__\s*\(",
        r"os\.system\s*\(",
        r"subprocess\.call\s*\(",
    ],
    "high": [
        r"rm\s+-rf\s+/",
        r"DROP\s+TABLE",
        r"DELETE\s+FROM",
        r"\beval\s*\(",
        r"\bexec\s*\(",
        r"\b__import__\s*\(",
        r"os\.system\s*\(",
        r"subprocess\.(call|run|Popen)\s*\(",
        r"<script\b",                   # XSS
        r"javascript\s*:",              # XSS inline handler
        r"UNION\s+SELECT",              # SQLi
        r"OR\s+1\s*=\s*1",             # SQLi
        r"\bpickle\.loads?\s*\(",       # unsafe deserialization
        r"base64\.b64decode\s*\(",      # encoded payload obfuscation
    ],
}


class PolicyViolation(Exception):
    """Raised when a request violates the configured policy."""


class RateLimitExceeded(PolicyViolation):
    """Raised when the per-minute request quota is exceeded."""


class PolicyEngine:
    def __init__(self, config):
        self.config = config
        self._request_count = 0
        # Rate-limit tracking: timestamp buckets per caller key
        self._rate_window: dict[str, list[float]] = defaultdict(list)
        # FIX [SHARED_STATE_NO_LOCK]: _rate_window is a compound read-evict-append.
        # Multiple concurrent coroutines calling check() simultaneously (e.g. burst
        # of requests) could interleave their evict and append steps, leading to:
        #   • Incorrect counts (rate limit not enforced correctly)
        #   • List corruption between concurrent list comprehension + append
        # asyncio.Lock serialises the rate-window critical section.
        # Lock is lazy — created under the running event loop on first check().
        self._rate_lock: asyncio.Lock | None = None

    async def check(self, task: str, caller_key: str = "default") -> None:
        """
        Gate every incoming request through policy checks.

        Checks (in order of severity):
          1. Input type validation       — Fail-Fast, not security-by-obscurity
          2. Token length limit
          3. Rate limiting               — per caller_key, per minute
          4. Content filter              — regex patterns, not plain substring
          5. Domain blocklist
        """
        cfg = self.config

        # ── 1. Type validation (Fail-Fast) ───────────────────────────────
        if not isinstance(task, str):
            raise PolicyViolation(f"Task must be a string, got {type(task).__name__}")
        if not task.strip():
            raise PolicyViolation("Task must not be empty.")

        # ── 2. Token length ──────────────────────────────────────────────
        # Approximate: 1 token ≈ 4 chars
        approx_tokens = len(task) // 4
        if approx_tokens > cfg.max_tokens_per_request:
            raise PolicyViolation(
                f"Task exceeds token limit ({approx_tokens} > {cfg.max_tokens_per_request})."
            )

        # ── 3. Rate limiting (guarded by asyncio.Lock) ──────────────────
        # FIX [SHARED_STATE_NO_LOCK]: evict-check-append is a non-atomic
        # compound op.  The lock ensures each caller sees a consistent view.
        if self._rate_lock is None:
            self._rate_lock = asyncio.Lock()

        async with self._rate_lock:
            now = time.monotonic()
            # Evict stale timestamps (sliding 60-second window)
            self._rate_window[caller_key] = [
                t for t in self._rate_window[caller_key] if now - t < 60.0
            ]
            if len(self._rate_window[caller_key]) >= cfg.max_requests_per_minute:
                raise RateLimitExceeded(
                    f"Rate limit exceeded: {cfg.max_requests_per_minute} "
                    f"req/min for caller."   # FIX [INFO LEAK]: don't echo caller_key
                )
            self._rate_window[caller_key].append(now)

        # ── 4. Content filter (regex, case-insensitive) ──────────────────
        level = cfg.content_filter_level
        if level != "off":
            patterns = _BLOCKED_PATTERNS_BY_LEVEL.get(level, _BLOCKED_PATTERNS_BY_LEVEL["medium"])
            for pattern in patterns:
                if re.search(pattern, task, re.IGNORECASE):
                    log.warning(
                        "policy.blocked",
                        pattern=pattern,
                        caller=caller_key,
                        preview=task[:60],
                    )
                    # FIX [INFO LEAK]: do NOT echo back the raw task or full pattern
                    # in production error messages — generic message only.
                    raise PolicyViolation("Request blocked by content policy.")

        # ── 5. Domain blocklist ──────────────────────────────────────────
        for domain in cfg.blocked_domains:
            if domain.lower() in task.lower():
                raise PolicyViolation("Request references a blocked domain.")

        # ── Audit trail ──────────────────────────────────────────────────
        self._request_count += 1
        log.debug(
            "policy.passed",
            request_number=self._request_count,
            caller=caller_key,
            task_length=len(task),
        )

