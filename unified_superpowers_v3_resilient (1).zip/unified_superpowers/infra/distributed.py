"""
unified_superpowers/infra/distributed.py
─────────────────────────────────────────
Fix [DISTRIBUTED_COORDINATION_MISSING]

Components:
  DistributedLock    — Redis SETNX-based mutex (prevents split-brain writes)
  LeaderElection     — one active leader per role across workers
  WorkerLease        — heartbeat-based worker presence tracking
  DistributedBarrier — rendezvous point for multi-worker fan-out

All built on Redis (already a dependency) — no new infra required.
Uses SETNX + EXPIRE for atomicity; falls back to in-process locks when
Redis is unavailable (single-worker dev mode).
"""

from __future__ import annotations

import asyncio
import json
import os
import socket
import time
import uuid
from contextlib import asynccontextmanager
from typing import AsyncIterator

import structlog

log = structlog.get_logger(__name__)

WORKER_ID = f"{socket.gethostname()}-{os.getpid()}-{str(uuid.uuid4())[:6]}"


# ══════════════════════════════════════════════════════════════════════════════
# Distributed Lock
# ══════════════════════════════════════════════════════════════════════════════

class LockNotAcquiredError(RuntimeError):
    """Raised when a distributed lock cannot be acquired within the timeout."""


class DistributedLock:
    """
    Redis SET NX PX distributed lock (Redlock-lite for single-node).

    Guarantees:
      • Only one holder at a time (per Redis instance)
      • Auto-expires after `ttl_ms` even if the holder crashes
      • Release is safe — only the lock owner can release (value check)
      • In-process asyncio.Lock fallback when Redis is unavailable

    Usage:
        lock = DistributedLock(redis_bus, "chroma_write", ttl_ms=5_000)
        async with lock.acquire(timeout=3.0):
            # exclusive section
            ...
    """

    LOCK_PREFIX = "dlock:"

    def __init__(self, redis_bus, name: str, ttl_ms: int = 10_000):
        self._redis  = redis_bus
        self._name   = f"{self.LOCK_PREFIX}{name}"
        self._ttl_ms = ttl_ms
        self._token  = f"{WORKER_ID}:{str(uuid.uuid4())[:8]}"
        # In-process fallback
        self._local_lock: asyncio.Lock | None = None

    def _get_local_lock(self) -> asyncio.Lock:
        if self._local_lock is None:
            self._local_lock = asyncio.Lock()
        return self._local_lock

    @asynccontextmanager
    async def acquire(self, timeout: float = 5.0) -> AsyncIterator[None]:
        """
        Async context manager — acquires lock, yields, then releases.
        Raises LockNotAcquiredError if lock not obtained within `timeout` s.
        """
        acquired = await self._try_acquire(timeout)
        if not acquired:
            raise LockNotAcquiredError(
                f"Could not acquire distributed lock '{self._name}' "
                f"within {timeout}s. Another worker holds it."
            )
        try:
            yield
        finally:
            await self._release()

    async def _try_acquire(self, timeout: float) -> bool:
        client = self._redis._redis
        if client is None:
            # No Redis — fall back to in-process lock
            try:
                await asyncio.wait_for(
                    self._get_local_lock().acquire(), timeout=timeout
                )
                return True
            except asyncio.TimeoutError:
                return False

        deadline = time.monotonic() + timeout
        poll_interval = 0.05   # 50ms polling

        while time.monotonic() < deadline:
            result = await client.set(
                self._name, self._token,
                nx=True,       # only set if not exists
                px=self._ttl_ms,
            )
            if result:
                log.debug("dlock.acquired", name=self._name, token=self._token)
                return True
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            await asyncio.sleep(min(poll_interval, remaining))
            poll_interval = min(poll_interval * 1.5, 0.5)   # exponential backoff

        return False

    async def _release(self) -> None:
        client = self._redis._redis
        if client is None:
            try:
                self._get_local_lock().release()
            except RuntimeError:
                pass   # already released
            return

        # Lua script: only delete if we own the lock (value == our token)
        # This prevents releasing a lock that expired and was re-acquired
        # by another worker.
        lua = """
        if redis.call("GET", KEYS[1]) == ARGV[1] then
            return redis.call("DEL", KEYS[1])
        else
            return 0
        end
        """
        try:
            result = await client.eval(lua, 1, self._name, self._token)
            if result == 0:
                log.warning("dlock.release_skipped",
                            name=self._name,
                            reason="lock expired or stolen")
            else:
                log.debug("dlock.released", name=self._name)
        except Exception as exc:
            log.warning("dlock.release_error", error=str(exc))

    async def is_locked(self) -> bool:
        client = self._redis._redis
        if client is None:
            return self._local_lock is not None and self._local_lock.locked()
        return await client.exists(self._name) == 1

    async def ttl_remaining_ms(self) -> int:
        client = self._redis._redis
        if client is None:
            return -1
        return await client.pttl(self._name)


# ══════════════════════════════════════════════════════════════════════════════
# Leader Election
# ══════════════════════════════════════════════════════════════════════════════

class LeaderElection:
    """
    Redis-based leader election for a named role.

    A candidate tries to SET NX the leader key with its worker_id.
    The current leader renews its TTL via heartbeat.
    A candidate that fails to SET NX reads the current leader.

    Usage:
        election = LeaderElection(redis_bus, role="orchestrator")
        await election.start()
        if election.is_leader:
            ...   # this worker is the leader
        await election.stop()
    """

    LEADER_PREFIX = "leader:"
    HEARTBEAT_S   = 5.0
    LEADER_TTL_S  = 15    # 3× heartbeat — auto-expires if leader dies

    def __init__(self, redis_bus, role: str,
                 worker_id: str = WORKER_ID):
        self._redis     = redis_bus
        self._key       = f"{self.LEADER_PREFIX}{role}"
        self._worker_id = worker_id
        self._is_leader = False
        self._task: asyncio.Task | None = None

    @property
    def is_leader(self) -> bool:
        return self._is_leader

    @property
    def worker_id(self) -> str:
        return self._worker_id

    async def start(self) -> None:
        await self._try_become_leader()
        self._task = asyncio.create_task(
            self._heartbeat_loop(), name=f"leader_election_{self._key}"
        )
        log.info("election.started",
                 key=self._key, is_leader=self._is_leader,
                 worker=self._worker_id[:20])

    async def stop(self) -> None:
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        if self._is_leader:
            await self._resign()

    async def current_leader(self) -> str | None:
        """Return the worker_id of the current leader, or None."""
        client = self._redis._redis
        if client is None:
            return self._worker_id if self._is_leader else None
        val = await client.get(self._key)
        return val if val else None

    async def _try_become_leader(self) -> None:
        client = self._redis._redis
        if client is None:
            self._is_leader = True   # single worker — always leader
            return
        result = await client.set(
            self._key, self._worker_id,
            nx=True, ex=self.LEADER_TTL_S,
        )
        self._is_leader = result is not None
        log.debug("election.attempt",
                  key=self._key, won=self._is_leader,
                  worker=self._worker_id[:20])

    async def _heartbeat_loop(self) -> None:
        while True:
            await asyncio.sleep(self.HEARTBEAT_S)
            if self._is_leader:
                await self._renew()
            else:
                # Try to become leader if current leader expired
                await self._try_become_leader()

    async def _renew(self) -> None:
        client = self._redis._redis
        if client is None:
            return
        try:
            # Only renew if we still own the key
            val = await client.get(self._key)
            if val == self._worker_id:
                await client.expire(self._key, self.LEADER_TTL_S)
            else:
                # We lost leadership (key expired and was taken)
                self._is_leader = False
                log.warning("election.leadership_lost", key=self._key)
        except Exception as exc:
            log.warning("election.renew_error", error=str(exc))

    async def _resign(self) -> None:
        client = self._redis._redis
        if client is None:
            self._is_leader = False
            return
        lua = """
        if redis.call("GET", KEYS[1]) == ARGV[1] then
            return redis.call("DEL", KEYS[1])
        end
        return 0
        """
        try:
            await client.eval(lua, 1, self._key, self._worker_id)
            self._is_leader = False
            log.info("election.resigned", key=self._key)
        except Exception as exc:
            log.warning("election.resign_error", error=str(exc))


# ══════════════════════════════════════════════════════════════════════════════
# Worker Lease (heartbeat presence)
# ══════════════════════════════════════════════════════════════════════════════

class WorkerLease:
    """
    Heartbeat-based worker presence tracking.

    Each worker registers itself in Redis with a TTL-based key.
    Other components can query active_workers() to discover the fleet.

    Enables:
      • Scale-aware routing (don't send tasks to dead workers)
      • Graceful drain (worker marks itself DRAINING before shutdown)
      • Worker count for backpressure decisions
    """

    LEASE_PREFIX  = "worker:"
    HEARTBEAT_S   = 10.0
    LEASE_TTL_S   = 30

    def __init__(self, redis_bus, worker_id: str = WORKER_ID):
        self._redis     = redis_bus
        self._worker_id = worker_id
        self._key       = f"{self.LEASE_PREFIX}{worker_id}"
        self._task: asyncio.Task | None = None

    async def start(self) -> None:
        await self._register("active")
        self._task = asyncio.create_task(
            self._heartbeat(), name="worker_lease_heartbeat"
        )
        log.info("worker_lease.registered", worker=self._worker_id[:20])

    async def stop(self) -> None:
        await self._register("draining")
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        await self._deregister()

    async def _register(self, status: str) -> None:
        client = self._redis._redis
        if client is None:
            return
        payload = json.dumps({
            "worker_id": self._worker_id,
            "status":    status,
            "ts":        time.time(),
        })
        await client.setex(self._key, self.LEASE_TTL_S, payload)

    async def _deregister(self) -> None:
        client = self._redis._redis
        if client is None:
            return
        await client.delete(self._key)
        log.info("worker_lease.deregistered", worker=self._worker_id[:20])

    async def _heartbeat(self) -> None:
        while True:
            await asyncio.sleep(self.HEARTBEAT_S)
            try:
                await self._register("active")
            except asyncio.CancelledError:
                break
            except Exception as exc:
                log.warning("worker_lease.heartbeat_error", error=str(exc))

    @classmethod
    async def active_workers(cls, redis_bus) -> list[dict]:
        """Return all currently active workers."""
        client = redis_bus._redis
        if client is None:
            return [{"worker_id": WORKER_ID, "status": "active", "ts": time.time()}]
        cursor, keys = 0, []
        while True:
            cursor, batch = await client.scan(
                cursor, match=f"{cls.LEASE_PREFIX}*", count=100
            )
            keys.extend(batch)
            if cursor == 0:
                break
        workers = []
        for k in keys:
            raw = await client.get(k)
            if raw:
                try:
                    workers.append(json.loads(raw))
                except Exception:
                    pass
        return workers


# ══════════════════════════════════════════════════════════════════════════════
# Distributed Barrier
# ══════════════════════════════════════════════════════════════════════════════

class DistributedBarrier:
    """
    Rendezvous point: blocks until N workers have all checked in.

    Used for coordinated fan-out: the orchestrator spawns N sub-tasks
    across workers and waits at the barrier until all report done.
    """

    BARRIER_PREFIX = "barrier:"

    def __init__(self, redis_bus, barrier_name: str, expected: int,
                 ttl_s: int = 120):
        self._redis    = redis_bus
        self._key      = f"{self.BARRIER_PREFIX}{barrier_name}"
        self._expected = expected
        self._ttl_s    = ttl_s

    async def check_in(self, worker_id: str = WORKER_ID) -> int:
        """Check in this worker. Returns current count."""
        client = self._redis._redis
        if client is None:
            return self._expected   # single-worker: immediately satisfied

        count = await client.hincrby(self._key, worker_id, 1)
        await client.expire(self._key, self._ttl_s)
        return await client.hlen(self._key)

    async def wait(self, poll_interval: float = 0.5,
                   timeout: float = 60.0) -> bool:
        """
        Wait until `expected` workers have checked in.
        Returns True if barrier cleared, False if timeout.
        """
        deadline = time.monotonic() + timeout
        client   = self._redis._redis

        if client is None:
            return True   # single-worker always satisfied

        while time.monotonic() < deadline:
            count = await client.hlen(self._key)
            if count >= self._expected:
                log.debug("barrier.cleared",
                          key=self._key, count=count)
                await client.delete(self._key)
                return True
            await asyncio.sleep(poll_interval)

        log.warning("barrier.timeout",
                    key=self._key, expected=self._expected)
        return False
