"""
unified_superpowers/infra/sandbox.py — Docker sandbox + Jarvis Runtime
"""
from __future__ import annotations
import asyncio
import os
import stat
import tempfile
from pathlib import Path
import structlog

log = structlog.get_logger(__name__)

# FIX [INJECTION]: strict allowlist — never accept arbitrary language strings
_ALLOWED_LANGUAGES: dict[str, tuple[str, str]] = {
    "python":     ("py",  "python3"),
    "javascript": ("js",  "node"),
    "bash":       ("sh",  "bash"),
}


class DockerSandbox:
    """Docker-based execution sandbox + Jarvis Runtime."""

    def __init__(self, config):
        self.config = config
        self._client = None

    def _docker(self):
        if self._client is None:
            import docker  # type: ignore
            self._client = docker.from_env()
        return self._client

    async def pull_image(self) -> None:
        try:
            # FIX [DEPRECATED_API]: use asyncio.get_running_loop() — already
            # inside an async context; the deprecated get_event_loop API may
            # silently create a new loop in Python 3.12+ when called outside
            # a running loop.
            loop = asyncio.get_running_loop()
            await loop.run_in_executor(
                None,
                lambda: self._docker().images.pull(self.config.sandbox_image),
            )
            log.info("sandbox.image_pulled", image=self.config.sandbox_image)
        except RuntimeError:
            # Not inside a running loop (e.g., called from sync context) — fallback
            import docker  # type: ignore
            docker.from_env().images.pull(self.config.sandbox_image)
            log.info("sandbox.image_pulled_sync", image=self.config.sandbox_image)
        except Exception as exc:
            log.warning("sandbox.pull_failed", error=str(exc))

    async def run_code(self, code: str, language: str = "python") -> str:
        # FIX [INJECTION]: validate language against strict allowlist
        if language not in _ALLOWED_LANGUAGES:
            raise ValueError(
                f"Unsupported language '{language}'. "
                f"Allowed: {list(_ALLOWED_LANGUAGES)}"
            )
        ext, cmd = _ALLOWED_LANGUAGES[language]

        # FIX [INSECURE_TEMPFILE]: set mode=0o600 immediately after creation
        # so other OS users cannot read the code file before the container runs.
        fd, tmp = tempfile.mkstemp(suffix=f".{ext}")
        try:
            os.chmod(tmp, stat.S_IRUSR | stat.S_IWUSR)   # 0o600 — owner read/write only
            with os.fdopen(fd, "w") as f:
                f.write(code)

            # FIX [PATH_TRAVERSAL]: use only the basename in the container command;
            # never interpolate user-supplied paths.
            safe_basename = Path(tmp).name

            # FIX [DEPRECATED_API]: get_running_loop() — correct inside async fn
            loop = asyncio.get_running_loop()
            result = await loop.run_in_executor(
                None,
                lambda: self._docker().containers.run(
                    image=self.config.sandbox_image,
                    command=[cmd, f"/code/{safe_basename}"],   # list form — no shell
                    volumes={
                        os.path.dirname(tmp): {"bind": "/code", "mode": "ro"},
                    },
                    mem_limit=self.config.sandbox_mem_limit,
                    network_mode=self.config.sandbox_network,
                    remove=True,
                    timeout=self.config.sandbox_timeout_s,
                    stdout=True,
                    stderr=True,
                    user="nobody",    # drop privileges inside container
                ),
            )
            return result.decode() if isinstance(result, bytes) else str(result)

        except Exception as exc:
            # FIX [INFO LEAK]: log full error server-side; return generic message
            # to caller so internal paths / image names don't leak upward.
            log.exception("sandbox.run_failed", language=language)
            return f"Execution failed. Check server logs for details."

        finally:
            # Always clean up temp file — even on exception
            try:
                os.unlink(tmp)
            except OSError:
                pass

