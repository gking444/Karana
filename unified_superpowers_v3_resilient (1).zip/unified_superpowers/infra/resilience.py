"""
unified_superpowers/infra/resilience.py
────────────────────────────────────────
Resilience primitives — ADR-003 + ADR-004.

Fix [R-008] CircuitBreaker  — prevents cascade failure on LLM API outage
Fix [R-009] RetryPolicy     — full-jitter exponential backoff, no thundering herd
Fix [TIMEOUT_MISSING]       — every external call wrapped with hard timeout

Classes
───────
CircuitBreaker   Three-state FSM: CLOSED → OPEN → HALF_OPEN → CLOSED
RetryPolicy      Async decorator with full-jitter backoff
with_timeout     Thin asyncio.wait_for wrapper that maps TimeoutError cleanly
BulkheadLimiter  Bounded asyncio.Semaphore — caps concurrent calls to one service
"""

from __future__ import annotations

import asyncio
import enum
import math
import random
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Awaitable, Type

import structlog

log = structlog.get_logger(__name__)


# ══════════════════════════════════════════════════════════════════════════════
# Exceptions
# ══════════════════════════════════════════════════════════════════════════════

class CircuitOpenError(RuntimeError):
    """Raised when a call is attempted while the circuit breaker is OPEN."""


class MaxRetriesExceeded(RuntimeError):
    """Raised when all retry attempts have been exhausted."""


# ══════════════════════════════════════════════════════════════════════════════
# Circuit Breaker  (ADR-003)
# ══════════════════════════════════════════════════════════════════════════════

class CBState(str, enum.Enum):
    CLOSED    = "closed"     # Normal operation — calls pass through
    OPEN      = "open"       # Failing — calls fast-fail with CircuitOpenError
    HALF_OPEN = "half_open"  # Testing recovery — one probe call allowed


@dataclass
class CircuitBreaker:
    """
    Three-state circuit breaker for external API calls.

    State transitions
    ─────────────────
    CLOSED  → OPEN      when failure_count >= failure_threshold in window_s
    OPEN    → HALF_OPEN after reset_timeout_s elapses
    HALF_OPEN→ CLOSED   on probe success
    HALF_OPEN→ OPEN     on probe failure

    Usage
    ─────
        cb = CircuitBreaker(name="anthropic_llm")

        async with cb.call():
            response = await anthropic_client.messages.create(...)

        # or as decorator:
        @cb.protect
        async def call_llm(prompt): ...
    """

    name:              str   = "default"
    failure_threshold: int   = 5      # failures before opening
    window_s:          float = 60.0   # rolling window for failure counting
    reset_timeout_s:   float = 60.0   # seconds OPEN before → HALF_OPEN
    success_threshold: int   = 1      # successes in HALF_OPEN before → CLOSED

    # Runtime state (not part of config — created post-init)
    _state:           CBState               = field(default=CBState.CLOSED,      init=False, repr=False)
    _failure_times:   list[float]           = field(default_factory=list,         init=False, repr=False)
    _opened_at:       float | None          = field(default=None,                 init=False, repr=False)
    _half_open_wins:  int                   = field(default=0,                    init=False, repr=False)
    _lock:            asyncio.Lock | None   = field(default=None,                 init=False, repr=False)
    _total_calls:     int                   = field(default=0,                    init=False, repr=False)
    _total_failures:  int                   = field(default=0,                    init=False, repr=False)
    _total_rejected:  int                   = field(default=0,                    init=False, repr=False)

    def _get_lock(self) -> asyncio.Lock:
        if self._lock is None:
            self._lock = asyncio.Lock()
        return self._lock

    # ── State machine ─────────────────────────────────────────────────────────

    async def _transition(self, new_state: CBState, reason: str) -> None:
        self._state = new_state
        log.info(
            "circuit_breaker.transition",
            name=self.name,
            state=new_state.value,
            reason=reason,
            failures=len(self._failure_times),
        )

    async def _check_and_evolve(self) -> None:
        """Check whether state should transition before allowing a call."""
        async with self._get_lock():
            now = time.monotonic()

            if self._state == CBState.OPEN:
                if self._opened_at and (now - self._opened_at) >= self.reset_timeout_s:
                    self._half_open_wins = 0
                    await self._transition(CBState.HALF_OPEN, "reset_timeout_elapsed")
                else:
                    self._total_rejected += 1
                    raise CircuitOpenError(
                        f"Circuit breaker '{self.name}' is OPEN. "
                        f"Retry after {self.reset_timeout_s}s. "
                        f"Total failures: {self._total_failures}"
                    )

    async def _record_success(self) -> None:
        async with self._get_lock():
            # Evict old failure timestamps outside window
            now = time.monotonic()
            self._failure_times = [
                t for t in self._failure_times if now - t < self.window_s
            ]
            if self._state == CBState.HALF_OPEN:
                self._half_open_wins += 1
                if self._half_open_wins >= self.success_threshold:
                    await self._transition(CBState.CLOSED, "probe_succeeded")

    async def _record_failure(self) -> None:
        async with self._get_lock():
            now = time.monotonic()
            self._failure_times.append(now)
            self._total_failures += 1
            # Evict outside window
            self._failure_times = [
                t for t in self._failure_times if now - t < self.window_s
            ]
            if self._state == CBState.HALF_OPEN:
                self._opened_at = now
                self._half_open_wins = 0
                await self._transition(CBState.OPEN, "probe_failed")
            elif (
                self._state == CBState.CLOSED
                and len(self._failure_times) >= self.failure_threshold
            ):
                self._opened_at = now
                await self._transition(CBState.OPEN, "failure_threshold_reached")

    # ── Public API ────────────────────────────────────────────────────────────

    class _CallCtx:
        def __init__(self, cb: "CircuitBreaker"):
            self._cb = cb

        async def __aenter__(self):
            await self._cb._check_and_evolve()
            self._cb._total_calls += 1
            return self

        async def __aexit__(self, exc_type, exc_val, _tb):
            if exc_type is None or exc_type is asyncio.CancelledError:
                await self._cb._record_success()
            else:
                await self._cb._record_failure()
            return False   # never suppress

    def call(self) -> "_CallCtx":
        """Async context manager for a single protected call."""
        return self._CallCtx(self)

    def protect(self, fn: Callable) -> Callable:
        """Decorator that wraps an async function with circuit-breaker protection."""
        async def wrapper(*args, **kwargs):
            async with self.call():
                return await fn(*args, **kwargs)
        wrapper.__name__ = fn.__name__
        return wrapper

    def status(self) -> dict:
        return {
            "name":          self.name,
            "state":         self._state.value,
            "failure_count": len(self._failure_times),
            "total_calls":   self._total_calls,
            "total_failures":self._total_failures,
            "total_rejected":self._total_rejected,
        }


# ══════════════════════════════════════════════════════════════════════════════
# Retry Policy  (ADR-004)
# ══════════════════════════════════════════════════════════════════════════════

# Errors that are safe to retry (transient)
RETRYABLE_EXCEPTIONS: tuple[Type[Exception], ...] = (
    ConnectionError,
    TimeoutError,
    asyncio.TimeoutError,
    OSError,
)

# HTTP status codes that warrant retry (when raised as exceptions with .status)
RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}


@dataclass
class RetryPolicy:
    """
    Full-jitter exponential backoff retry policy  (ADR-004).

    Algorithm:  delay = random(0, min(cap, base * 2^attempt))
    This is the "Full Jitter" variant from the AWS retry blog post.
    It spreads retries across the widest possible time window, preventing
    thundering herds when N agents all fail and retry simultaneously.

    Usage
    ─────
        policy = RetryPolicy(max_attempts=3, base_delay_s=1.0, cap_delay_s=30.0)

        result = await policy.execute(call_anthropic_api, prompt="hello")
    """

    max_attempts:  int   = 3
    base_delay_s:  float = 1.0
    cap_delay_s:   float = 30.0
    retryable:     tuple = field(default_factory=lambda: RETRYABLE_EXCEPTIONS)

    def _jitter_delay(self, attempt: int) -> float:
        """Full-jitter delay: random(0, min(cap, base * 2^attempt))."""
        exponential = self.base_delay_s * math.pow(2, attempt)
        capped      = min(self.cap_delay_s, exponential)
        return random.uniform(0, capped)

    def _is_retryable(self, exc: Exception) -> bool:
        if isinstance(exc, self.retryable):
            return True
        # Check HTTP status codes on exception objects that carry .status or .status_code
        for attr in ("status", "status_code"):
            code = getattr(exc, attr, None)
            if code in RETRYABLE_STATUS_CODES:
                return True
        return False

    async def execute(
        self,
        fn: Callable[..., Awaitable[Any]],
        *args: Any,
        **kwargs: Any,
    ) -> Any:
        """
        Call `fn(*args, **kwargs)` up to max_attempts times.
        Raises MaxRetriesExceeded (wrapping the last exception) on exhaustion.
        Raises immediately on non-retryable exceptions.
        Never retries CancelledError — always re-raises immediately.
        """
        last_exc: Exception | None = None

        for attempt in range(self.max_attempts):
            try:
                return await fn(*args, **kwargs)

            except asyncio.CancelledError:
                raise   # never retry cancellations

            except Exception as exc:
                last_exc = exc
                if not self._is_retryable(exc):
                    raise   # non-retryable — fail immediately

                if attempt < self.max_attempts - 1:
                    delay = self._jitter_delay(attempt)
                    log.warning(
                        "retry.scheduled",
                        fn=getattr(fn, "__name__", str(fn)),
                        attempt=attempt + 1,
                        max_attempts=self.max_attempts,
                        delay_s=round(delay, 2),
                        error=str(exc)[:80],
                    )
                    await asyncio.sleep(delay)

        raise MaxRetriesExceeded(
            f"All {self.max_attempts} attempts failed for "
            f"'{getattr(fn, '__name__', '?')}'. "
            f"Last error: {last_exc}"
        ) from last_exc

    def wrap(self, fn: Callable) -> Callable:
        """Decorator that applies this retry policy to an async function."""
        async def wrapper(*args, **kwargs):
            return await self.execute(fn, *args, **kwargs)
        wrapper.__name__ = fn.__name__
        return wrapper


# ══════════════════════════════════════════════════════════════════════════════
# Timeout helper
# ══════════════════════════════════════════════════════════════════════════════

async def with_timeout(
    coro: Awaitable[Any],
    timeout_s: float,
    name: str = "operation",
) -> Any:
    """
    Await `coro` with a hard timeout.
    Maps asyncio.TimeoutError → RuntimeError with descriptive message.
    Re-raises CancelledError immediately (never wraps it).
    """
    try:
        return await asyncio.wait_for(coro, timeout=timeout_s)
    except asyncio.CancelledError:
        log.debug("with_timeout.cancelled", name=name)
        raise
    except asyncio.TimeoutError:
        log.warning("with_timeout.expired", name=name, timeout_s=timeout_s)
        raise RuntimeError(
            f"'{name}' timed out after {timeout_s}s. "
            "Check network connectivity or increase the timeout."
        )


# ══════════════════════════════════════════════════════════════════════════════
# Bulkhead limiter
# ══════════════════════════════════════════════════════════════════════════════

class BulkheadLimiter:
    """
    Resource-isolation bulkhead — caps concurrent calls to one service.

    Prevents a slow dependency from consuming all available coroutine slots.
    Each external service should have its own BulkheadLimiter.

    Usage
    ─────
        llm_bulkhead = BulkheadLimiter(max_concurrent=10, name="llm_api")

        async with llm_bulkhead.acquire(timeout=5.0):
            result = await call_llm(...)
    """

    def __init__(self, max_concurrent: int, name: str = "service"):
        self.name           = name
        self.max_concurrent = max_concurrent
        self._sem:          asyncio.Semaphore | None = None
        self._waiting:      int = 0
        self._rejected:     int = 0
        self._active:       int = 0

    def _get_sem(self) -> asyncio.Semaphore:
        if self._sem is None:
            self._sem = asyncio.Semaphore(self.max_concurrent)
        return self._sem

    class _AcquireCtx:
        def __init__(self, limiter: "BulkheadLimiter", timeout: float):
            self._l = limiter
            self._t = timeout

        async def __aenter__(self):
            self._l._waiting += 1
            try:
                await asyncio.wait_for(
                    self._l._get_sem().acquire(),
                    timeout=self._t,
                )
                self._l._active += 1
            except asyncio.TimeoutError:
                self._l._rejected += 1
                raise RuntimeError(
                    f"Bulkhead '{self._l.name}' rejected: "
                    f"all {self._l.max_concurrent} slots busy after {self._t}s. "
                    f"Total rejected: {self._l._rejected}"
                )
            finally:
                self._l._waiting -= 1
            return self

        async def __aexit__(self, *_):
            self._l._get_sem().release()
            self._l._active -= 1
            return False

    def acquire(self, timeout: float = 5.0) -> "_AcquireCtx":
        return self._AcquireCtx(self, timeout)

    def status(self) -> dict:
        return {
            "name":           self.name,
            "max_concurrent": self.max_concurrent,
            "active":         self._active,
            "waiting":        self._waiting,
            "rejected":       self._rejected,
            "utilisation":    round(self._active / self.max_concurrent, 3),
        }
