# 🚀 Unified Superpowers — Complete AI Agent System

> One repo to rule them all. 30+ GitHub projects, unified into a single autonomous AI stack.

---

## 📋 Repository Map — All Sources Integrated

| Source Repo | Role in Unified System | Module |
|---|---|---|
| **OpenJarvis** (`open-jarvis/OpenJarvis`) | Modular local-first framework primitives | `core/config.py`, `core/system.py` |
| **Hermes** (NousResearch reasoning) | Brain / primary reasoning model | `agents/hermes_agent.py` |
| **Microsoft JARVIS** (`microsoft/JARVIS`) | JARVIS-style task decomposition (4-stage HuggingGPT) | `agents/hermes_agent.py → decompose_to_subtasks()` |
| **LightningAgent** | Fast executor for small tasks | `agents/lightning_agent.py` |
| **edxui** | UI frontend layer | `agents/picoclaw_agent.py` (edxui host config) |
| **PicoClaw** | System control / UI actions | `agents/picoclaw_agent.py` |
| **OpenHands** (`All-Hands-AI/OpenHands`) | Coding and dev execution | `agents/openhands_adapter.py` |
| **UI-TARS** (`bytedance/UI-TARS-desktop`) | Multimodal UI agent | `agents/picoclaw_agent.py` |
| **Goose** (`block/goose`) | Lightweight background worker | `agents/goose_agent.py` |
| **Ruflow** | Workflow automation | `workflow/deepflow.py` |
| **LangChain** (`langchain-ai/langchain`) | Agent framework / LLM tooling | `workflow/crewai_engine.py`, all agents |
| **CrewAI** (`crewAIInc/crewAI`) | Multi-agent crew orchestration | `workflow/crewai_engine.py` |
| **LangGraph** (`langchain-ai/langgraph`) | Core decision graph / state machine | `workflow/langgraph_engine.py` |
| **Graphify** | Visualisation / logic graphing | `utils/graphify.py` |
| **OpenClaude** | Deep reasoning model (Opus tier) | `agents/hermes_agent.py` (deep path) |
| **Gemma 4** | Local model option | `core/config.py` (local_engine) |
| **Jarvis Runtime** | Execution environment | `infra/sandbox.py` |
| **VaXil** | Vision layer | `vision/vaxil.py` |
| **Docker** | Sandbox isolation | `infra/sandbox.py` |
| **Task Router** | Decision engine | `core/task_router.py` |
| **State Manager** | Workflow memory | `memory/redis_bus.py → StateManager` |
| **Feedback Loop** | Self-correction | `workflow/feedback_loop.py` |
| **Chroma** (`chroma-core/chroma`) | Vector memory | `memory/chroma_store.py` |
| **Redis** | Fast memory / queue | `memory/redis_bus.py` |
| **LangSmith** | Observability / tracing | `utils/observability.py` |
| **Plugin System** | Extensions | `plugins/plugin_manager.py` |
| **Policy Engine** | Safety guardrails | `infra/policy_engine.py` |
| **FreeBuff** | Context scratchpad buffer | `utils/freebuff.py` |
| **OpenWork** | Task management + reporting | `utils/freebuff.py → OpenWork` |
| **PaperClip** | File attachment manager | `utils/freebuff.py → PaperClip` |
| **DeepFlow 2.0** | Advanced workflow engine (Prefect) | `workflow/deepflow.py` |
| **Superpowers** | Final autonomous system (top-level) | `core/system.py → UnifiedSuperpowers` |
| **HALO OS** (`context-labs/HALO`) | Hierarchical Agent Loop Optimizer OS | `agents/halo_os.py` |

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                     UNIFIED SUPERPOWERS SYSTEM                      │
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                    HALO OS  (Kernel)                        │   │
│  │  Scheduler · Context Switch · Tool Manager · Audit Log      │   │
│  │  Self-Improvement RLM Loop · Access Controller              │   │
│  └─────────────────────────┬───────────────────────────────────┘   │
│                             │                                       │
│  ┌──────────────────────────▼──────────────────────────────────┐   │
│  │                   TASK ROUTER                               │   │
│  │     Rules-based heuristics + LLM classifier                 │   │
│  └──┬──────────┬────────────┬────────────┬─────────────────────┘   │
│     │          │            │            │                          │
│  ┌──▼──┐  ┌───▼───┐  ┌─────▼────┐ ┌────▼──────────────────────┐   │
│  │Light│  │ Goose │  │OpenHands │ │     HERMES (Brain)         │   │
│  │ning │  │Worker │  │Coding+Dev│ │  Reasoning · Planning      │   │
│  └──┬──┘  └───┬───┘  └─────┬────┘ │  JARVIS decomposition      │   │
│     │         │             │      │  OpenClaude deep path      │   │
│  ┌──▼──────────▼─────────────▼─────┤  Gemma 4 local fallback    │   │
│  │         PICOCLAW + UI-TARS      └───────────────────────────┘   │
│  │    Desktop UI · VaXil Vision                                     │
│  └──────────────────────────────────────────────────────────────┘  │
│                                                                      │
│  ┌────────────────────────────────────────────────────────────────┐ │
│  │               WORKFLOW LAYER                                   │ │
│  │  LangGraph (graph) · CrewAI (crew) · DeepFlow (schedule)       │ │
│  │  Feedback Loop (self-correction) · Ruflow (automation)         │ │
│  └────────────────────────────────────────────────────────────────┘ │
│                                                                      │
│  ┌────────────────────┐  ┌────────────────────────────────────────┐ │
│  │   MEMORY LAYER     │  │          INFRA LAYER                   │ │
│  │  Chroma (vector)   │  │  Docker Sandbox · Jarvis Runtime       │ │
│  │  Redis (fast/queue)│  │  Policy Engine · Plugin System         │ │
│  │  State Manager     │  │  LangSmith · Observability             │ │
│  │  FreeBuff (scratch)│  │  FreeBuff · OpenWork · PaperClip       │ │
│  └────────────────────┘  └────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────────────────┘
```

---

## ⚡ Quick Start

```bash
# 1. Clone
git clone https://github.com/your-org/unified-superpowers.git
cd unified-superpowers

# 2. Install
pip install -e ".[dev]"

# 3. Configure — copy and edit
cp .env.example .env
# Set: ANTHROPIC_API_KEY, OPENAI_API_KEY, LANGCHAIN_API_KEY

# 4. Run a task
superpowers run "Refactor my Python project to use async IO"

# 5. Stream output
superpowers run "Explain LangGraph in 3 paragraphs" --stream

# 6. Force deep reasoning (OpenClaude / Opus)
superpowers run "Design a microservices architecture for a fintech app" --deep

# 7. Check system status
superpowers status

# 8. Run HALO self-improvement cycle
superpowers improve
```

### Python API

```python
import asyncio
from unified_superpowers import UnifiedSuperpowers, SystemConfig

async def main():
    config = SystemConfig()          # reads from .env
    async with UnifiedSuperpowers(config) as system:

        # Simple task
        result = await system.run("Summarise the Transformer architecture")
        print(result["result"])

        # Coding task → auto-routes to OpenHands
        result = await system.run("Write a FastAPI CRUD app for a todo list")
        print(result["result"])

        # UI task → auto-routes to PicoClaw/UI-TARS
        result = await system.run("Take a screenshot and describe what's on screen")
        print(result["result"])

        # Access HALO OS directly
        status = system.halo_os.status()
        print(status)

        # Run HALO self-improvement
        patches = await system.halo_os.improve(system.lightning.raw_llm)
        print(f"Applied {len(patches)} patches")

asyncio.run(main())
```

---

## 🧠 HALO OS — Hierarchical Agent Loop Optimizer

HALO OS is the **kernel layer** of the entire system. Inspired by `context-labs/HALO`, it:

1. **Wraps every agent execution** — each run creates an `AgentProcess` with priority scheduling
2. **Traces every action** — OpenTelemetry-compatible spans flushed to JSONL
3. **Detects failure patterns** — RLM engine analyses traces across runs
4. **Generates patches** — self-healing: prompt patches, config changes, routing fixes
5. **Applies & re-measures** — closes the loop

```python
# Direct HALO OS usage
from unified_superpowers.agents.halo_os import HALO_OS, TaskPriority

halo = HALO_OS(config)

# Spawn a process
async def my_agent(proc):
    return f"Result for: {proc.task}"

result = await halo.run_agent("hermes", "Analyse this dataset", my_agent,
                               priority=TaskPriority.HIGH)

# Trigger self-improvement
patches = await halo.improve(llm_call_fn=my_llm)

# Check kernel state
print(halo.status())
print(halo.audit())
```

---

## 🔧 Configuration

```yaml
# config.yaml
intelligence:
  primary_provider: anthropic
  primary_model: claude-sonnet-4-20250514
  deep_reasoning_model: claude-opus-4-20250514
  local_engine: ollama
  local_model_name: gemma3:12b

memory:
  chroma_host: localhost
  chroma_port: 8000
  redis_url: redis://localhost:6379/0

workflow:
  router_mode: hybrid          # rules | llm | hybrid
  enable_self_correction: true
  max_correction_rounds: 3

ui_vision:
  enable_ui_control: false     # set true to enable PicoClaw/UI-TARS

infra:
  sandbox_image: python:3.12-slim
  sandbox_mem_limit: 512m

policy:
  content_filter_level: medium
  allow_code_execution: true
  allow_shell_commands: false
```

---

## 📁 Project Structure

```
unified_superpowers/
├── __init__.py
├── core/
│   ├── system.py          ← UnifiedSuperpowers (top-level orchestrator)
│   ├── config.py          ← SystemConfig (all sub-configs)
│   └── task_router.py     ← TaskRouter + AgentRole
├── agents/
│   ├── halo_os.py         ← HALO OS Kernel + HALO_OS façade  ⭐ NEW
│   ├── hermes_agent.py    ← Hermes + OpenClaude + JARVIS planning
│   ├── lightning_agent.py ← LightningAgent (fast path)
│   ├── goose_agent.py     ← Goose (background worker)
│   ├── openhands_adapter.py← OpenHands (coding/dev)
│   └── picoclaw_agent.py  ← PicoClaw + UI-TARS (UI control)
├── memory/
│   ├── chroma_store.py    ← Chroma vector store
│   ├── redis_bus.py       ← Redis fast memory + queue
│   └── state_manager.py   ← (embedded in redis_bus.py)
├── workflow/
│   ├── langgraph_engine.py← LangGraph decision graph
│   ├── crewai_engine.py   ← CrewAI crew orchestration
│   ├── deepflow.py        ← DeepFlow 2.0 / Prefect / Ruflow
│   └── feedback_loop.py   ← Self-correction loop
├── vision/
│   └── vaxil.py           ← VaXil vision layer (image, OCR)
├── infra/
│   ├── sandbox.py         ← Docker sandbox + Jarvis Runtime
│   └── policy_engine.py   ← Policy Engine (safety)
├── plugins/
│   └── plugin_manager.py  ← Plugin System (extensions)
├── utils/
│   ├── observability.py   ← LangSmith + structlog + CLI
│   ├── graphify.py        ← Graphify (Mermaid diagrams)
│   └── freebuff.py        ← FreeBuff + OpenWork + PaperClip
└── pyproject.toml         ← All dependencies unified
```

---

## 🔁 Routing Logic

| Task pattern | → Agent | Why |
|---|---|---|
| "what is", "summarise", "translate" | LightningAgent | Fast, stateless |
| "write code", "debug", "git", "npm" | OpenHands | CodeAct loop |
| "click", "screenshot", "desktop" | PicoClaw + UI-TARS | UI control |
| scheduled / background | Goose | Low-overhead worker |
| "analyse", "plan", "architect" | Hermes | Deep reasoning |
| complexity > 0.85 | LangGraph → CrewAI | Multi-agent crew |

---

## 🛡️ Safety

The **Policy Engine** gates every request:
- Token limit enforcement
- Content filter (off / low / medium / high)
- Domain blocklist
- Shell command gating (disabled by default)
- HALO OS Access Controller (per-tool, per-agent permissions)

---

## 📊 Observability

| Layer | Tool | What it captures |
|---|---|---|
| Traces | LangSmith | LLM calls, tool use, chain steps |
| Metrics | structlog | Latency, errors, token counts |
| Agent OS | HALO kernel | Process spans, failure patterns, patches |
| Workflow | Prefect (DeepFlow) | Scheduled run history, retries |

---

## 🧩 Writing a Plugin

```python
# plugins/my_plugin.py

async def register(system):
    """Called at startup — receives the full UnifiedSuperpowers instance."""
    print("my_plugin loaded!")

async def on_task_complete(task: str, result: str):
    """Hook called after every task finishes."""
    print(f"Task done: {task[:40]}")
```

Drop the file in `plugins/` — it auto-loads on startup.

---

## 🗺️ Roadmap

- [ ] MCP (Model Context Protocol) tool server integration
- [ ] A2A (Agent-to-Agent) protocol support
- [ ] MemOS persistent memory layer
- [ ] Voice interface (ElevenLabs + Whisper)
- [ ] Mobile agent (Claude for Android)
- [ ] Superpowers Cloud deployment (Kubernetes + Helm)
- [ ] Visual HALO dashboard (Graphify web UI)

---

## 📜 License

MIT — all integrated OSS components retain their original licenses.
