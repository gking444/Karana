# ADR-004: Retry Policy with Exponential Backoff + Jitter

**Status:** Accepted | **Date:** 2025-05 | **Deciders:** Architect Agent

## Context
Transient LLM API errors (429 rate-limit, 503 Service Unavailable) should be
retried, but naive retry creates thundering herd storms when many agents retry
simultaneously.

## Decision
Implement `RetryPolicy` with full-jitter exponential backoff:
  delay = random(0, min(cap, base * 2^attempt))
  base=1s, cap=30s, max_attempts=3

## Consequences
**Positive:** Retries are spread across a time window; no thundering herd.
**Negative:** P99 latency increases by up to 3×30s=90s in worst case.
**Mitigation:** Only retry on 429/503/network errors; never retry on 4xx.
