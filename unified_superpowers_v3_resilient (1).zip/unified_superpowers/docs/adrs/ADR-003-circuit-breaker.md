# ADR-003: Circuit Breaker for External API Calls

**Status:** Accepted | **Date:** 2025-05 | **Deciders:** Architect Agent

## Context
LLM API calls (Anthropic, OpenAI) can fail transiently. Without a circuit
breaker, a sustained outage causes thread pool exhaustion as all coroutines
pile up waiting for timeouts.

## Decision
Implement `CircuitBreaker` with three states: CLOSED (normal), OPEN (failing,
fast-fail), HALF-OPEN (testing recovery). Thresholds: 5 failures in 60s opens
the breaker; auto-reset after 60s in OPEN state.

## Consequences
**Positive:** Prevents cascade failure; LLM outage doesn't crash the system.
**Negative:** False positives on single slow request may open breaker early.
**Mitigation:** Use failure_threshold=5 and require consecutive failures.
