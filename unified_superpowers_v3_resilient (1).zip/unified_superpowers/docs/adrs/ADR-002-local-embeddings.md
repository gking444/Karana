# ADR-002: Local Hash Embeddings for Chroma

**Status:** Accepted | **Date:** 2025-05 | **Deciders:** Architect Agent

## Context
Chroma's default embedding function (all-MiniLM-L6-v2) downloads a 21 MB ONNX
model on first use. In air-gapped, CI, and restricted-network environments this
download fails silently or produces corrupt files.

## Decision
Ship a `HashEmbeddingFunction` that produces 512-dim unit-normalised vectors
using SHA-256 seeded hashing. Falls back to SentenceTransformer if available.

## Consequences
**Positive:** Zero network, zero deps, deterministic, works everywhere.
**Negative:** No semantic similarity — cosine scores reflect hash proximity only.
**Mitigation:** In production with network access, SentenceTransformer is preferred
and loaded first. HashEF is the fallback, not the default.
