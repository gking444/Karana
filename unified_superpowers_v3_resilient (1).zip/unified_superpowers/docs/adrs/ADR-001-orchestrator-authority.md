# ADR-001: Single Orchestration Authority

**Status:** Accepted | **Date:** 2025-05 | **Deciders:** Architect Agent

## Context
Four workflow engines (LangGraph, CrewAI, DeepFlow, FeedbackLoop) all had the
ability to invoke agents, manage state, and retry tasks — causing ambiguous
ownership and split-brain scheduling under load.

## Decision
Introduce a single `Orchestrator` class with four strict layer contracts:
- Layer 1 (Runtime): LangGraph — executes steps
- Layer 2 (Strategy): CrewAI — plans only, returns string
- Layer 3 (Batch): DeepFlow — schedules into Redis queue
- Layer 4 (Middleware): FeedbackLoop — post-processes finished result

## Consequences
**Positive:** No ambiguity about who owns a task. Global cancel_all() works.
**Negative:** All task flow routes through Orchestrator — single point of contention.
**Mitigation:** BoundedTaskQueue provides backpressure; HALO OS handles scheduling.
