# Product Requirements Document — Unified Superpowers
**Version:** 2.0 | **Status:** Production-Ready | **Phase:** 1 of 9

---

## 1. Project Overview
Unified Superpowers is a **production-grade autonomous AI agent orchestration system** that integrates 30+ open-source AI frameworks into a single coherent platform. It routes tasks to specialised agents (coding, UI automation, reasoning, background work), enforces safety policies, persists memory across sessions, and self-improves via the HALO OS kernel.

---

## 2. Feature Specifications

### P0 — Must Have (System Cannot Ship Without)
| ID | Feature | Acceptance Criteria |
|---|---|---|
| F-001 | Task routing | Given any natural-language task, route to correct agent within 50ms |
| F-002 | Global cancellation | Any in-flight task cancelled within 100ms of cancel() call |
| F-003 | Backpressure | Queue full → QueueFullError returned, never silent OOM |
| F-004 | Policy enforcement | SQLi/XSS/shell-injection blocked; clean tasks pass; rate limit enforced |
| F-005 | Vector memory | add() + query() work offline (no network) via local embeddings |
| F-006 | Health endpoints | /health/liveness + /health/readiness respond in < 10ms |
| F-007 | Graceful shutdown | All tasks drained within 30s of SIGTERM; no data corruption |
| F-008 | Circuit breaker | LLM API failures trip breaker; fallback served; auto-reset after 60s |

### P1 — Should Have
| ID | Feature | Acceptance Criteria |
|---|---|---|
| F-009 | HALO self-improvement | Trace analysis generates patches every N runs |
| F-010 | Plugin sandbox | Subprocess isolation; timeout kill; manifest required |
| F-011 | Distributed locking | No split-brain; lease auto-expires on crash |
| F-012 | Observability pipeline | Every span carries trace_id; timeline renders per trace |
| F-013 | Schema migration | Idempotent; version tracked; runs at startup |

### P2 — Nice to Have
| ID | Feature | Acceptance Criteria |
|---|---|---|
| F-014 | Multi-region failover | Detects region failure; reroutes within 10s |
| F-015 | Voice interface | Whisper → task → TTS response |

---

## 3. Non-Functional Requirements (SLOs)

| Metric | SLO Target | Measurement |
|---|---|---|
| Task routing latency | < 50ms p95 (rules), < 500ms p95 (LLM) | `elapsed_s` in result |
| API response time | < 100ms p95 for /health | Server-side timer |
| Uptime | 99.9% (< 9h downtime/year) | Liveness probe |
| Queue full rejection | 0 silent OOM errors | QueueFullError always raised |
| Policy enforcement | 100% of injections blocked | Test suite |
| LLM timeout | < 30s hard timeout | wait_for wrapper |
| Memory growth | < 5% per 1000 tasks (soak test) | tracemalloc |
| Cancellation propagation | < 100ms to all children | Event.wait() test |
| Plugin timeout | Killed within PLUGIN_TIMEOUT_S + 500ms | subprocess test |

---

## 4. Abuse Cases & Edge Cases

| ID | Scenario | Expected Behaviour |
|---|---|---|
| A-001 | 10,000 tasks submitted simultaneously | Queue fills to maxsize; excess rejected with QueueFullError |
| A-002 | Task with 1MB payload | Token limit check rejects before LLM call |
| A-003 | UNION SELECT in task string | PolicyViolation raised; no LLM call made |
| A-004 | Plugin with infinite loop | Killed after PLUGIN_TIMEOUT_S; RuntimeError returned |
| A-005 | Redis down for 60s | In-process fallback; no crash; reconnects automatically |
| A-006 | Chroma unreachable | In-memory hash embeddings; add/query still work |
| A-007 | LLM returns 500 for 30s | Circuit breaker opens; fallback response served |
| A-008 | cancel() during LLM stream | CancelledError propagated; no zombie coroutines |
| A-009 | Plugin declares EXECUTE_CODE without approval | Blocked at load time; not executed |
| A-010 | Two workers elect leader simultaneously | Only one becomes leader; other remains follower |
| A-011 | Schema version mismatch on restart | Migration runs forward-only; never destructive |
| A-012 | Task containing path traversal `../../etc/passwd` | VaXil rejects; policy may catch; logged |
| A-013 | 100 concurrent connect() calls to Redis | Double-checked lock ensures single connection |
| A-014 | CancelledError propagation across 3-deep child contexts | All 3 children cancelled within 100ms |

---

## 5. Risk Register

| ID | Risk | Severity | Probability | Mitigation | Status |
|---|---|---|---|---|---|
| R-001 | LLM API key leaked in logs | Critical | Medium | Masking in structlog; source scan test | ✅ Mitigated |
| R-002 | Plugin RCE via malicious plugin | Critical | Low | Subprocess sandbox + manifest + capability guard | ✅ Mitigated |
| R-003 | Redis split-brain on network partition | High | Low | DistributedLock + leader election TTL | ✅ Mitigated |
| R-004 | LLM timeout deadlocks event loop | High | Medium | asyncio.wait_for + CancelledError handler | ✅ Mitigated |
| R-005 | Chroma ONNX download fails in air-gap | High | High | HashEmbeddingFunction local fallback | ✅ Mitigated |
| R-006 | asyncio.Semaphore on wrong loop | High | High | Lazy init in _ensure_primitives() | ✅ Mitigated |
| R-007 | Queue backpressure not enforced | High | Medium | BoundedTaskQueue with QueueFullError | ✅ Mitigated |
| R-008 | No circuit breaker on LLM calls | High | Medium | CircuitBreaker class | ✅ Mitigated |
| R-009 | No retry + jitter on transient failures | Medium | High | RetryPolicy class | ✅ Mitigated |
| R-010 | Health check endpoint missing | Medium | High | FastAPI /health | ✅ Mitigated |
| R-011 | No CI/CD quality gate | Medium | High | GitHub Actions | ✅ Mitigated |
