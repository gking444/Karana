"""
tests/test_architecture.py
────────────────────────────
Architecture validation tests.

Tests prove the structural fixes from the review:
  1. Single orchestration authority
  2. Layer contract enforcement (runtime/strategy/batch/middleware)
  3. Global cancellation propagates to children
  4. Backpressure rejects at capacity
  5. Plugin sandbox isolation
  6. Observability pipeline emits correlation IDs
  7. Distributed lock correctness
  8. Leader election uniqueness
  9. Schema migration is idempotent
 10. Retention enforcer TTL application
"""

from __future__ import annotations

import asyncio
import json
import tempfile
import time
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


# ══════════════════════════════════════════════════════════════════════════════
# 1. Single orchestration authority
# ══════════════════════════════════════════════════════════════════════════════

class TestSingleOrchestrationAuthority:
    """
    Prove that only Orchestrator starts agent execution.
    CrewAI, DeepFlow, and FeedbackLoop must NOT invoke agents directly.
    """

    def test_orchestrator_is_the_only_run_entry(self):
        """system.run() must delegate entirely to self.orchestrator.run()."""
        import inspect
        from unified_superpowers.core import system as sys_mod
        src = inspect.getsource(sys_mod)

        # system.py must reference orchestrator.run — not call agents directly
        assert "self.orchestrator" in src
        # The old pattern of directly calling agent.run in system.py should be gone
        # (agents are now only called via orchestrator → langgraph → agent)
        assert "await self.hermes.run(" not in src or "orchestrator" in src

    def test_crewai_adapter_does_not_call_agents(self):
        """CrewAIStrategyAdapter.plan() must call hermes only — not other agents."""
        import inspect
        from unified_superpowers.core.orchestrator import CrewAIStrategyAdapter
        src = inspect.getsource(CrewAIStrategyAdapter)
        # Must only call hermes — never openhands, picoclaw, goose, lightning
        for forbidden in ("openhands", "picoclaw", "goose", ".lightning"):
            assert forbidden not in src.lower(), \
                f"CrewAIStrategyAdapter references '{forbidden}' — breaks layer contract"

    def test_deepflow_adapter_does_not_execute_agents(self):
        """DeepFlowBatchAdapter.schedule() must only enqueue — never call run()."""
        import inspect
        from unified_superpowers.core.orchestrator import DeepFlowBatchAdapter
        src = inspect.getsource(DeepFlowBatchAdapter)
        # Must push to redis, not run agents
        assert "push_task" in src
        assert "agent.run" not in src

    def test_feedback_loop_does_not_create_tasks(self):
        """FeedbackLoopMiddlewareAdapter.apply() must not call orchestrator.run()."""
        import inspect
        from unified_superpowers.core.orchestrator import FeedbackLoopMiddlewareAdapter
        src = inspect.getsource(FeedbackLoopMiddlewareAdapter)
        assert "orchestrator.run" not in src
        assert "create_task" not in src

    @pytest.mark.asyncio
    async def test_orchestrator_owns_context_registry(self):
        """Every task creates an ExecutionContext tracked by the orchestrator."""
        from unified_superpowers.core.orchestrator import Orchestrator
        from unified_superpowers.core.task_router import AgentRole, RoutingDecision

        mock_agent = AsyncMock(return_value="done")
        orch = Orchestrator(
            agents={AgentRole.LIGHTNING: MagicMock(run=mock_agent)},
            runtime=_make_runtime("done"),
            strategy=_make_strategy("plan"),
            batch=_make_batch(),
            middleware=_make_middleware("done"),
            memory_write=AsyncMock(),
        )

        result, ctx = await orch.run(
            "test task",
            decision=RoutingDecision(
                primary=AgentRole.LIGHTNING, complexity=0.2
            ),
        )
        assert ctx.context_id is not None
        assert len(ctx.context_id) > 4
        assert result == "done"


# ══════════════════════════════════════════════════════════════════════════════
# 2. ExecutionContext — cancellation propagates to children
# ══════════════════════════════════════════════════════════════════════════════

class TestGlobalCancellation:
    """Fix [NO_CANCELLATION_MODEL]"""

    @pytest.mark.asyncio
    async def test_cancel_sets_event(self):
        from unified_superpowers.core.execution_context import ExecutionContext, ContextStatus
        ctx = ExecutionContext(task="test")
        await ctx.cancel("test reason")
        assert ctx.status == ContextStatus.CANCELLED
        assert ctx.is_cancelled

    @pytest.mark.asyncio
    async def test_cancel_propagates_to_children(self):
        from unified_superpowers.core.execution_context import (
            ExecutionContext, ContextStatus
        )
        parent = ExecutionContext(task="parent")
        child1 = parent.spawn_child("child1")
        child2 = parent.spawn_child("child2")
        grandchild = child1.spawn_child("grandchild")

        await parent.cancel("top-level cancel")

        assert parent.is_cancelled
        assert child1.is_cancelled
        assert child2.is_cancelled
        assert grandchild.is_cancelled

    @pytest.mark.asyncio
    async def test_wait_cancelled_unblocks(self):
        from unified_superpowers.core.execution_context import ExecutionContext
        ctx = ExecutionContext(task="blocking task")

        async def background():
            await ctx.wait_cancelled()
            return "unblocked"

        task = asyncio.create_task(background())
        await asyncio.sleep(0)
        await ctx.cancel("test")
        result = await asyncio.wait_for(task, timeout=1.0)
        assert result == "unblocked"

    @pytest.mark.asyncio
    async def test_check_cancelled_raises(self):
        from unified_superpowers.core.execution_context import ExecutionContext
        ctx = ExecutionContext(task="t")
        await ctx.cancel()
        with pytest.raises(asyncio.CancelledError):
            ctx.check_cancelled()

    @pytest.mark.asyncio
    async def test_cancel_all_cancels_active_contexts(self):
        from unified_superpowers.core.orchestrator import Orchestrator
        from unified_superpowers.core.task_router import AgentRole, RoutingDecision
        from unified_superpowers.core.execution_context import ContextStatus

        gate = asyncio.Event()

        async def slow_agent_run(*a, **kw):
            await gate.wait()
            return "late result"

        orch = Orchestrator(
            agents={AgentRole.HERMES: MagicMock(run=slow_agent_run)},
            runtime=_make_runtime_slow(gate),
            strategy=_make_strategy("plan"),
            batch=_make_batch(),
            middleware=_make_middleware("x"),
            memory_write=AsyncMock(),
        )

        # Start a task but don't wait for it
        run_task = asyncio.create_task(
            orch.run("slow task",
                     decision=RoutingDecision(primary=AgentRole.HERMES,
                                              complexity=0.9))
        )
        await asyncio.sleep(0.05)

        cancelled = await orch.cancel_all("test_shutdown")
        gate.set()   # unblock so task can actually cancel cleanly
        assert cancelled >= 0   # may be 0 if task finished before cancel

        try:
            await run_task
        except (asyncio.CancelledError, Exception):
            pass

    @pytest.mark.asyncio
    async def test_deadline_expired_raises(self):
        from unified_superpowers.core.execution_context import ExecutionContext
        ctx = ExecutionContext(task="t", deadline_at=time.monotonic() - 1.0)
        with pytest.raises(TimeoutError):
            ctx.check_deadline()

    @pytest.mark.asyncio
    async def test_child_inherits_parent_deadline(self):
        from unified_superpowers.core.execution_context import ExecutionContext
        parent = ExecutionContext(
            task="parent", deadline_at=time.monotonic() + 10.0
        )
        child = parent.spawn_child("child", deadline_at=time.monotonic() + 100.0)
        # Child must inherit parent's tighter deadline
        assert child.deadline_at == parent.deadline_at


# ══════════════════════════════════════════════════════════════════════════════
# 3. Backpressure — BoundedTaskQueue
# ══════════════════════════════════════════════════════════════════════════════

class TestBackpressure:
    """Fix [NO_BACKPRESSURE]"""

    @pytest.mark.asyncio
    async def test_queue_full_raises_queue_full_error(self):
        from unified_superpowers.core.orchestrator import (
            BoundedTaskQueue, QueueFullError
        )
        from unified_superpowers.core.execution_context import ExecutionContext
        q = BoundedTaskQueue(maxsize=2)
        ctx = ExecutionContext(task="t")

        await q.enqueue(ctx)
        q.task_done()
        await q.enqueue(ctx)
        q.task_done()

        # Third enqueue when full must raise
        with pytest.raises(QueueFullError, match="capacity"):
            await q.enqueue(ctx)

    @pytest.mark.asyncio
    async def test_pressure_gauge(self):
        from unified_superpowers.core.orchestrator import BoundedTaskQueue
        from unified_superpowers.core.execution_context import ExecutionContext
        q = BoundedTaskQueue(maxsize=10)
        assert q.pressure == 0.0

        for _ in range(5):
            ctx = ExecutionContext(task="t")
            await q.enqueue(ctx)
        assert abs(q.pressure - 0.5) < 0.01

    @pytest.mark.asyncio
    async def test_rejected_total_increments(self):
        from unified_superpowers.core.orchestrator import (
            BoundedTaskQueue, QueueFullError
        )
        from unified_superpowers.core.execution_context import ExecutionContext
        q = BoundedTaskQueue(maxsize=1)
        await q.enqueue(ExecutionContext(task="first"))

        for _ in range(3):
            try:
                await q.enqueue(ExecutionContext(task="rejected"))
            except QueueFullError:
                pass

        assert q.rejected_total == 3

    @pytest.mark.asyncio
    async def test_token_budget_exhaustion_raises(self):
        from unified_superpowers.core.execution_context import ExecutionContext
        ctx = ExecutionContext(task="t", token_budget=100)
        await ctx.consume_tokens(80)
        with pytest.raises(ResourceWarning, match="budget exhausted"):
            await ctx.consume_tokens(30)

    @pytest.mark.asyncio
    async def test_token_pressure_gauge(self):
        from unified_superpowers.core.execution_context import ExecutionContext
        ctx = ExecutionContext(task="t", token_budget=1000)
        assert ctx.token_pressure == 0.0
        await ctx.consume_tokens(500)
        assert abs(ctx.token_pressure - 0.5) < 0.01


# ══════════════════════════════════════════════════════════════════════════════
# 4. Plugin sandbox isolation
# ══════════════════════════════════════════════════════════════════════════════

class TestPluginSandbox:
    """Fix [PLUGIN_ISOLATION_MISSING] + [DYNAMIC_IMPORTS_DANGEROUS]"""

    @pytest.mark.asyncio
    async def test_plugin_without_manifest_is_rejected(self, tmp_path):
        from unified_superpowers.plugins.plugin_sandbox import PluginManager
        plugin_file = tmp_path / "no_manifest_plugin.py"
        plugin_file.write_text("def register(system): pass\n")

        mgr = PluginManager([tmp_path])
        await mgr.discover_and_load()
        assert "no_manifest_plugin" not in {
            p["name"] for p in mgr.list_plugins()
        }

    @pytest.mark.asyncio
    async def test_high_risk_capability_without_approval_blocked(self, tmp_path):
        from unified_superpowers.plugins.plugin_sandbox import PluginManager
        plugin_file = tmp_path / "risky.py"
        plugin_file.write_text("def register(system): pass\n")
        manifest = tmp_path / "risky.manifest.json"
        manifest.write_text(json.dumps({
            "name": "risky",
            "capabilities": ["execute_code"],   # high-risk
            "hooks": ["on_task_complete"],
            "operator_approved": False,          # NOT approved
        }))

        mgr = PluginManager([tmp_path], allow_high_risk=False)
        await mgr.discover_and_load()
        assert "risky" not in {p["name"] for p in mgr.list_plugins()}

    @pytest.mark.asyncio
    async def test_safe_plugin_loads_with_manifest(self, tmp_path):
        from unified_superpowers.plugins.plugin_sandbox import PluginManager
        plugin_file = tmp_path / "safe_plugin.py"
        plugin_file.write_text("async def on_task_complete(**kwargs): return 'ok'\n")
        manifest = tmp_path / "safe_plugin.manifest.json"
        manifest.write_text(json.dumps({
            "name": "safe_plugin",
            "capabilities": ["read_memory"],
            "hooks": ["on_task_complete"],
        }))

        mgr = PluginManager([tmp_path])
        await mgr.discover_and_load()
        names = {p["name"] for p in mgr.list_plugins()}
        assert "safe_plugin" in names

    @pytest.mark.asyncio
    async def test_plugin_timeout_kills_subprocess(self, tmp_path):
        from unified_superpowers.plugins.plugin_sandbox import (
            SandboxedPlugin, PluginManifest, Capability
        )
        import unified_superpowers.plugins.plugin_sandbox as psm
        psm.PLUGIN_TIMEOUT_S = 0.5   # very short for test

        plugin_file = tmp_path / "slow.py"
        plugin_file.write_text(
            "import time\ndef on_task(**kw): time.sleep(999)\n"
        )
        manifest = PluginManifest(
            name="slow", capabilities=[Capability.READ_MEMORY],
            hooks=["on_task"]
        )
        sandboxed = SandboxedPlugin(plugin_file, manifest)
        with pytest.raises(RuntimeError):  # timed out or non-zero exit
            await sandboxed.call_hook("on_task")

    def test_manifest_capability_check_raises_on_undeclared(self):
        from unified_superpowers.plugins.plugin_sandbox import (
            PluginManifest, Capability
        )
        manifest = PluginManifest(
            name="limited",
            capabilities=[Capability.READ_MEMORY],
            hooks=["hook"],
        )
        with pytest.raises(PermissionError, match="execute_code"):
            manifest.check_capability(Capability.EXECUTE_CODE)

    def test_manifest_capability_check_passes_for_declared(self):
        from unified_superpowers.plugins.plugin_sandbox import (
            PluginManifest, Capability
        )
        manifest = PluginManifest(
            name="network_plugin",
            capabilities=[Capability.NETWORK, Capability.READ_MEMORY],
            hooks=["hook"],
        )
        manifest.check_capability(Capability.NETWORK)  # must not raise
        manifest.check_capability(Capability.READ_MEMORY)


# ══════════════════════════════════════════════════════════════════════════════
# 5. Observability pipeline — correlation IDs + timeline
# ══════════════════════════════════════════════════════════════════════════════

class TestObservabilityPipeline:
    """Fix [OBSERVABILITY_PIPELINE_INCOMPLETE]"""

    @pytest.mark.asyncio
    async def test_span_carries_trace_id(self):
        from unified_superpowers.utils.observability_pipeline import (
            Tracer, SpanKind
        )
        tracer = Tracer(context_id="test-ctx-001")
        with tracer.span("agent.hermes", SpanKind.AGENT) as s:
            s.set_attr("model", "claude-sonnet")

        spans = tracer.all_spans()
        assert len(spans) == 1
        assert spans[0].trace_id == "test-ctx-001"
        assert spans[0].attributes["model"] == "claude-sonnet"

    @pytest.mark.asyncio
    async def test_nested_spans_have_parent_ids(self):
        from unified_superpowers.utils.observability_pipeline import (
            Tracer, SpanKind
        )
        tracer = Tracer(context_id="ctx-002")
        with tracer.span("outer", SpanKind.TASK) as outer:
            outer_id = outer.span_id
            with tracer.span("inner", SpanKind.LLM) as inner:
                inner_id = inner.span_id

        spans = tracer.all_spans()
        span_dict = {s.span_id: s for s in spans}
        assert span_dict[inner_id].parent_span == outer_id

    @pytest.mark.asyncio
    async def test_collector_ingests_and_timelines(self):
        from unified_superpowers.utils.observability_pipeline import (
            ObservabilityCollector, Tracer, SpanKind
        )
        coll = ObservabilityCollector()

        tracer = Tracer(context_id="ctx-003")
        with tracer.span("step1", SpanKind.AGENT):
            pass
        with tracer.span("step2", SpanKind.LLM):
            pass

        await coll.ingest_tracer(tracer)
        timeline = coll.get_timeline("ctx-003")
        assert len(timeline) == 2
        # Timeline must be sorted by start_ns
        assert timeline[0]["start_ns"] <= timeline[1]["start_ns"]

    @pytest.mark.asyncio
    async def test_collector_drops_when_full_without_blocking(self):
        from unified_superpowers.utils.observability_pipeline import (
            ObservabilityCollector, Span
        )
        coll = ObservabilityCollector(buffer_maxsize=3)
        for i in range(10):
            s = Span(trace_id=f"t{i}", name=f"span{i}")
            s.finish()
            await coll.ingest(s)
        assert coll._dropped_spans == 7

    @pytest.mark.asyncio
    async def test_health_returns_metrics(self):
        from unified_superpowers.utils.observability_pipeline import (
            ObservabilityCollector
        )
        coll = ObservabilityCollector()
        h = coll.health()
        assert "total_spans"   in h
        assert "queue_pressure"in h
        assert "running"       in h

    @pytest.mark.asyncio
    async def test_ascii_timeline_renders(self):
        from unified_superpowers.utils.observability_pipeline import (
            ObservabilityCollector, Span
        )
        coll = ObservabilityCollector()

        async def _setup():
            for i, name in enumerate(["plan", "execute", "correct"]):
                s = Span(trace_id="vis-001", name=name)
                s.start_ns = time.time_ns() + i * 1_000_000
                s.finish()
                await coll.ingest(s)

        await _setup()
        output = coll.render_timeline_ascii("vis-001")
        assert "vis-001" in output
        assert "plan" in output


# ══════════════════════════════════════════════════════════════════════════════
# 6. Distributed lock — mutual exclusion
# ══════════════════════════════════════════════════════════════════════════════

class TestDistributedLock:
    """Fix [DISTRIBUTED_COORDINATION_MISSING]"""

    @pytest.mark.asyncio
    async def test_local_fallback_mutual_exclusion(self):
        """Without Redis, the in-process fallback must still enforce exclusion."""
        from unified_superpowers.infra.distributed import DistributedLock

        redis_bus = MagicMock()
        redis_bus._redis = None   # force local fallback
        lock = DistributedLock(redis_bus, "test_lock", ttl_ms=5_000)

        inside_count = 0
        max_inside   = 0

        async def critical_section():
            nonlocal inside_count, max_inside
            async with lock.acquire(timeout=2.0):
                inside_count += 1
                max_inside = max(max_inside, inside_count)
                await asyncio.sleep(0.01)
                inside_count -= 1

        await asyncio.gather(*[critical_section() for _ in range(5)])
        assert max_inside == 1, \
            f"Lock allowed {max_inside} concurrent holders — not mutually exclusive"

    @pytest.mark.asyncio
    async def test_timeout_raises_lock_not_acquired(self):
        from unified_superpowers.infra.distributed import (
            DistributedLock, LockNotAcquiredError
        )
        redis_bus = MagicMock()
        redis_bus._redis = None
        lock = DistributedLock(redis_bus, "timeout_lock", ttl_ms=5_000)

        gate = asyncio.Event()

        async def holder():
            async with lock.acquire(timeout=5.0):
                await gate.wait()

        hold_task = asyncio.create_task(holder())
        await asyncio.sleep(0.05)   # let holder grab lock

        with pytest.raises(LockNotAcquiredError):
            async with lock.acquire(timeout=0.1):
                pass

        gate.set()
        await hold_task

    @pytest.mark.asyncio
    async def test_lock_released_on_exception(self):
        from unified_superpowers.infra.distributed import DistributedLock
        redis_bus = MagicMock()
        redis_bus._redis = None
        lock = DistributedLock(redis_bus, "exc_lock")

        try:
            async with lock.acquire(timeout=1.0):
                raise ValueError("inner error")
        except ValueError:
            pass

        # Lock must be free — this must not timeout
        await asyncio.wait_for(
            _acquire_and_release(lock), timeout=1.0
        )


async def _acquire_and_release(lock):
    async with lock.acquire(timeout=0.5):
        return True


# ══════════════════════════════════════════════════════════════════════════════
# 7. Leader election — at most one leader
# ══════════════════════════════════════════════════════════════════════════════

class TestLeaderElection:
    """Fix [DISTRIBUTED_COORDINATION_MISSING] — no split-brain"""

    @pytest.mark.asyncio
    async def test_single_worker_becomes_leader(self):
        from unified_superpowers.infra.distributed import LeaderElection
        redis_bus = MagicMock()
        redis_bus._redis = None   # local mode — always leader
        election = LeaderElection(redis_bus, "test_role")
        await election.start()
        assert election.is_leader
        await election.stop()

    @pytest.mark.asyncio
    async def test_resignation_clears_leader_flag(self):
        from unified_superpowers.infra.distributed import LeaderElection
        redis_bus = MagicMock()
        redis_bus._redis = None
        election = LeaderElection(redis_bus, "resign_role")
        await election.start()
        assert election.is_leader
        await election.stop()
        assert not election.is_leader


# ══════════════════════════════════════════════════════════════════════════════
# 8. Schema migration — idempotent
# ══════════════════════════════════════════════════════════════════════════════

class TestSchemaMigration:
    """Fix [PERSISTENCE_GOVERNANCE]"""

    @pytest.mark.asyncio
    async def test_migration_creates_tables(self, tmp_path):
        from unified_superpowers.memory.persistence import (
            SchemaMigrator, CURRENT_SCHEMA_VERSION
        )
        db_path = tmp_path / "test.db"
        migrator = SchemaMigrator(db_path)

        try:
            import aiosqlite
        except ImportError:
            pytest.skip("aiosqlite not installed")

        await migrator.migrate()

        async with aiosqlite.connect(str(db_path)) as db:
            async with db.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            ) as cur:
                tables = {row[0] async for row in cur}

        assert "state"      in tables
        assert "task_log"   in tables
        assert "plugin_state" in tables

    @pytest.mark.asyncio
    async def test_migration_is_idempotent(self, tmp_path):
        from unified_superpowers.memory.persistence import SchemaMigrator
        db_path = tmp_path / "idem.db"
        migrator = SchemaMigrator(db_path)

        try:
            import aiosqlite
        except ImportError:
            pytest.skip("aiosqlite not installed")

        await migrator.migrate()
        await migrator.migrate()   # must not raise or duplicate tables

    def test_version_file_written(self, tmp_path):
        from unified_superpowers.memory.persistence import (
            SchemaMigrator, CURRENT_SCHEMA_VERSION, SCHEMA_FILE
        )
        import unified_superpowers.memory.persistence as pm
        orig_schema_file = pm.SCHEMA_FILE
        pm.SCHEMA_FILE = tmp_path / "schema_version.json"

        migrator = SchemaMigrator(tmp_path / "v.db")
        migrator._write_version(CURRENT_SCHEMA_VERSION)
        read_back = migrator._read_version()
        assert read_back == CURRENT_SCHEMA_VERSION

        pm.SCHEMA_FILE = orig_schema_file   # restore


# ══════════════════════════════════════════════════════════════════════════════
# 9. Transactional writer
# ══════════════════════════════════════════════════════════════════════════════

class TestTransactionalWriter:
    """Fix [SHARED_STATE_RISK] — atomic multi-key writes"""

    @pytest.mark.asyncio
    async def test_atomic_write_falls_back_without_redis(self):
        from unified_superpowers.memory.persistence import TransactionalWriter

        redis_bus = MagicMock()
        redis_bus._redis = None
        redis_bus.set = AsyncMock()
        writer = TransactionalWriter(redis_bus)

        result = await writer.atomic_write(
            {"key1": "val1", "key2": "val2"}, ttl_s=60
        )
        assert result is True
        assert redis_bus.set.call_count == 2


# ══════════════════════════════════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════════════════════════════════

def _make_runtime(result: str):
    from unified_superpowers.core.orchestrator import IRuntimeLayer
    class R(IRuntimeLayer):
        async def run(self, task, ctx, decision, agents):
            return result
    return R()

def _make_runtime_slow(gate: asyncio.Event):
    from unified_superpowers.core.orchestrator import IRuntimeLayer
    class R(IRuntimeLayer):
        async def run(self, task, ctx, decision, agents):
            await gate.wait()
            return "slow done"
    return R()

def _make_strategy(result: str):
    from unified_superpowers.core.orchestrator import IStrategyLayer
    class S(IStrategyLayer):
        async def plan(self, task, ctx):
            return result
    return S()

def _make_batch():
    from unified_superpowers.core.orchestrator import IBatchLayer
    class B(IBatchLayer):
        async def schedule(self, task, cron, ctx):
            return "scheduled"
    return B()

def _make_middleware(result: str):
    from unified_superpowers.core.orchestrator import IMiddlewareHook
    class M(IMiddlewareHook):
        async def apply(self, task, r, ctx):
            return result
    return M()
