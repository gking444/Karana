"""
tests/test_property.py
───────────────────────
Property-Based Tests  (Phase 5 — QA Agent)

Uses hypothesis for fuzzing-style testing.
If hypothesis is not installed, tests are skipped gracefully.

Properties verified:
  • PolicyEngine: no input crashes the engine (returns either pass or PolicyViolation)
  • TaskRouter: every string routes to a valid AgentRole
  • ExecutionContext: token_pressure always in [0.0, 1.0]
  • HashEmbeddingFunction: output always unit-normalised (L2 norm ≈ 1.0)
  • FreeBuff: write N items → read ≤ N items (maxlen enforced)
  • RetryPolicy: jitter delay always in [0, cap]
"""

from __future__ import annotations

import asyncio
import math
import pytest

try:
    from hypothesis import given, settings, assume
    from hypothesis import strategies as st
    HYPOTHESIS_AVAILABLE = True
except ImportError:
    HYPOTHESIS_AVAILABLE = False

pytestmark = pytest.mark.skipif(
    not HYPOTHESIS_AVAILABLE,
    reason="hypothesis not installed — run: pip install hypothesis"
)


# ══════════════════════════════════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════════════════════════════════

def run(coro):
    """
    Run a coroutine synchronously inside a property test.

    FIX [PROPERTY_TEST_FOUND]: asyncio.get_event_loop() raises
    'RuntimeError: There is no current event loop in thread MainThread'
    on Python 3.12+ when no loop has been set on the thread (the
    deprecated auto-create-on-main-thread behavior was removed).
    hypothesis calls the test function many times outside any async
    context, so there is never a 'current' loop to fetch.

    asyncio.run() is correct here: it creates a brand-new loop for each
    call and closes it on completion — exactly the isolation property-based
    testing wants between examples anyway.
    """
    return asyncio.run(coro)


def _make_policy_engine(level="high"):
    from unified_superpowers.infra.policy_engine import PolicyEngine
    from unittest.mock import MagicMock
    cfg = MagicMock()
    cfg.content_filter_level = level
    cfg.max_tokens_per_request = 8_000
    cfg.max_requests_per_minute = 100_000
    cfg.blocked_domains = []
    return PolicyEngine(cfg)


# ══════════════════════════════════════════════════════════════════════════════
# 1. Policy Engine — never crashes on arbitrary input
# ══════════════════════════════════════════════════════════════════════════════

if HYPOTHESIS_AVAILABLE:
    @given(st.text(min_size=1, max_size=1000))
    @settings(max_examples=200, deadline=1000)
    def test_policy_engine_never_crashes(text):
        """
        Property: PolicyEngine.check(text) either passes or raises
        PolicyViolation/RateLimitExceeded — NEVER raises any other exception.
        """
        from unified_superpowers.infra.policy_engine import (
            PolicyEngine, PolicyViolation, RateLimitExceeded
        )
        pe = _make_policy_engine()
        try:
            run(pe.check(text, caller_key="fuzz"))
        except (PolicyViolation, RateLimitExceeded):
            pass   # expected controlled failures
        except Exception as exc:
            pytest.fail(
                f"PolicyEngine crashed on input {text!r:.60}: "
                f"{type(exc).__name__}: {exc}"
            )

    @given(st.text(min_size=1, max_size=100))
    @settings(max_examples=100, deadline=500)
    def test_task_router_always_returns_valid_role(text):
        """
        Property: TaskRouter.route(text) always returns a RoutingDecision
        with a valid AgentRole — never raises, never returns None.
        """
        from unified_superpowers.core.task_router import TaskRouter, AgentRole
        router = TaskRouter(mode="rules")
        decision = run(router.route(text))
        assert decision is not None
        assert decision.primary in list(AgentRole)
        assert 0.0 <= decision.complexity <= 1.0

    @given(st.integers(min_value=0, max_value=100_000))
    @settings(max_examples=100, deadline=500)
    def test_token_pressure_always_in_range(tokens_used):
        """
        Property: token_pressure is always in [0.0, 1.0] regardless of
        how many tokens are consumed (never exceeds budget due to guard).
        """
        from unified_superpowers.core.execution_context import ExecutionContext

        budget = 1000
        ctx = ExecutionContext(task="t", token_budget=budget)
        tokens = min(tokens_used, budget)   # clamp to budget for this test

        actual = run(_consume_tokens(ctx, tokens))
        assert 0.0 <= ctx.token_pressure <= 1.0, \
            f"token_pressure {ctx.token_pressure} out of [0,1] with budget={budget}, used={tokens}"

    async def _consume_tokens(ctx, n):
        await ctx.consume_tokens(n)

    @given(st.text(min_size=0, max_size=500))
    @settings(max_examples=200, deadline=2000)
    def test_hash_embedding_always_unit_normalised(text):
        """
        Property: HashEmbeddingFunction always returns a unit-normalised
        vector (L2 norm ≈ 1.0, within floating-point tolerance).
        """
        from unified_superpowers.memory.chroma_store import _make_local_ef

        ef = _make_local_ef()
        if not text:   # empty string → skip (chroma rejects empty docs)
            return
        vecs = ef([text])
        assert len(vecs) == 1
        vec = vecs[0]
        assert len(vec) == 512   # DIM
        norm = math.sqrt(sum(x * x for x in vec))
        assert abs(norm - 1.0) < 1e-6, \
            f"L2 norm {norm:.6f} ≠ 1.0 for text {text!r:.30}"

    @given(st.integers(min_value=1, max_value=200),
           st.integers(min_value=1, max_value=50))
    @settings(max_examples=100, deadline=500)
    def test_freebuff_maxlen_always_enforced(n_writes, maxlen):
        """
        Property: After N writes to a FreeBuff(maxlen=M),
        len(buffer) == min(N, M) — maxlen is always honoured.
        """
        from unified_superpowers.utils.freebuff import FreeBuff
        buf = FreeBuff(maxlen=maxlen)
        for i in range(n_writes):
            buf.write("agent", f"content_{i}")
        actual = len(buf._buffer)
        expected = min(n_writes, maxlen)
        assert actual == expected, \
            f"FreeBuff({maxlen}) has {actual} items after {n_writes} writes, expected {expected}"

    @given(st.integers(min_value=0, max_value=10))
    @settings(max_examples=50, deadline=500)
    def test_retry_jitter_always_in_range(attempt):
        """
        Property: jitter delay is always in [0, cap] for any attempt number.
        """
        from unified_superpowers.infra.resilience import RetryPolicy
        policy = RetryPolicy(max_attempts=20, base_delay_s=1.0, cap_delay_s=30.0)
        for _ in range(100):   # sample 100 random delays per attempt
            delay = policy._jitter_delay(attempt)
            assert 0.0 <= delay <= 30.0, \
                f"Jitter delay {delay} out of [0, 30] for attempt {attempt}"

    @given(st.text(min_size=1, max_size=300))
    @settings(max_examples=200, deadline=1000)
    def test_picoclaw_sanitizer_always_produces_valid_json(text):
        """
        Property: _sanitize_task_for_fallback(text) always produces
        output that can be safely embedded in a JSON string literal.
        """
        import json
        from unified_superpowers.agents.picoclaw_agent import PicoClawAgent
        from unittest.mock import MagicMock

        cfg = MagicMock()
        cfg.ui_vision.enable_ui_control = True
        cfg.ui_vision.vaxil_model = "test"
        cfg.intelligence.primary_provider = "anthropic"
        cfg.intelligence.anthropic_api_key = ""
        agent = PicoClawAgent(cfg)

        safe = agent._sanitize_task_for_fallback(text)
        # Must be embeddable in JSON string literal
        template = f'{{"value":"{safe}"}}'
        parsed = json.loads(template)   # must not raise JSONDecodeError
        assert "value" in parsed
