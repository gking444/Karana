"""
unified_superpowers/agents/goose_agent.py
─────────────────────────────────────────
GooseAgent — lightweight background worker.

Source: github.com/block/goose
  • Scheduled / async tasks that don't need a heavy reasoning loop
  • Wraps Goose toolkit: file I/O, shell commands, web requests
  • Used for: monitoring jobs, report digests, data collection, cron-style ops
"""
from __future__ import annotations
import asyncio
import structlog
from typing import Any

log = structlog.get_logger(__name__)


class GooseAgent:
    """Lightweight worker — fast, low-overhead, tool-calling loop."""

    SYSTEM_PROMPT = (
        "You are Goose, a lightweight autonomous worker. "
        "Complete tasks efficiently using the tools available. "
        "Report progress clearly. Fail fast if a tool is unavailable."
    )

    def __init__(self, config):
        self.config = config

    async def run(self, task: str, context: dict[str, Any] | None = None) -> str:
        log.info("goose.run", task=task[:60])
        # Goose wraps a simple tool-calling loop; we delegate to LightningAgent
        # with a goose-flavoured system prompt for now, and swap in the real
        # goose SDK when available in the environment.
        try:
            import goose  # type: ignore  # block/goose SDK
            session = goose.Session(provider=self.config.intelligence.primary_provider)
            result = await session.run(task)
            return result
        except ImportError:
            # Fallback: direct LLM call
            from unified_superpowers.agents.lightning_agent import LightningAgent
            agent = LightningAgent(self.config)
            return await agent.run(f"[Goose worker] {task}", context=context)

    async def schedule(self, task: str, cron_expr: str) -> str:
        """Register task with DeepFlow/Prefect scheduler."""
        log.info("goose.schedule", task=task[:60], cron=cron_expr)
        return f"Scheduled: '{task}' @ {cron_expr}"
