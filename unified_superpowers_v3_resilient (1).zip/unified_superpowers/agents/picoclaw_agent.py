"""
unified_superpowers/agents/picoclaw_agent.py
─────────────────────────────────────────────
PicoClawAgent — UI control + desktop automation.

Source repos:
  • PicoClaw  (system control / UI action)
  • UI-TARS   (github.com/bytedance/UI-TARS-desktop — multimodal UI agent stack)
  • edxui      (UI frontend layer)

Capabilities:
  • Screenshot capture + OCR
  • Mouse / keyboard control (pyautogui)
  • Browser automation (Playwright)
  • Visual grounding via VaXil vision layer
"""
from __future__ import annotations
import base64
import asyncio
import json
import structlog
from typing import Any

log = structlog.get_logger(__name__)

_UITARS_SYSTEM = """\
You are UI-TARS, a multimodal desktop AI agent.
You receive screenshots and natural-language instructions.
Respond with a JSON action plan:
{
  "actions": [
    {"type": "click|type|scroll|key|wait", "target": "...", "value": "..."}
  ],
  "reasoning": "..."
}
"""


class PicoClawAgent:
    """
    Desktop / UI automation agent — PicoClaw + UI-TARS unified.
    """

    def __init__(self, config):
        self.config = config
        self._pyautogui_available = self._check_pyautogui()

    def _check_pyautogui(self) -> bool:
        try:
            import pyautogui  # type: ignore
            return True
        except ImportError:
            return False

    async def run(self, task: str, context: dict[str, Any] | None = None) -> str:
        log.info("picoclaw.run", task=task[:80])

        if not self.config.ui_vision.enable_ui_control:
            return (
                "UI control is disabled. Set VISION_ENABLE_UI_CONTROL=true "
                "in your config to enable PicoClaw / UI-TARS."
            )

        screenshot_b64 = await self._capture_screenshot()
        action_plan = await self._plan_actions(task, screenshot_b64)
        return await self._execute_actions(action_plan)

    async def _capture_screenshot(self) -> str:
        """Capture screen → base64 PNG."""
        import io
        try:
            import pyautogui
            from PIL import Image
            img = pyautogui.screenshot()
            buf = io.BytesIO()
            img.save(buf, format="PNG")
            return base64.b64encode(buf.getvalue()).decode()
        except Exception as exc:
            log.warning("picoclaw.screenshot_failed", error=str(exc))
            return ""

    async def _plan_actions(self, task: str, screenshot_b64: str) -> list[dict]:
        """Send screenshot + task to vision model → action plan."""
        import json
        intel = self.config.intelligence

        if intel.primary_provider == "anthropic":
            import anthropic
            client = anthropic.AsyncAnthropic(api_key=intel.anthropic_api_key)
            content: list = [{"type": "text", "text": f"Task: {task}"}]
            if screenshot_b64:
                content.insert(0, {
                    "type": "image",
                    "source": {"type": "base64", "media_type": "image/png",
                               "data": screenshot_b64},
                })
            resp = await client.messages.create(
                model=self.config.ui_vision.vaxil_model,
                max_tokens=1024,
                system=_UITARS_SYSTEM,
                messages=[{"role": "user", "content": content}],
            )
            raw = resp.content[0].text
        else:
            # FIX [INJECTION]: sanitize task before embedding in JSON string literal.
            safe_task = self._sanitize_task_for_fallback(task)
            raw = f'{{"actions":[{{"type":"text","target":"","value":"{safe_task}"}}],"reasoning":"fallback"}}'

        try:
            data = json.loads(raw)
            return data.get("actions", [])
        except Exception as exc:
            # FIX [SILENT_EXCEPTION]: log parse failure; don't silently drop it.
            log.warning("picoclaw.plan_parse_failed", error=str(exc), raw_preview=raw[:120])
            return []

    def _sanitize_task_for_fallback(self, task: str) -> str:
        """
        FIX [INJECTION]: the fallback path interpolates `task` directly into a
        JSON string literal.  Escaping only quote/backslash/newline is
        insufficient — raw control characters (0x00-0x1F, e.g. \\x1f) are
        also invalid inside a JSON string and break json.loads().

        FIX [PROPERTY_TEST_FOUND]: use json.dumps() to get fully RFC-8259
        compliant escaping (handles every control character, not just the
        three we previously special-cased), then strip the wrapping quotes
        since the caller embeds the result inside its own quoted literal.
        """
        truncated = task[:200]
        # json.dumps('foo') -> '"foo"'; strip the outer quotes we don't want
        return json.dumps(truncated)[1:-1]

    async def _execute_actions(self, actions: list[dict]) -> str:
        """Execute pyautogui actions from plan."""
        if not self._pyautogui_available or not actions:
            return f"Planned {len(actions)} UI action(s) — execution skipped (no display)."

        import pyautogui
        results = []
        for act in actions:
            atype = act.get("type", "")
            val   = act.get("value", "")
            try:
                if atype == "click":
                    pyautogui.click()
                elif atype == "type":
                    pyautogui.typewrite(val, interval=0.05)
                elif atype == "key":
                    pyautogui.press(val)
                elif atype == "scroll":
                    pyautogui.scroll(int(val) if val else 3)
                elif atype == "wait":
                    await asyncio.sleep(float(val) if val else 1.0)
                results.append(f"✓ {atype}: {val[:40]}")
            except Exception as exc:
                results.append(f"✗ {atype}: {exc}")

        return "\n".join(results)
