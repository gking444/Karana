"""
unified_superpowers/agents/hermes_agent.py
──────────────────────────────────────────
HermesAgent — the primary reasoning / brain model.

Source repos:
  • Hermes   (NousResearch Hermes reasoning model)
  • OpenClaude (deep reasoning — uses Anthropic Opus tier)
  • Microsoft JARVIS task-planning stage (4-step: plan→select→execute→respond)

Architecture:
  • Fast path  → primary LLM (Claude Sonnet / Gemma 4 local)
  • Deep path  → OpenClaude / Claude Opus when complexity > threshold
  • JARVIS path → decompose into sub-task graph, dispatch to HuggingFace models
"""

from __future__ import annotations
import asyncio
from typing import Any, AsyncIterator
import structlog

log = structlog.get_logger(__name__)

_HERMES_SYSTEM = """\
You are Hermes, the reasoning core of Unified Superpowers.
You excel at multi-step analysis, planning, architecture decisions,
and synthesising information from multiple sources.
Think step-by-step. Be precise, honest, and thorough.
"""

_JARVIS_PLAN_PROMPT = """\
You are the task planner for a multi-model AI system (inspired by Microsoft JARVIS/HuggingGPT).
Given the user request below, decompose it into a JSON list of subtasks.
Each subtask has: {{"id": str, "description": str, "tool": str, "depends_on": [str]}}.
Available tools: text_generation, image_captioning, code_execution,
                 web_search, file_read, file_write, ui_automation, data_analysis.

User request: {task}

Respond ONLY with a valid JSON array. No markdown fences.
"""


class HermesAgent:
    """
    Primary reasoning agent — acts as the 'brain' of the system.
    Wraps:
      • Hermes reasoning via Anthropic / OpenAI
      • OpenClaude deep-path (Opus tier)
      • JARVIS-style task decomposition
    """

    def __init__(self, config):
        self.config = config
        self._client = None

    def _build_client(self):
        intel = self.config.intelligence
        if intel.primary_provider == "anthropic":
            import anthropic
            return anthropic.AsyncAnthropic(api_key=intel.anthropic_api_key)
        import openai
        return openai.AsyncOpenAI(api_key=intel.openai_api_key)

    @property
    def client(self):
        if self._client is None:
            self._client = self._build_client()
        return self._client

    # ── Core run ──────────────────────────────────────────────────────────

    async def run(self, task: str, context: dict[str, Any] | None = None,
                  force_deep: bool = False) -> str:
        intel = self.config.intelligence
        ctx_str = f"\n\nAdditional context:\n{context}" if context else ""
        full_prompt = task + ctx_str

        # Choose model: deep reasoning path (OpenClaude / Opus) or standard
        use_deep = force_deep or self._needs_deep_reasoning(task)
        model = intel.deep_reasoning_model if use_deep else intel.primary_model

        log.info("hermes.run", model=model, deep=use_deep, task=task[:80])

        if intel.primary_provider == "anthropic":
            resp = await self.client.messages.create(
                model=model,
                max_tokens=4096,
                system=_HERMES_SYSTEM,
                messages=[{"role": "user", "content": full_prompt}],
            )
            return resp.content[0].text

        # OpenAI path
        resp = await self.client.chat.completions.create(
            model=model,
            max_tokens=4096,
            messages=[
                {"role": "system", "content": _HERMES_SYSTEM},
                {"role": "user", "content": full_prompt},
            ],
        )
        return resp.choices[0].message.content

    # ── Streaming ─────────────────────────────────────────────────────────

    async def stream(self, task: str) -> AsyncIterator[str]:
        intel = self.config.intelligence
        if intel.primary_provider == "anthropic":
            async with self.client.messages.stream(
                model=intel.primary_model,
                max_tokens=4096,
                system=_HERMES_SYSTEM,
                messages=[{"role": "user", "content": task}],
            ) as stream:
                async for text in stream.text_stream:
                    yield text
        else:
            stream = await self.client.chat.completions.create(
                model=intel.primary_model,
                max_tokens=4096,
                stream=True,
                messages=[
                    {"role": "system", "content": _HERMES_SYSTEM},
                    {"role": "user", "content": task},
                ],
            )
            async for chunk in stream:
                delta = chunk.choices[0].delta.content
                if delta:
                    yield delta

    # ── JARVIS-style sub-task decomposition (Microsoft JARVIS) ────────────

    async def decompose_to_subtasks(self, task: str) -> list[dict]:
        """
        Break a complex task into a directed acyclic graph of subtasks.
        Inspired by the 4-stage HuggingGPT / JARVIS planning approach.
        """
        import json
        prompt = _JARVIS_PLAN_PROMPT.format(task=task)
        raw = await self.run(prompt)
        try:
            # strip any stray markdown
            clean = raw.strip().lstrip("```json").rstrip("```").strip()
            return json.loads(clean)
        except json.JSONDecodeError:
            log.warning("jarvis.plan.parse_failed", raw=raw[:200])
            return [{"id": "0", "description": task, "tool": "text_generation",
                     "depends_on": []}]

    # ── Complexity heuristic ──────────────────────────────────────────────

    def _needs_deep_reasoning(self, task: str) -> bool:
        threshold = self.config.intelligence.deep_reasoning_threshold
        # Rough proxy: long tasks, or tasks with "deep" / "architecture" keywords
        deep_signals = ["architect", "design system", "compare tradeoffs",
                        "formal proof", "security audit", "strategic plan",
                        "research paper", "full implementation"]
        hit = any(s in task.lower() for s in deep_signals)
        long = len(task) > 800
        return hit or long
