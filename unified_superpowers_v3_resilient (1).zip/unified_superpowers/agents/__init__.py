"""
unified_superpowers/agents/__init__.py  +  all agent adapters
─────────────────────────────────────────────────────────────
Mapped repos:
  LightningAgent  → github.com/lightning-agent (fast executor)
  GooseAgent      → github.com/block/goose     (lightweight worker)
  OpenHandsAdapter→ github.com/All-Hands-AI/OpenHands
  PicoClawAgent   → github.com/PicoClaw + UI-TARS (UI/desktop control)
  HermesAgent     → Hermes reasoning model + OpenClaude deep-reasoning
"""
# agents/__init__.py  — intentionally empty; each agent is a separate module
