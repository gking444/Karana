"""
unified_superpowers/agents/openhands_adapter.py
────────────────────────────────────────────────
OpenHandsAdapter — coding & dev-execution agent.

Source: github.com/All-Hands-AI/OpenHands
  • Code generation, editing, refactoring
  • Shell command execution in sandboxed env
  • File I/O, Git operations, package installs
  • CodeAct-style: write→execute→observe loop
"""
from __future__ import annotations
import structlog
from typing import Any

log = structlog.get_logger(__name__)


class OpenHandsAdapter:
    """
    Wraps the OpenHands SDK (openhands-ai PyPI package).
    Falls back to a LangChain Python REPL chain if the SDK is absent.
    """

    def __init__(self, config):
        self.config = config
        self._sdk_available = self._check_sdk()

    def _check_sdk(self) -> bool:
        try:
            import openhands  # type: ignore
            return True
        except ImportError:
            return False

    async def run(self, task: str, context: dict[str, Any] | None = None) -> str:
        log.info("openhands.run", task=task[:80], sdk=self._sdk_available)

        if self._sdk_available:
            return await self._run_sdk(task, context)
        return await self._run_langchain_fallback(task, context)

    async def _run_sdk(self, task: str, context: dict | None) -> str:
        import asyncio
        from openhands import OpenHands  # type: ignore
        oh = OpenHands(
            llm_provider=self.config.intelligence.primary_provider,
            model=self.config.intelligence.primary_model,
            sandbox_image=self.config.infra.sandbox_image,
        )
        result = await oh.run(task)
        return result.output

    async def _run_langchain_fallback(self, task: str, context: dict | None) -> str:
        from langchain_experimental.agents import create_python_agent
        from langchain_experimental.tools import PythonREPLTool
        from langchain_openai import ChatOpenAI

        intel = self.config.intelligence
        llm = ChatOpenAI(model=intel.primary_model, api_key=intel.openai_api_key)
        agent = create_python_agent(llm=llm, tool=PythonREPLTool(), verbose=False)
        result = agent.run(task)
        return str(result)
