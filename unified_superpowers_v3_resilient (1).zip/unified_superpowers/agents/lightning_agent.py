"""
unified_superpowers/agents/lightning_agent.py
─────────────────────────────────────────────
LightningAgent — fast executor for small, stateless tasks.

Based on: github.com/lightning-agent concept
  • Single LLM call — no tool loop
  • Timeout: 30 s (config.workflow.fast_task_timeout_s)
  • Ideal for: Q&A, translation, quick math, summaries
"""

from __future__ import annotations
import asyncio
from typing import Any

import structlog

log = structlog.get_logger(__name__)


class LightningAgent:
    """Single-shot, low-latency agent — wraps a direct Anthropic/OpenAI call."""

    SYSTEM_PROMPT = (
        "You are LightningAgent — a fast, precise AI assistant. "
        "Answer concisely and accurately. No fluff."
    )

    def __init__(self, config):
        self.config = config
        self._client = None

    def _get_client(self):
        if self._client is None:
            intel = self.config.intelligence
            if intel.primary_provider == "anthropic":
                import anthropic
                self._client = anthropic.AsyncAnthropic(api_key=intel.anthropic_api_key)
            elif intel.primary_provider == "openai":
                import openai
                self._client = openai.AsyncOpenAI(api_key=intel.openai_api_key)
        return self._client

    async def raw_llm(self, prompt: str) -> str:
        """
        Direct LLM call used by TaskRouter and quick helpers.

        FIX [WAIT_FOR_NO_CANCEL_HANDLER]:
          asyncio.wait_for() cancels the wrapped coroutine on timeout and
          raises asyncio.TimeoutError.  Without a handler the CancelledError
          propagates up unhandled, potentially leaving the HTTP connection
          in an indeterminate state inside the SDK's internal pool.

          We catch TimeoutError explicitly, log it with context (so timeouts
          are visible in LangSmith traces), and re-raise as a RuntimeError
          with a clear message so callers get actionable diagnostics.

          CancelledError (external cancellation, e.g. keyboard interrupt or
          parent task cancelled) is re-raised immediately — we never swallow it.
        """
        intel = self.config.intelligence
        client = self._get_client()
        timeout = self.config.workflow.fast_task_timeout_s

        try:
            if intel.primary_provider == "anthropic":
                resp = await asyncio.wait_for(
                    client.messages.create(
                        model=intel.primary_model,
                        max_tokens=512,
                        system=self.SYSTEM_PROMPT,
                        messages=[{"role": "user", "content": prompt}],
                    ),
                    timeout=timeout,
                )
                return resp.content[0].text

            elif intel.primary_provider == "openai":
                resp = await asyncio.wait_for(
                    client.chat.completions.create(
                        model=intel.primary_model,
                        max_tokens=512,
                        messages=[
                            {"role": "system", "content": self.SYSTEM_PROMPT},
                            {"role": "user", "content": prompt},
                        ],
                    ),
                    timeout=timeout,
                )
                return resp.choices[0].message.content

            raise ValueError(f"Unsupported provider: {intel.primary_provider}")

        except asyncio.TimeoutError:
            log.warning(
                "lightning.timeout",
                provider=intel.primary_provider,
                timeout_s=timeout,
                prompt_preview=prompt[:60],
            )
            raise RuntimeError(
                f"LLM call timed out after {timeout}s "
                f"(provider={intel.primary_provider}). "
                "Check network or increase WORKFLOW_FAST_TASK_TIMEOUT_S."
            )

        except asyncio.CancelledError:
            # FIX: never swallow CancelledError — log and re-raise immediately
            log.warning("lightning.cancelled", prompt_preview=prompt[:60])
            raise

    async def run(self, task: str, context: dict[str, Any] | None = None) -> str:
        log.info("lightning.run", task=task[:60])
        ctx_str = f"\nContext: {context}" if context else ""
        return await self.raw_llm(task + ctx_str)
